import { useEffect, useRef } from 'react';

type BackOverlayCallback = () => void;

const overlayStack: BackOverlayCallback[] = [];

export function useRegisterBackOverlay(active: boolean, onClose: BackOverlayCallback): void {
  const onCloseRef = useRef(onClose);
  onCloseRef.current = onClose;

  useEffect(() => {
    if (!active) return;
    const handler = () => {
      onCloseRef.current();
    };
    overlayStack.push(handler);
    return () => {
      const idx = overlayStack.lastIndexOf(handler);
      if (idx !== -1) {
        overlayStack.splice(idx, 1);
      }
    };
  }, [active]);
}

export function handleOverlayBackPress(): boolean {
  const top = overlayStack[overlayStack.length - 1];
  if (!top) return false;
  top();
  return true;
}

import { Capacitor } from '@capacitor/core';
import type { DecryptedBackupPayload, EncryptedBackupEnvelope } from '../types';
import { checkNativeBiometricAvailable, verifyWithNativeBiometric } from './platform';

const encoder = new TextEncoder();
const decoder = new TextDecoder();

function bytesToBase64(bytes: Uint8Array): string {
  let binary = '';
  const chunkSize = 0x8000;
  for (let i = 0; i < bytes.length; i += chunkSize) {
    binary += String.fromCharCode(...bytes.subarray(i, i + chunkSize));
  }
  return btoa(binary);
}

function base64ToBytes(b64: string): Uint8Array {
  const binary = atob(b64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  return bytes;
}

export function generateSalt(length = 16): string {
  const bytes = crypto.getRandomValues(new Uint8Array(length));
  return bytesToBase64(bytes);
}

export async function hashPin(pin: string, saltB64: string): Promise<string> {
  const keyMaterial = await crypto.subtle.importKey(
    'raw',
    encoder.encode(pin),
    'PBKDF2',
    false,
    ['deriveBits']
  );
  const bits = await crypto.subtle.deriveBits(
    {
      name: 'PBKDF2',
      salt: base64ToBytes(saltB64) as BufferSource,
      iterations: 100000,
      hash: 'SHA-256',
    },
    keyMaterial,
    256
  );
  return bytesToBase64(new Uint8Array(bits));
}

export async function verifyPin(pin: string, saltB64: string, expectedHashB64: string): Promise<boolean> {
  const derived = await hashPin(pin, saltB64);
  if (derived.length !== expectedHashB64.length) return false;
  let diff = 0;
  for (let i = 0; i < derived.length; i++) {
    diff |= derived.charCodeAt(i) ^ expectedHashB64.charCodeAt(i);
  }
  return diff === 0;
}

async function deriveAesKey(passphrase: string, salt: Uint8Array, iterations = 100000): Promise<CryptoKey> {
  const keyMaterial = await crypto.subtle.importKey(
    'raw',
    encoder.encode(passphrase),
    'PBKDF2',
    false,
    ['deriveKey']
  );
  return crypto.subtle.deriveKey(
    {
      name: 'PBKDF2',
      salt: salt as BufferSource,
      iterations,
      hash: 'SHA-256',
    },
    keyMaterial,
    { name: 'AES-GCM', length: 256 },
    false,
    ['encrypt', 'decrypt']
  );
}

export async function encryptBackupPayload(
  payload: DecryptedBackupPayload,
  passphrase: string
): Promise<EncryptedBackupEnvelope> {
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const iterations = 100000;
  const key = await deriveAesKey(passphrase, salt, iterations);
  const plaintext = encoder.encode(JSON.stringify(payload));
  const encrypted = await crypto.subtle.encrypt(
    { name: 'AES-GCM', iv: iv as BufferSource },
    key,
    plaintext
  );
  return {
    format: 'TRIMOOL_AYURVEDA_ENCRYPTED_BACKUP',
    version: 1,
    algorithm: 'AES-256-GCM',
    kdf: 'PBKDF2-SHA256',
    iterations,
    salt: bytesToBase64(salt),
    iv: bytesToBase64(iv),
    ciphertext: bytesToBase64(new Uint8Array(encrypted)),
    createdAt: new Date().toISOString(),
  };
}

export async function decryptBackupPayload(
  envelope: EncryptedBackupEnvelope,
  passphrase: string
): Promise<DecryptedBackupPayload> {
  if (
    !envelope ||
    envelope.format !== 'TRIMOOL_AYURVEDA_ENCRYPTED_BACKUP' ||
    !envelope.salt ||
    !envelope.iv ||
    !envelope.ciphertext
  ) {
    throw new Error('Invalid backup format');
  }
  const salt = base64ToBytes(envelope.salt);
  const iv = base64ToBytes(envelope.iv);
  const ciphertext = base64ToBytes(envelope.ciphertext);
  const key = await deriveAesKey(passphrase, salt, envelope.iterations || 100000);
  const decrypted = await crypto.subtle.decrypt(
    { name: 'AES-GCM', iv: iv as BufferSource },
    key,
    ciphertext as BufferSource
  );
  const json = decoder.decode(decrypted);
  const parsed = JSON.parse(json) as DecryptedBackupPayload;
  if (parsed.app !== 'TRIMOOL AYURVEDA') {
    throw new Error('Invalid backup payload');
  }
  return parsed;
}

// Local device key stored in IndexedDB keystore (non-extractable CryptoKey) for encrypting images at rest
const KEY_DB_NAME = 'TrimoolKeyStore';
const KEY_STORE_NAME = 'keys';
const DEVICE_KEY_ID = 'media_aes_key';

function openKeyDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(KEY_DB_NAME, 1);
    req.onupgradeneeded = () => {
      if (!req.result.objectStoreNames.contains(KEY_STORE_NAME)) {
        req.result.createObjectStore(KEY_STORE_NAME);
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

async function getOrCreateMediaKey(): Promise<CryptoKey> {
  const db = await openKeyDb();
  const existing = await new Promise<CryptoKey | undefined>((resolve, reject) => {
    const tx = db.transaction(KEY_STORE_NAME, 'readonly');
    const req = tx.objectStore(KEY_STORE_NAME).get(DEVICE_KEY_ID);
    req.onsuccess = () => resolve(req.result as CryptoKey | undefined);
    req.onerror = () => reject(req.error);
  });
  if (existing) {
    db.close();
    return existing;
  }
  const newKey = await crypto.subtle.generateKey(
    { name: 'AES-GCM', length: 256 },
    false, // non-extractable
    ['encrypt', 'decrypt']
  );
  await new Promise<void>((resolve, reject) => {
    const tx = db.transaction(KEY_STORE_NAME, 'readwrite');
    tx.objectStore(KEY_STORE_NAME).put(newKey, DEVICE_KEY_ID);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
  db.close();
  return newKey;
}

export async function encryptLocalMediaString(dataUrl: string): Promise<string> {
  const key = await getOrCreateMediaKey();
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const encrypted = await crypto.subtle.encrypt(
    { name: 'AES-GCM', iv: iv as BufferSource },
    key,
    encoder.encode(dataUrl)
  );
  return JSON.stringify({
    iv: bytesToBase64(iv),
    ct: bytesToBase64(new Uint8Array(encrypted)),
  });
}

export async function decryptLocalMediaString(payload: string): Promise<string> {
  const parsed = JSON.parse(payload) as { iv: string; ct: string };
  const key = await getOrCreateMediaKey();
  const decrypted = await crypto.subtle.decrypt(
    { name: 'AES-GCM', iv: base64ToBytes(parsed.iv) as BufferSource },
    key,
    base64ToBytes(parsed.ct) as BufferSource
  );
  return decoder.decode(decrypted);
}

// Platform Biometric Authentication (Native Android BiometricPrompt in Capacitor, WebAuthn in browser/PWA)
export async function isBiometricSupported(): Promise<boolean> {
  try {
    if (Capacitor.isNativePlatform()) {
      return await checkNativeBiometricAvailable();
    }
    if (
      typeof window === 'undefined' ||
      !window.PublicKeyCredential ||
      !PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable
    ) {
      return false;
    }
    return await PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable();
  } catch {
    return false;
  }
}

export async function registerBiometricCredential(): Promise<string> {
  if (Capacitor.isNativePlatform()) {
    await verifyWithNativeBiometric({
      title: 'TRIMOOL AYURVEDA',
      subtitle: 'Enable fingerprint / face unlock',
      reason: 'Confirm your device biometric to protect clinic records',
      cancelText: 'Cancel',
    });
    return 'native-android-biometric';
  }

  const challenge = crypto.getRandomValues(new Uint8Array(32));
  const userId = crypto.getRandomValues(new Uint8Array(16));
  const credential = (await navigator.credentials.create({
    publicKey: {
      challenge,
      rp: { name: 'TRIMOOL AYURVEDA' },
      user: {
        id: userId,
        name: 'clinic-doctor',
        displayName: 'TRIMOOL AYURVEDA Doctor',
      },
      pubKeyCredParams: [
        { alg: -7, type: 'public-key' },
        { alg: -257, type: 'public-key' },
      ],
      authenticatorSelection: {
        authenticatorAttachment: 'platform',
        userVerification: 'required',
      },
      timeout: 60000,
    },
  })) as PublicKeyCredential | null;

  if (!credential) {
    throw new Error('Biometric registration failed');
  }
  return bytesToBase64(new Uint8Array(credential.rawId));
}

export async function verifyBiometricCredential(credentialIdB64: string): Promise<boolean> {
  if (Capacitor.isNativePlatform()) {
    return await verifyWithNativeBiometric({
      title: 'TRIMOOL AYURVEDA',
      subtitle: 'Unlock clinic records',
      reason: 'Verify your identity to access patient records',
      cancelText: 'Use PIN',
    });
  }

  const challenge = crypto.getRandomValues(new Uint8Array(32));
  const assertion = await navigator.credentials.get({
    publicKey: {
      challenge,
      allowCredentials: [
        {
          id: base64ToBytes(credentialIdB64) as BufferSource,
          type: 'public-key',
          transports: ['internal'],
        },
      ],
      userVerification: 'required',
      timeout: 60000,
    },
  });
  return Boolean(assertion);
}

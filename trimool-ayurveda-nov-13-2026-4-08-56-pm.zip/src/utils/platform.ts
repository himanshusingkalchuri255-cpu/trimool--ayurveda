import { Capacitor } from '@capacitor/core';
import { Camera, CameraResultType, CameraSource } from '@capacitor/camera';
import { Directory, Encoding, Filesystem } from '@capacitor/filesystem';
import { Share } from '@capacitor/share';
import { NativeBiometric } from '@capgo/capacitor-native-biometric';
import type { ImageCategory } from '../types';

export function isNativeApp(): boolean {
  return Capacitor.isNativePlatform();
}

export function isNativeAndroid(): boolean {
  return Capacitor.isNativePlatform() && Capacitor.getPlatform() === 'android';
}

export interface CapturedMediaItem {
  dataUrl: string;
  fileName: string;
  mimeType: string;
  sizeBytes: number;
}

function estimateDataUrlBytes(dataUrl: string): number {
  const commaIdx = dataUrl.indexOf(',');
  const b64Len = commaIdx >= 0 ? dataUrl.length - commaIdx - 1 : dataUrl.length;
  return Math.round((b64Len * 3) / 4);
}

function blobToDataUrl(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        resolve(reader.result);
      } else {
        reject(new Error('Failed to read image blob'));
      }
    };
    reader.onerror = () => reject(reader.error || new Error('FileReader error'));
    reader.readAsDataURL(blob);
  });
}

function isUserCancelledError(err: unknown): boolean {
  const msg = String((err as { message?: string })?.message || err || '').toLowerCase();
  return msg.includes('cancel') || msg.includes('user did not');
}

export async function capturePhotoWithNativeCamera(
  category: ImageCategory
): Promise<CapturedMediaItem | null> {
  try {
    const perms = await Camera.checkPermissions();
    if (perms.camera !== 'granted') {
      const requested = await Camera.requestPermissions({ permissions: ['camera'] });
      if (requested.camera !== 'granted' && requested.camera !== 'limited') {
        throw new Error('Camera permission denied');
      }
    }

    const photo = await Camera.getPhoto({
      source: CameraSource.Camera,
      resultType: CameraResultType.DataUrl,
      quality: 90,
      correctOrientation: true,
      saveToGallery: false,
    });

    if (!photo.dataUrl) {
      return null;
    }

    const format = (photo.format || 'jpeg').toLowerCase();
    const ext = format === 'png' ? 'png' : 'jpg';
    const mimeType = format === 'png' ? 'image/png' : 'image/jpeg';
    const prefix = category === 'prescription' ? 'prescription' : 'report';

    return {
      dataUrl: photo.dataUrl,
      fileName: `${prefix}_${Date.now()}.${ext}`,
      mimeType,
      sizeBytes: estimateDataUrlBytes(photo.dataUrl),
    };
  } catch (err) {
    if (isUserCancelledError(err)) {
      return null;
    }
    throw err;
  }
}

export async function pickPhotosFromNativeGallery(
  category: ImageCategory
): Promise<CapturedMediaItem[]> {
  try {
    const perms = await Camera.checkPermissions();
    if (perms.photos !== 'granted' && perms.photos !== 'limited') {
      await Camera.requestPermissions({ permissions: ['photos'] });
    }

    const picked = await Camera.pickImages({
      quality: 90,
      limit: 10,
      correctOrientation: true,
    });

    if (!picked.photos || picked.photos.length === 0) {
      return [];
    }

    const prefix = category === 'prescription' ? 'prescription' : 'report';
    const results: CapturedMediaItem[] = [];

    for (let i = 0; i < picked.photos.length; i++) {
      const item = picked.photos[i];
      const fetchUrl = item.webPath || (item.path ? Capacitor.convertFileSrc(item.path) : '');
      if (!fetchUrl) continue;

      const response = await fetch(fetchUrl);
      const blob = await response.blob();
      const dataUrl = await blobToDataUrl(blob);
      const format = (item.format || 'jpeg').toLowerCase();
      const ext = format === 'png' ? 'png' : 'jpg';
      const mimeType = blob.type || (format === 'png' ? 'image/png' : 'image/jpeg');

      results.push({
        dataUrl,
        fileName: `${prefix}_${Date.now()}_${i + 1}.${ext}`,
        mimeType,
        sizeBytes: blob.size || estimateDataUrlBytes(dataUrl),
      });
    }

    return results;
  } catch (err) {
    if (isUserCancelledError(err)) {
      return [];
    }
    throw err;
  }
}

export async function checkNativeBiometricAvailable(): Promise<boolean> {
  try {
    const res = await NativeBiometric.isAvailable({ useFallback: false });
    return Boolean(res.isAvailable);
  } catch {
    return false;
  }
}

export async function verifyWithNativeBiometric(options?: {
  title?: string;
  subtitle?: string;
  reason?: string;
  cancelText?: string;
}): Promise<boolean> {
  await NativeBiometric.verifyIdentity({
    title: options?.title || 'TRIMOOL AYURVEDA',
    subtitle: options?.subtitle || 'Verify identity to unlock clinic records',
    reason: options?.reason || 'Authenticate to access patient records',
    negativeButtonText: options?.cancelText || 'Use PIN',
    useFallback: false,
  });
  return true;
}

export async function saveBackupFileOnNative(
  fileName: string,
  jsonString: string,
  shareTitle: string
): Promise<void> {
  // Write to app cache and share via Android share/save sheet so user can save to Downloads/Files/Drive
  const cacheResult = await Filesystem.writeFile({
    path: fileName,
    data: jsonString,
    directory: Directory.Cache,
    encoding: Encoding.UTF8,
  });

  // Also keep a local copy in app-private Documents directory
  try {
    await Filesystem.writeFile({
      path: `backups/${fileName}`,
      data: jsonString,
      directory: Directory.Data,
      encoding: Encoding.UTF8,
      recursive: true,
    });
  } catch {
    // Non-fatal if private copy fails
  }

  await Share.share({
    title: shareTitle,
    text: fileName,
    url: cacheResult.uri,
    dialogTitle: shareTitle,
  });
}

import React from 'react';

interface TrimoolLogoProps {
  className?: string;
}

export const TrimoolLogo: React.FC<TrimoolLogoProps> = ({ className = 'w-10 h-10' }) => {
  return (
    <svg
      viewBox="0 0 64 64"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      aria-hidden="true"
    >
      <rect width="64" height="64" rx="16" className="fill-[#14532D] dark:fill-emerald-900" />
      <circle
        cx="32"
        cy="32"
        r="24"
        className="stroke-emerald-300/30"
        strokeWidth="1.5"
      />
      {/* Center upright herbal leaf */}
      <path
        d="M32 12C32 12 40 21.5 40 31C40 37 36.5 41.5 32 43.2C27.5 41.5 24 37 24 31C24 21.5 32 12 32 12Z"
        className="fill-emerald-50"
      />
      <path
        d="M32 17V42.5"
        className="stroke-[#14532D]"
        strokeWidth="1.8"
        strokeLinecap="round"
      />
      {/* Left leaf */}
      <path
        d="M30.2 43.2C23.5 42.2 16.8 36.8 14.8 28.5C21 29.3 26.8 33.5 30.2 43.2Z"
        className="fill-emerald-300"
      />
      {/* Right leaf */}
      <path
        d="M33.8 43.2C40.5 42.2 47.2 36.8 49.2 28.5C43 29.3 37.2 33.5 33.8 43.2Z"
        className="fill-emerald-300"
      />
      {/* Three roots (Tri-Mool) */}
      <path
        d="M32 43.2V51.5M32 45.5C29.5 47.7 26.8 49.2 24.5 50.2M32 45.5C34.5 47.7 37.2 49.2 39.5 50.2"
        className="stroke-emerald-100"
        strokeWidth="2"
        strokeLinecap="round"
      />
    </svg>
  );
};

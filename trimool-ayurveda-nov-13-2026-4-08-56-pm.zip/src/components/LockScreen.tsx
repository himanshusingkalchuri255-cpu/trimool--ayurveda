import React, { useState } from 'react';
import { Fingerprint, Lock } from 'lucide-react';
import { translations } from '../i18n/translations';
import type { Language } from '../types';
import { verifyBiometricCredential, verifyPin } from '../utils/crypto';
import { TrimoolLogo } from './TrimoolLogo';

interface LockScreenProps {
  language: Language;
  pinSalt: string;
  pinHash: string;
  biometricEnabled: boolean;
  biometricCredentialId: string | null;
  onUnlock: () => void;
}

export const LockScreen: React.FC<LockScreenProps> = ({
  language,
  pinSalt,
  pinHash,
  biometricEnabled,
  biometricCredentialId,
  onUnlock,
}) => {
  const t = translations[language];
  const [pin, setPin] = useState('');
  const [error, setError] = useState('');
  const [checking, setChecking] = useState(false);

  const handlePinSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setChecking(true);
    try {
      const ok = await verifyPin(pin, pinSalt, pinHash);
      if (ok) {
        setPin('');
        onUnlock();
      } else {
        setError(t.wrongPin);
      }
    } catch {
      setError(t.wrongPin);
    } finally {
      setChecking(false);
    }
  };

  const handleBiometric = async () => {
    if (!biometricCredentialId) return;
    setError('');
    setChecking(true);
    try {
      const ok = await verifyBiometricCredential(biometricCredentialId);
      if (ok) {
        onUnlock();
      } else {
        setError(t.biometricFailed);
      }
    } catch {
      setError(t.biometricFailed);
    } finally {
      setChecking(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#F4F7F5] dark:bg-[#0B1510] p-4">
      <div className="w-full max-w-sm rounded-3xl bg-white dark:bg-[#132219] border border-emerald-950/10 dark:border-emerald-200/10 p-8 shadow-lg">
        <div className="flex flex-col items-center text-center">
          <TrimoolLogo className="w-16 h-16" />
          <div className="mt-4 flex items-center gap-2 text-emerald-900 dark:text-emerald-200">
            <Lock className="w-4 h-4" />
            <h1 className="text-xl font-bold tracking-tight">{t.unlockTitle}</h1>
          </div>
          <p className="mt-2 text-sm text-slate-600 dark:text-slate-300">{t.unlockSubtitle}</p>
        </div>

        <form onSubmit={handlePinSubmit} className="mt-6 space-y-4">
          <div>
            <input
              type="password"
              inputMode="numeric"
              pattern="[0-9]*"
              maxLength={6}
              autoFocus
              value={pin}
              onChange={(e) => {
                setPin(e.target.value.replace(/\D/g, ''));
                setError('');
              }}
              placeholder={t.enterPin}
              className="w-full min-h-[48px] rounded-xl border border-slate-300 dark:border-emerald-200/20 bg-white dark:bg-[#0B1510] px-4 py-3 text-center text-xl tracking-[0.4em] font-semibold tabular-nums text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-emerald-700"
            />
          </div>

          {error && (
            <p className="text-sm font-medium text-red-700 dark:text-red-300 text-center">
              {error}
            </p>
          )}

          <button
            type="submit"
            disabled={checking || pin.length < 4}
            className="w-full min-h-[48px] rounded-xl bg-[#14532D] hover:bg-[#166534] disabled:opacity-50 text-white font-semibold text-sm transition-colors cursor-pointer"
          >
            {t.unlock}
          </button>
        </form>

        {biometricEnabled && biometricCredentialId && (
          <button
            type="button"
            onClick={handleBiometric}
            disabled={checking}
            className="mt-3 w-full min-h-[48px] flex items-center justify-center gap-2 rounded-xl border border-emerald-800/20 dark:border-emerald-300/20 bg-emerald-50/70 dark:bg-emerald-950/40 text-emerald-950 dark:text-emerald-100 text-sm font-medium hover:bg-emerald-100/70 dark:hover:bg-emerald-950/70 transition-colors cursor-pointer"
          >
            <Fingerprint className="w-5 h-5" />
            <span>{t.useBiometric}</span>
          </button>
        )}
      </div>
    </div>
  );
};

import React, { useState } from 'react';
import { AlertCircle, ArrowLeft, ArrowRight, Save, UserCheck } from 'lucide-react';
import {
  findPotentialDuplicates,
  registerPatientWithFirstVisit,
  updatePatientDetails,
} from '../db/database';
import { getGenderLabel, translations } from '../i18n/translations';
import type { Gender, Language, Patient } from '../types';

interface PatientFormViewProps {
  language: Language;
  existingPatient?: Patient | null;
  onCancel: () => void;
  onCreated: (patient: Patient, firstVisitId: string) => void;
  onUpdated: (patient: Patient) => void;
  onOpenExistingPatient: (patientId: string) => void;
}

export const PatientFormView: React.FC<PatientFormViewProps> = ({
  language,
  existingPatient,
  onCancel,
  onCreated,
  onUpdated,
  onOpenExistingPatient,
}) => {
  const t = translations[language];
  const isEditing = Boolean(existingPatient);

  const [name, setName] = useState(existingPatient?.name || '');
  const [age, setAge] = useState(existingPatient ? String(existingPatient.age) : '');
  const [gender, setGender] = useState<Gender>(existingPatient?.gender || 'Male');
  const [mobile, setMobile] = useState(existingPatient?.mobile || '');
  const [address, setAddress] = useState(existingPatient?.address || '');
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);
  const [duplicates, setDuplicates] = useState<Patient[]>([]);

  const validate = (): number | null => {
    if (!name.trim()) {
      setError(t.validationNameRequired);
      return null;
    }
    const ageNum = Number(age);
    if (age.trim() === '' || Number.isNaN(ageNum) || ageNum < 0 || ageNum > 125) {
      setError(t.validationAgeRequired);
      return null;
    }
    setError('');
    return Math.round(ageNum);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const validAge = validate();
    if (validAge === null) return;

    setSaving(true);
    try {
      if (isEditing && existingPatient) {
        const updated = await updatePatientDetails(existingPatient.id, {
          name,
          age: validAge,
          gender,
          mobile,
          address,
        });
        onUpdated(updated);
        return;
      }

      // Duplicate patient protection before creating new patient
      const matches = await findPotentialDuplicates(name, mobile);
      if (matches.length > 0 && duplicates.length === 0) {
        setDuplicates(matches);
        setSaving(false);
        return;
      }

      const { patient, firstVisit } = await registerPatientWithFirstVisit({
        name,
        age: validAge,
        gender,
        mobile,
        address,
      });
      onCreated(patient, firstVisit.id);
    } finally {
      setSaving(false);
    }
  };

  const handleCreateAnyway = async () => {
    const validAge = validate();
    if (validAge === null) return;
    setSaving(true);
    try {
      const { patient, firstVisit } = await registerPatientWithFirstVisit({
        name,
        age: validAge,
        gender,
        mobile,
        address,
      });
      onCreated(patient, firstVisit.id);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="mx-auto max-w-2xl space-y-6">
      <div className="flex items-center gap-3">
        <button
          type="button"
          onClick={onCancel}
          className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl border border-emerald-950/10 dark:border-emerald-200/15 bg-white dark:bg-[#132219] text-slate-700 dark:text-slate-200 hover:bg-emerald-50 dark:hover:bg-emerald-950/50 transition-colors cursor-pointer"
          aria-label={t.backHome}
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-slate-100">
            {isEditing ? t.editPatientTitle : t.newPatientTitle}
          </h2>
          {isEditing && existingPatient && (
            <p className="text-xs font-medium text-emerald-800 dark:text-emerald-300 tabular-nums">
              {t.patientId}: {existingPatient.id}
            </p>
          )}
        </div>
      </div>

      {/* Duplicate Patient Warning */}
      {duplicates.length > 0 && (
        <div className="rounded-2xl border border-amber-300 dark:border-amber-700/60 bg-amber-50 dark:bg-amber-950/40 p-5 space-y-4">
          <div className="flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-amber-700 dark:text-amber-300 shrink-0 mt-0.5" />
            <div className="space-y-1">
              <h3 className="text-base font-semibold text-amber-950 dark:text-amber-100">
                {t.duplicateTitle}
              </h3>
              <p className="text-sm text-amber-900 dark:text-amber-200 leading-relaxed">
                {t.duplicateDesc}
              </p>
            </div>
          </div>

          <div className="space-y-2">
            {duplicates.map((dup) => (
              <div
                key={dup.id}
                className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 rounded-xl bg-white dark:bg-[#132219] border border-amber-200 dark:border-amber-800/50 p-4"
              >
                <div className="min-w-0">
                  <div className="font-semibold text-slate-900 dark:text-slate-100">
                    {dup.name}
                  </div>
                  <div className="mt-0.5 text-xs text-slate-600 dark:text-slate-300 tabular-nums flex flex-wrap items-center gap-x-2">
                    <span>{dup.id}</span>
                    <span aria-hidden="true">·</span>
                    <span>
                      {dup.age} {t.yearsShort}
                    </span>
                    <span aria-hidden="true">·</span>
                    <span>{getGenderLabel(dup.gender, language)}</span>
                    {dup.mobile && (
                      <>
                        <span aria-hidden="true">·</span>
                        <span>{dup.mobile}</span>
                      </>
                    )}
                  </div>
                  {dup.address && (
                    <div className="mt-0.5 text-xs text-slate-500 dark:text-slate-400 truncate">
                      {dup.address}
                    </div>
                  )}
                </div>
                <button
                  type="button"
                  onClick={() => onOpenExistingPatient(dup.id)}
                  className="min-h-[44px] shrink-0 inline-flex items-center justify-center gap-2 rounded-xl bg-[#14532D] hover:bg-[#166534] text-white px-4 py-2 text-sm font-semibold transition-colors cursor-pointer"
                >
                  <UserCheck className="w-4 h-4" />
                  <span>{t.openExistingProfile}</span>
                </button>
              </div>
            ))}
          </div>

          <div className="flex justify-end">
            <button
              type="button"
              onClick={handleCreateAnyway}
              disabled={saving}
              className="min-h-[44px] inline-flex items-center gap-2 rounded-xl border border-amber-700/30 dark:border-amber-300/30 px-4 py-2 text-sm font-medium text-amber-950 dark:text-amber-100 hover:bg-amber-100/70 dark:hover:bg-amber-900/30 transition-colors cursor-pointer"
            >
              <span>{t.createNewAnyway}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      <form
        onSubmit={handleSubmit}
        className="rounded-2xl bg-white dark:bg-[#132219] border border-emerald-950/10 dark:border-emerald-200/10 p-6 shadow-xs space-y-5"
      >
        {/* Patient Name */}
        <div>
          <div className="flex items-center justify-between mb-1.5">
            <label
              htmlFor="patient-name"
              className="text-sm font-semibold text-slate-800 dark:text-slate-200"
            >
              {t.patientName}
            </label>
            <span className="text-xs font-medium text-emerald-800 dark:text-emerald-300">
              {t.required}
            </span>
          </div>
          <input
            id="patient-name"
            type="text"
            required
            value={name}
            onChange={(e) => {
              setName(e.target.value);
              setDuplicates([]);
            }}
            placeholder={t.patientNamePlaceholder}
            className="w-full min-h-[48px] rounded-xl border border-slate-300 dark:border-emerald-200/20 bg-white dark:bg-[#0B1510] px-4 py-2.5 text-base text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-emerald-700"
          />
        </div>

        {/* Age & Gender Row */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label
                htmlFor="patient-age"
                className="text-sm font-semibold text-slate-800 dark:text-slate-200"
              >
                {t.age}
              </label>
              <span className="text-xs font-medium text-emerald-800 dark:text-emerald-300">
                {t.required}
              </span>
            </div>
            <input
              id="patient-age"
              type="number"
              inputMode="numeric"
              min={0}
              max={125}
              required
              value={age}
              onChange={(e) => setAge(e.target.value)}
              placeholder={t.agePlaceholder}
              className="w-full min-h-[48px] rounded-xl border border-slate-300 dark:border-emerald-200/20 bg-white dark:bg-[#0B1510] px-4 py-2.5 text-base tabular-nums text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-emerald-700"
            />
          </div>

          <div>
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-sm font-semibold text-slate-800 dark:text-slate-200">
                {t.gender}
              </span>
              <span className="text-xs font-medium text-emerald-800 dark:text-emerald-300">
                {t.required}
              </span>
            </div>
            <div className="grid grid-cols-3 gap-1.5 p-1 rounded-xl bg-slate-100 dark:bg-[#0B1510] border border-slate-200 dark:border-emerald-200/15">
              {(['Male', 'Female', 'Other'] as Gender[]).map((g) => (
                <button
                  key={g}
                  type="button"
                  onClick={() => setGender(g)}
                  className={`min-h-[40px] rounded-lg text-sm font-medium transition-colors cursor-pointer ${
                    gender === g
                      ? 'bg-[#14532D] text-white shadow-xs dark:bg-emerald-700'
                      : 'text-slate-700 dark:text-slate-300 hover:bg-white/60 dark:hover:bg-emerald-950/40'
                  }`}
                >
                  {getGenderLabel(g, language)}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Mobile Number */}
        <div>
          <div className="flex items-center justify-between mb-1.5">
            <label
              htmlFor="patient-mobile"
              className="text-sm font-semibold text-slate-800 dark:text-slate-200"
            >
              {t.mobile}
            </label>
            <span className="text-xs text-slate-500 dark:text-slate-400">{t.optional}</span>
          </div>
          <input
            id="patient-mobile"
            type="tel"
            inputMode="tel"
            value={mobile}
            onChange={(e) => {
              setMobile(e.target.value);
              setDuplicates([]);
            }}
            placeholder={t.mobilePlaceholder}
            className="w-full min-h-[48px] rounded-xl border border-slate-300 dark:border-emerald-200/20 bg-white dark:bg-[#0B1510] px-4 py-2.5 text-base tabular-nums text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-emerald-700"
          />
        </div>

        {/* Address */}
        <div>
          <div className="flex items-center justify-between mb-1.5">
            <label
              htmlFor="patient-address"
              className="text-sm font-semibold text-slate-800 dark:text-slate-200"
            >
              {t.address}
            </label>
            <span className="text-xs text-slate-500 dark:text-slate-400">{t.optional}</span>
          </div>
          <textarea
            id="patient-address"
            rows={2}
            value={address}
            onChange={(e) => setAddress(e.target.value)}
            placeholder={t.addressPlaceholder}
            className="w-full rounded-xl border border-slate-300 dark:border-emerald-200/20 bg-white dark:bg-[#0B1510] px-4 py-2.5 text-base text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-emerald-700"
          />
        </div>

        {error && (
          <p className="text-sm font-medium text-red-700 dark:text-red-300">{error}</p>
        )}

        <div className="pt-2 flex flex-col-reverse sm:flex-row sm:justify-end gap-3">
          <button
            type="button"
            onClick={onCancel}
            className="min-h-[48px] rounded-xl border border-slate-200 dark:border-emerald-200/15 px-6 py-3 text-sm font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-emerald-950/40 transition-colors cursor-pointer"
          >
            {t.cancel}
          </button>
          <button
            type="submit"
            disabled={saving}
            className="min-h-[48px] inline-flex items-center justify-center gap-2 rounded-xl bg-[#14532D] hover:bg-[#166534] dark:bg-emerald-700 dark:hover:bg-emerald-600 disabled:opacity-60 px-6 py-3 text-sm font-semibold text-white transition-colors cursor-pointer"
          >
            <Save className="w-4 h-4" />
            <span>{isEditing ? t.saveChanges : t.saveAndCreateVisit}</span>
          </button>
        </div>
      </form>
    </div>
  );
};

import React, { useEffect, useRef, useState } from 'react';
import { ChevronLeft, ChevronRight, RotateCcw, Trash2, X, ZoomIn, ZoomOut } from 'lucide-react';
import type { DecryptedMedicalImage } from '../db/database';
import { translations } from '../i18n/translations';
import type { Language } from '../types';
import { useRegisterBackOverlay } from '../utils/backHandler';

interface PhotoViewerModalProps {
  images: DecryptedMedicalImage[];
  initialIndex: number;
  language: Language;
  onClose: () => void;
  onRequestDelete: (image: DecryptedMedicalImage) => void;
}

export const PhotoViewerModal: React.FC<PhotoViewerModalProps> = ({
  images,
  initialIndex,
  language,
  onClose,
  onRequestDelete,
}) => {
  const t = translations[language];
  const [index, setIndex] = useState(initialIndex);
  const [scale, setScale] = useState(1);
  const [offset, setOffset] = useState({ x: 0, y: 0 });

  useRegisterBackOverlay(images.length > 0, onClose);

  const pointersRef = useRef<Map<number, { x: number; y: number }>>(new Map());
  const pinchStartDistRef = useRef<number | null>(null);
  const pinchStartScaleRef = useRef<number>(1);
  const dragStartRef = useRef<{ x: number; y: number; ox: number; oy: number } | null>(null);

  useEffect(() => {
    setIndex(Math.min(initialIndex, Math.max(0, images.length - 1)));
  }, [initialIndex, images.length]);

  useEffect(() => {
    setScale(1);
    setOffset({ x: 0, y: 0 });
  }, [index]);

  if (images.length === 0) return null;
  const current = images[index] || images[0];

  const resetZoom = () => {
    setScale(1);
    setOffset({ x: 0, y: 0 });
  };

  const adjustZoom = (delta: number) => {
    setScale((prev) => {
      const next = Math.min(5, Math.max(1, Number((prev + delta).toFixed(2))));
      if (next === 1) setOffset({ x: 0, y: 0 });
      return next;
    });
  };

  const handleWheel = (e: React.WheelEvent) => {
    e.preventDefault();
    adjustZoom(e.deltaY < 0 ? 0.35 : -0.35);
  };

  const handlePointerDown = (e: React.PointerEvent) => {
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    pointersRef.current.set(e.pointerId, { x: e.clientX, y: e.clientY });

    if (pointersRef.current.size === 2) {
      const pts = Array.from(pointersRef.current.values());
      pinchStartDistRef.current = Math.hypot(pts[0].x - pts[1].x, pts[0].y - pts[1].y);
      pinchStartScaleRef.current = scale;
      dragStartRef.current = null;
    } else if (pointersRef.current.size === 1 && scale > 1) {
      dragStartRef.current = {
        x: e.clientX,
        y: e.clientY,
        ox: offset.x,
        oy: offset.y,
      };
    }
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!pointersRef.current.has(e.pointerId)) return;
    pointersRef.current.set(e.pointerId, { x: e.clientX, y: e.clientY });

    if (pointersRef.current.size === 2 && pinchStartDistRef.current) {
      const pts = Array.from(pointersRef.current.values());
      const dist = Math.hypot(pts[0].x - pts[1].x, pts[0].y - pts[1].y);
      const ratio = dist / pinchStartDistRef.current;
      const nextScale = Math.min(5, Math.max(1, pinchStartScaleRef.current * ratio));
      setScale(nextScale);
      if (nextScale === 1) setOffset({ x: 0, y: 0 });
    } else if (pointersRef.current.size === 1 && dragStartRef.current && scale > 1) {
      const dx = e.clientX - dragStartRef.current.x;
      const dy = e.clientY - dragStartRef.current.y;
      setOffset({
        x: dragStartRef.current.ox + dx,
        y: dragStartRef.current.oy + dy,
      });
    }
  };

  const handlePointerUp = (e: React.PointerEvent) => {
    pointersRef.current.delete(e.pointerId);
    if (pointersRef.current.size < 2) {
      pinchStartDistRef.current = null;
    }
    if (pointersRef.current.size === 0) {
      dragStartRef.current = null;
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex flex-col bg-black text-white select-none"
      role="dialog"
      aria-modal="true"
    >
      {/* Top Toolbar */}
      <div className="flex items-center justify-between px-4 py-3 bg-black/85 border-b border-white/10">
        <div className="min-w-0 flex items-center gap-3">
          <span className="text-sm font-semibold tabular-nums">
            {index + 1} / {images.length}
          </span>
          <span className="text-xs text-neutral-400 truncate hidden sm:inline">
            {current.fileName}
          </span>
        </div>

        <div className="flex items-center gap-1">
          <button
            type="button"
            onClick={() => onRequestDelete(current)}
            className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl text-red-400 hover:bg-red-950/60 cursor-pointer"
            aria-label={t.deletePhoto}
          >
            <Trash2 className="w-5 h-5" />
          </button>
          <button
            type="button"
            onClick={onClose}
            className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl hover:bg-white/10 cursor-pointer"
            aria-label={t.close}
          >
            <X className="w-6 h-6" />
          </button>
        </div>
      </div>

      {/* Pinch-to-Zoom Canvas */}
      <div
        className="relative flex-1 flex items-center justify-center overflow-hidden touch-none"
        onWheel={handleWheel}
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        onPointerCancel={handlePointerUp}
        onDoubleClick={() => (scale > 1 ? resetZoom() : adjustZoom(1.5))}
      >
        <img
          src={current.dataUrl}
          alt={current.fileName}
          draggable={false}
          style={{
            transform: `translate3d(${offset.x}px, ${offset.y}px, 0) scale(${scale})`,
            transition: pointersRef.current.size > 0 ? 'none' : 'transform 120ms ease-out',
          }}
          className="max-h-full max-w-full object-contain pointer-events-none"
        />

        {images.length > 1 && (
          <>
            <button
              type="button"
              onClick={() => setIndex((i) => (i - 1 + images.length) % images.length)}
              className="absolute left-3 top-1/2 -translate-y-1/2 min-h-[44px] min-w-[44px] flex items-center justify-center rounded-full bg-black/60 hover:bg-black/80 border border-white/15 cursor-pointer"
              aria-label="Previous"
            >
              <ChevronLeft className="w-6 h-6" />
            </button>
            <button
              type="button"
              onClick={() => setIndex((i) => (i + 1) % images.length)}
              className="absolute right-3 top-1/2 -translate-y-1/2 min-h-[44px] min-w-[44px] flex items-center justify-center rounded-full bg-black/60 hover:bg-black/80 border border-white/15 cursor-pointer"
              aria-label="Next"
            >
              <ChevronRight className="w-6 h-6" />
            </button>
          </>
        )}
      </div>

      {/* Bottom Zoom Controls */}
      <div className="px-4 py-3 bg-black/85 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-2">
        <span className="text-xs text-neutral-400">{t.pinchHint}</span>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => adjustZoom(-0.5)}
            className="min-h-[44px] px-3 flex items-center gap-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-xs font-medium cursor-pointer"
          >
            <ZoomOut className="w-4 h-4" />
            <span>{t.zoomOut}</span>
          </button>
          <span className="text-xs font-semibold tabular-nums w-12 text-center">
            {Math.round(scale * 100)}%
          </span>
          <button
            type="button"
            onClick={() => adjustZoom(0.5)}
            className="min-h-[44px] px-3 flex items-center gap-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-xs font-medium cursor-pointer"
          >
            <ZoomIn className="w-4 h-4" />
            <span>{t.zoomIn}</span>
          </button>
          <button
            type="button"
            onClick={resetZoom}
            className="min-h-[44px] px-3 flex items-center gap-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-xs font-medium cursor-pointer"
          >
            <RotateCcw className="w-4 h-4" />
            <span>{t.resetZoom}</span>
          </button>
        </div>
      </div>
    </div>
  );
};

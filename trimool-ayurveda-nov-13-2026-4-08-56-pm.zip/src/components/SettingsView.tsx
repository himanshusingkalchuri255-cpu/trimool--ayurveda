import React, { useEffect, useRef, useState } from 'react';
import {
  ArrowLeft,
  CloudUpload,
  Download,
  Fingerprint,
  FolderUp,
  HardDriveDownload,
  KeyRound,
  Lock,
  LogOut,
  Moon,
  RefreshCw,
  ShieldCheck,
  Sun,
  Trash2,
} from 'lucide-react';
import type { User } from 'firebase/auth';
import {
  exportFullDatabasePayload,
  restoreFullDatabasePayload,
  saveSettings,
} from '../db/database';
import { formatDisplayDate, translations } from '../i18n/translations';
import {
  deleteDriveBackup,
  downloadDriveBackup,
  getDriveAccessToken,
  initDriveAuth,
  listDriveBackups,
  signInWithGoogleForDrive,
  signOutGoogleDrive,
  uploadEncryptedBackupToDrive,
} from '../services/googleDrive';
import type {
  AppSettings,
  DecryptedBackupPayload,
  DriveBackupFile,
  EncryptedBackupEnvelope,
  Language,
  ThemeMode,
} from '../types';
import {
  decryptBackupPayload,
  encryptBackupPayload,
  generateSalt,
  hashPin,
  isBiometricSupported,
  registerBiometricCredential,
} from '../utils/crypto';
import { useRegisterBackOverlay } from '../utils/backHandler';
import { isNativeApp, saveBackupFileOnNative } from '../utils/platform';
import { ConfirmDialog } from './ConfirmDialog';
import { PWAInstallButton } from './PWAInstallButton';

interface SettingsViewProps {
  settings: AppSettings;
  onSettingsUpdated: (updated: AppSettings) => void;
  onBack: () => void;
  onLockNow: () => void;
  onDataRestored: () => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  settings,
  onSettingsUpdated,
  onBack,
  onLockNow,
  onDataRestored,
}) => {
  const lang = settings.language;
  const t = translations[lang];

  // PIN setup
  const [pinInput, setPinInput] = useState('');
  const [pinConfirm, setPinConfirm] = useState('');
  const [pinMsg, setPinMsg] = useState('');

  // Biometrics
  const [bioSupported, setBioSupported] = useState(false);
  const [bioMsg, setBioMsg] = useState('');

  // Backup passphrase & messages
  const [passphrase, setPassphrase] = useState('');
  const [backupStatus, setBackupStatus] = useState('');
  const [backupError, setBackupError] = useState('');
  const [busy, setBusy] = useState(false);

  // Restore flow modal
  const restoreFileRef = useRef<HTMLInputElement | null>(null);
  const [pendingEnvelope, setPendingEnvelope] = useState<EncryptedBackupEnvelope | null>(null);
  const [restorePassphrase, setRestorePassphrase] = useState('');
  const [restoreError, setRestoreError] = useState('');
  const [verifiedPayload, setVerifiedPayload] = useState<DecryptedBackupPayload | null>(null);

  // Google Drive state
  const [driveUser, setDriveUser] = useState<User | null>(null);
  const [driveToken, setDriveToken] = useState<string | null>(() => getDriveAccessToken());
  const [driveFiles, setDriveFiles] = useState<DriveBackupFile[]>([]);
  const [driveLoading, setDriveLoading] = useState(false);
  const [driveFileToDelete, setDriveFileToDelete] = useState<DriveBackupFile | null>(null);

  useRegisterBackOverlay(pendingEnvelope !== null, () => {
    setPendingEnvelope(null);
    setVerifiedPayload(null);
    setRestorePassphrase('');
    setRestoreError('');
  });

  useEffect(() => {
    isBiometricSupported().then(setBioSupported);
    const unsub = initDriveAuth(
      (user, token) => {
        setDriveUser(user);
        setDriveToken(token);
      },
      () => {
        setDriveUser(null);
        setDriveToken(null);
        setDriveFiles([]);
      }
    );
    return () => unsub();
  }, []);

  const handleLanguageChange = async (language: Language) => {
    const updated = await saveSettings({ language });
    onSettingsUpdated(updated);
  };

  const handleThemeChange = async (theme: ThemeMode) => {
    const updated = await saveSettings({ theme });
    onSettingsUpdated(updated);
  };

  const handleEnablePin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!/^\d{4,6}$/.test(pinInput) || pinInput !== pinConfirm) {
      setPinMsg(t.pinMismatch);
      return;
    }
    const salt = generateSalt();
    const hash = await hashPin(pinInput, salt);
    const updated = await saveSettings({
      pinEnabled: true,
      pinSalt: salt,
      pinHash: hash,
    });
    setPinInput('');
    setPinConfirm('');
    setPinMsg('');
    onSettingsUpdated(updated);
  };

  const handleDisablePin = async () => {
    const updated = await saveSettings({
      pinEnabled: false,
      pinSalt: null,
      pinHash: null,
      biometricEnabled: false,
      biometricCredentialId: null,
    });
    onSettingsUpdated(updated);
  };

  const handleEnableBiometric = async () => {
    setBioMsg('');
    try {
      const credId = await registerBiometricCredential();
      const updated = await saveSettings({
        biometricEnabled: true,
        biometricCredentialId: credId,
      });
      onSettingsUpdated(updated);
    } catch {
      setBioMsg(t.biometricFailed);
    }
  };

  const handleDisableBiometric = async () => {
    const updated = await saveSettings({
      biometricEnabled: false,
      biometricCredentialId: null,
    });
    onSettingsUpdated(updated);
  };

  const handleToggleMediaEncryption = async () => {
    const updated = await saveSettings({
      encryptLocalMedia: !settings.encryptLocalMedia,
    });
    onSettingsUpdated(updated);
  };

  const buildEncryptedBackupJson = async (): Promise<{
    fileName: string;
    jsonString: string;
  }> => {
    const payload = await exportFullDatabasePayload();
    const envelope = await encryptBackupPayload(payload, passphrase);
    const stamp = new Date().toISOString().slice(0, 10);
    return {
      fileName: `trimool-ayurveda-backup-${stamp}.trimool-backup.json`,
      jsonString: JSON.stringify(envelope),
    };
  };

  const handleSaveLocalBackup = async () => {
    setBackupError('');
    setBackupStatus('');
    if (passphrase.length < 6) {
      setBackupError(t.passphraseTooShort);
      return;
    }
    setBusy(true);
    try {
      const { fileName, jsonString } = await buildEncryptedBackupJson();
      const win = window as unknown as {
        showSaveFilePicker?: (opts: unknown) => Promise<{
          createWritable: () => Promise<{
            write: (data: string) => Promise<void>;
            close: () => Promise<void>;
          }>;
        }>;
      };

      if (isNativeApp()) {
        await saveBackupFileOnNative(fileName, jsonString, t.createLocalBackup);
      } else if (typeof win.showSaveFilePicker === 'function') {
        try {
          const handle = await win.showSaveFilePicker({
            suggestedName: fileName,
            types: [
              {
                description: 'TRIMOOL AYURVEDA Encrypted Backup',
                accept: { 'application/json': ['.json'] },
              },
            ],
          });
          const writable = await handle.createWritable();
          await writable.write(jsonString);
          await writable.close();
        } catch (err) {
          // If user cancelled picker, abort cleanly; otherwise fall back to download
          if ((err as { name?: string })?.name === 'AbortError') {
            setBusy(false);
            return;
          }
          const blob = new Blob([jsonString], { type: 'application/json' });
          const url = URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url;
          a.download = fileName;
          a.click();
          URL.revokeObjectURL(url);
        }
      } else {
        const blob = new Blob([jsonString], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = fileName;
        a.click();
        URL.revokeObjectURL(url);
      }

      const updated = await saveSettings({ lastBackupAt: new Date().toISOString() });
      onSettingsUpdated(updated);
      setBackupStatus(t.backupSuccess);
    } catch {
      setBackupError(t.wrongPassphrase);
    } finally {
      setBusy(false);
    }
  };

  const handleLocalFileSelected = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    try {
      const text = await file.text();
      const parsed = JSON.parse(text) as EncryptedBackupEnvelope;
      setPendingEnvelope(parsed);
      setRestorePassphrase('');
      setRestoreError('');
      setVerifiedPayload(null);
    } catch {
      setBackupError(t.wrongPassphrase);
    }
  };

  const handleVerifyBackup = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!pendingEnvelope) return;
    setRestoreError('');
    try {
      const decoded = await decryptBackupPayload(pendingEnvelope, restorePassphrase);
      setVerifiedPayload(decoded);
    } catch {
      setRestoreError(t.wrongPassphrase);
    }
  };

  const handleConfirmRestore = async () => {
    if (!verifiedPayload) return;
    setBusy(true);
    try {
      await restoreFullDatabasePayload(verifiedPayload, settings.encryptLocalMedia);
      setPendingEnvelope(null);
      setVerifiedPayload(null);
      setRestorePassphrase('');
      setBackupStatus(t.restoreSuccess);
      onDataRestored();
    } finally {
      setBusy(false);
    }
  };

  const handleGoogleSignIn = async () => {
    setBackupError('');
    try {
      const res = await signInWithGoogleForDrive();
      setDriveUser(res.user);
      setDriveToken(res.accessToken);
      setDriveLoading(true);
      const files = await listDriveBackups(res.accessToken);
      setDriveFiles(files);
    } catch (err) {
      setBackupError((err as Error)?.message || 'Google sign-in failed');
    } finally {
      setDriveLoading(false);
    }
  };

  const handleRefreshDrive = async () => {
    if (!driveToken) return;
    setDriveLoading(true);
    setBackupError('');
    try {
      const files = await listDriveBackups(driveToken);
      setDriveFiles(files);
    } catch (err) {
      setBackupError((err as Error)?.message || 'Failed to load Drive files');
    } finally {
      setDriveLoading(false);
    }
  };

  const handleUploadDrive = async () => {
    if (!driveToken) return;
    setBackupError('');
    setBackupStatus('');
    if (passphrase.length < 6) {
      setBackupError(t.passphraseTooShort);
      return;
    }
    setBusy(true);
    try {
      const { fileName, jsonString } = await buildEncryptedBackupJson();
      await uploadEncryptedBackupToDrive(driveToken, fileName, jsonString);
      const updated = await saveSettings({ lastBackupAt: new Date().toISOString() });
      onSettingsUpdated(updated);
      setBackupStatus(t.driveUploadSuccess);
      await handleRefreshDrive();
    } catch (err) {
      setBackupError((err as Error)?.message || 'Google Drive upload failed');
    } finally {
      setBusy(false);
    }
  };

  const handleSelectDriveRestore = async (fileId: string) => {
    if (!driveToken) return;
    setBusy(true);
    setBackupError('');
    try {
      const text = await downloadDriveBackup(driveToken, fileId);
      const parsed = JSON.parse(text) as EncryptedBackupEnvelope;
      setPendingEnvelope(parsed);
      setRestorePassphrase('');
      setRestoreError('');
      setVerifiedPayload(null);
    } catch {
      setBackupError(t.wrongPassphrase);
    } finally {
      setBusy(false);
    }
  };

  const handleConfirmDeleteDriveFile = async () => {
    if (!driveToken || !driveFileToDelete) return;
    await deleteDriveBackup(driveToken, driveFileToDelete.id);
    setDriveFiles((prev) => prev.filter((f) => f.id !== driveFileToDelete.id));
    setDriveFileToDelete(null);
  };

  return (
    <div className="mx-auto max-w-3xl space-y-6 pb-8">
      {/* Header */}
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={onBack}
            className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl border border-emerald-950/10 dark:border-emerald-200/15 bg-white dark:bg-[#132219] text-slate-700 dark:text-slate-200 hover:bg-emerald-50 dark:hover:bg-emerald-950/50 transition-colors cursor-pointer"
            aria-label={t.backHome}
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h2 className="text-xl font-bold text-slate-900 dark:text-slate-100">
            {t.settingsTitle}
          </h2>
        </div>

        <PWAInstallButton language={lang} />
      </div>

      {/* 1. Language & Colour Theme */}
      <section className="rounded-2xl bg-white dark:bg-[#132219] border border-emerald-950/10 dark:border-emerald-200/10 p-6 shadow-xs space-y-5">
        <h3 className="text-base font-bold text-slate-900 dark:text-slate-100">
          {t.appearanceAndLanguage}
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <span className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-2">
              {t.languageLabel}
            </span>
            <div className="grid grid-cols-2 gap-1.5 p-1 rounded-xl bg-slate-100 dark:bg-[#0B1510] border border-slate-200 dark:border-emerald-200/15">
              <button
                type="button"
                onClick={() => handleLanguageChange('en')}
                className={`min-h-[44px] rounded-lg text-sm font-semibold transition-colors cursor-pointer ${
                  lang === 'en'
                    ? 'bg-[#14532D] text-white dark:bg-emerald-700'
                    : 'text-slate-700 dark:text-slate-300'
                }`}
              >
                English
              </button>
              <button
                type="button"
                onClick={() => handleLanguageChange('hi')}
                className={`min-h-[44px] rounded-lg text-sm font-semibold transition-colors cursor-pointer ${
                  lang === 'hi'
                    ? 'bg-[#14532D] text-white dark:bg-emerald-700'
                    : 'text-slate-700 dark:text-slate-300'
                }`}
              >
                हिंदी
              </button>
            </div>
          </div>

          <div>
            <span className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-2">
              {t.themeLabel}
            </span>
            <div className="grid grid-cols-2 gap-1.5 p-1 rounded-xl bg-slate-100 dark:bg-[#0B1510] border border-slate-200 dark:border-emerald-200/15">
              <button
                type="button"
                onClick={() => handleThemeChange('light')}
                className={`min-h-[44px] flex items-center justify-center gap-2 rounded-lg text-sm font-semibold transition-colors cursor-pointer ${
                  settings.theme === 'light'
                    ? 'bg-[#14532D] text-white dark:bg-emerald-700'
                    : 'text-slate-700 dark:text-slate-300'
                }`}
              >
                <Sun className="w-4 h-4" />
                <span>{t.lightMode}</span>
              </button>
              <button
                type="button"
                onClick={() => handleThemeChange('dark')}
                className={`min-h-[44px] flex items-center justify-center gap-2 rounded-lg text-sm font-semibold transition-colors cursor-pointer ${
                  settings.theme === 'dark'
                    ? 'bg-[#14532D] text-white dark:bg-emerald-700'
                    : 'text-slate-700 dark:text-slate-300'
                }`}
              >
                <Moon className="w-4 h-4" />
                <span>{t.darkMode}</span>
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* 2. Security & Privacy */}
      <section className="rounded-2xl bg-white dark:bg-[#132219] border border-emerald-950/10 dark:border-emerald-200/10 p-6 shadow-xs space-y-5">
        <div className="flex items-center gap-2">
          <ShieldCheck className="w-5 h-5 text-emerald-800 dark:text-emerald-300" />
          <h3 className="text-base font-bold text-slate-900 dark:text-slate-100">
            {t.securitySection}
          </h3>
        </div>

        {/* PIN Lock */}
        <div className="pt-2 border-t border-slate-100 dark:border-emerald-200/10 space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div>
              <p className="text-sm font-semibold text-slate-900 dark:text-slate-100">
                {t.appPinLock}
              </p>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {settings.pinEnabled ? t.pinEnabledLabel : t.pinDisabledLabel}
              </p>
            </div>
            {settings.pinEnabled && (
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={onLockNow}
                  className="min-h-[40px] inline-flex items-center gap-1.5 rounded-xl bg-[#14532D] text-white px-3.5 py-2 text-xs font-semibold cursor-pointer"
                >
                  <Lock className="w-3.5 h-3.5" />
                  <span>{t.lockApp}</span>
                </button>
                <button
                  type="button"
                  onClick={handleDisablePin}
                  className="min-h-[40px] rounded-xl border border-red-200 dark:border-red-900/50 text-red-700 dark:text-red-300 px-3.5 py-2 text-xs font-semibold cursor-pointer"
                >
                  {t.disablePin}
                </button>
              </div>
            )}
          </div>

          {!settings.pinEnabled && (
            <form onSubmit={handleEnablePin} className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
              <input
                type="password"
                inputMode="numeric"
                maxLength={6}
                value={pinInput}
                onChange={(e) => setPinInput(e.target.value.replace(/\D/g, ''))}
                placeholder={t.setPinPlaceholder}
                className="min-h-[44px] rounded-xl border border-slate-300 dark:border-emerald-200/20 bg-white dark:bg-[#0B1510] px-3.5 py-2 text-sm tabular-nums text-slate-900 dark:text-slate-100"
              />
              <input
                type="password"
                inputMode="numeric"
                maxLength={6}
                value={pinConfirm}
                onChange={(e) => setPinConfirm(e.target.value.replace(/\D/g, ''))}
                placeholder={t.confirmPinPlaceholder}
                className="min-h-[44px] rounded-xl border border-slate-300 dark:border-emerald-200/20 bg-white dark:bg-[#0B1510] px-3.5 py-2 text-sm tabular-nums text-slate-900 dark:text-slate-100"
              />
              <button
                type="submit"
                className="min-h-[44px] inline-flex items-center justify-center gap-2 rounded-xl bg-[#14532D] hover:bg-[#166534] dark:bg-emerald-700 text-white px-4 py-2 text-sm font-semibold cursor-pointer"
              >
                <KeyRound className="w-4 h-4" />
                <span>{t.enablePin}</span>
              </button>
            </form>
          )}
          {pinMsg && <p className="text-xs font-medium text-red-700 dark:text-red-300">{pinMsg}</p>}
        </div>

        {/* Biometric Authentication */}
        <div className="pt-4 border-t border-slate-100 dark:border-emerald-200/10 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <p className="text-sm font-semibold text-slate-900 dark:text-slate-100">
              {t.biometricLock}
            </p>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              {bioSupported ? t.biometricSupportedHint : t.biometricUnsupportedHint}
            </p>
            {bioMsg && (
              <p className="mt-1 text-xs font-medium text-red-700 dark:text-red-300">{bioMsg}</p>
            )}
          </div>

          {bioSupported && settings.pinEnabled && (
            settings.biometricEnabled ? (
              <button
                type="button"
                onClick={handleDisableBiometric}
                className="min-h-[44px] shrink-0 rounded-xl border border-red-200 dark:border-red-900/50 px-4 py-2 text-xs font-semibold text-red-700 dark:text-red-300 cursor-pointer"
              >
                {t.disableBiometric}
              </button>
            ) : (
              <button
                type="button"
                onClick={handleEnableBiometric}
                className="min-h-[44px] shrink-0 inline-flex items-center gap-2 rounded-xl border border-emerald-800/25 dark:border-emerald-300/25 px-4 py-2 text-xs font-semibold text-emerald-950 dark:text-emerald-100 hover:bg-emerald-50 dark:hover:bg-emerald-950/50 cursor-pointer"
              >
                <Fingerprint className="w-4 h-4" />
                <span>{t.enableBiometric}</span>
              </button>
            )
          )}
        </div>

        {/* Local Media AES-256-GCM Encryption */}
        <div className="pt-4 border-t border-slate-100 dark:border-emerald-200/10 flex items-center justify-between gap-3">
          <div>
            <p className="text-sm font-semibold text-slate-900 dark:text-slate-100">
              {t.encryptLocalPhotos}
            </p>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              {t.encryptLocalPhotosHint}
            </p>
          </div>
          <button
            type="button"
            onClick={handleToggleMediaEncryption}
            className={`min-h-[40px] shrink-0 rounded-xl px-4 py-2 text-xs font-semibold transition-colors cursor-pointer ${
              settings.encryptLocalMedia
                ? 'bg-[#14532D] text-white dark:bg-emerald-700'
                : 'border border-slate-300 dark:border-emerald-200/20 text-slate-700 dark:text-slate-300'
            }`}
          >
            {settings.encryptLocalMedia ? t.enabled : t.disabled}
          </button>
        </div>
      </section>

      {/* 3. Encrypted Local Backup & Restore */}
      <section className="rounded-2xl bg-white dark:bg-[#132219] border border-emerald-950/10 dark:border-emerald-200/10 p-6 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
          <h3 className="text-base font-bold text-slate-900 dark:text-slate-100">
            {t.localBackupSection}
          </h3>
          <span className="text-xs text-slate-500 dark:text-slate-400 tabular-nums">
            {t.lastBackup}:{' '}
            {settings.lastBackupAt
              ? formatDisplayDate(settings.lastBackupAt, lang)
              : t.neverBackedUp}
          </span>
        </div>
        <p className="text-sm text-slate-600 dark:text-slate-300">{t.localBackupDesc}</p>

        <div>
          <label
            htmlFor="backup-passphrase"
            className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5"
          >
            {t.backupPassphrase}
          </label>
          <input
            id="backup-passphrase"
            type="password"
            value={passphrase}
            onChange={(e) => {
              setPassphrase(e.target.value);
              setBackupError('');
            }}
            placeholder={t.passphrasePlaceholder}
            className="w-full min-h-[46px] rounded-xl border border-slate-300 dark:border-emerald-200/20 bg-white dark:bg-[#0B1510] px-4 py-2.5 text-sm text-slate-900 dark:text-slate-100"
          />
        </div>

        {backupError && (
          <p className="text-sm font-medium text-red-700 dark:text-red-300">{backupError}</p>
        )}
        {backupStatus && (
          <p className="text-sm font-medium text-emerald-800 dark:text-emerald-300">
            {backupStatus}
          </p>
        )}

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <button
            type="button"
            disabled={busy}
            onClick={handleSaveLocalBackup}
            className="min-h-[48px] inline-flex items-center justify-center gap-2 rounded-xl bg-[#14532D] hover:bg-[#166534] dark:bg-emerald-700 text-white px-4 py-3 text-sm font-semibold transition-colors cursor-pointer"
          >
            <Download className="w-4 h-4" />
            <span>{t.createLocalBackup}</span>
          </button>

          <button
            type="button"
            disabled={busy}
            onClick={() => restoreFileRef.current?.click()}
            className="min-h-[48px] inline-flex items-center justify-center gap-2 rounded-xl border border-emerald-800/25 dark:border-emerald-300/25 bg-emerald-50/70 dark:bg-emerald-950/40 text-emerald-950 dark:text-emerald-100 px-4 py-3 text-sm font-semibold hover:bg-emerald-100/70 transition-colors cursor-pointer"
          >
            <FolderUp className="w-4 h-4" />
            <span>{t.restoreLocalBackup}</span>
          </button>

          <input
            ref={restoreFileRef}
            type="file"
            accept=".json,application/json,*/*"
            className="hidden"
            onChange={handleLocalFileSelected}
          />
        </div>
        <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
          {t.pwaToAndroidHint}
        </p>
      </section>

      {/* 4. Optional Google Drive Backup */}
      <section className="rounded-2xl bg-white dark:bg-[#132219] border border-emerald-950/10 dark:border-emerald-200/10 p-6 shadow-xs space-y-4">
        <h3 className="text-base font-bold text-slate-900 dark:text-slate-100">
          {t.googleDriveSection}
        </h3>
        <p className="text-sm text-slate-600 dark:text-slate-300">{t.googleDriveDesc}</p>

        {!driveUser || !driveToken ? (
          <div>
            <button type="button" onClick={handleGoogleSignIn} className="gsi-material-button">
              <div className="gsi-material-button-content-wrapper">
                <div className="gsi-material-button-icon">
                  <svg
                    version="1.1"
                    xmlns="http://www.w3.org/2000/svg"
                    viewBox="0 0 48 48"
                    style={{ display: 'block' }}
                  >
                    <path
                      fill="#EA4335"
                      d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"
                    />
                    <path
                      fill="#4285F4"
                      d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"
                    />
                    <path
                      fill="#FBBC05"
                      d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"
                    />
                    <path
                      fill="#34A853"
                      d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"
                    />
                    <path fill="none" d="M0 0h48v48H0z" />
                  </svg>
                </div>
                <span className="gsi-material-button-contents">Sign in with Google</span>
              </div>
            </button>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 rounded-xl bg-emerald-50/70 dark:bg-emerald-950/40 border border-emerald-900/10 dark:border-emerald-200/15 p-3.5">
              <div className="text-sm">
                <span className="text-slate-500 dark:text-slate-400">{t.connectedAs}: </span>
                <span className="font-semibold text-slate-900 dark:text-slate-100">
                  {driveUser.email}
                </span>
              </div>
              <button
                type="button"
                onClick={signOutGoogleDrive}
                className="min-h-[40px] self-start sm:self-auto inline-flex items-center gap-1.5 rounded-lg border border-slate-300 dark:border-emerald-200/20 px-3 py-1.5 text-xs font-medium text-slate-700 dark:text-slate-200 cursor-pointer"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>{t.signOut}</span>
              </button>
            </div>

            <div className="flex flex-wrap gap-2.5">
              <button
                type="button"
                disabled={busy}
                onClick={handleUploadDrive}
                className="min-h-[46px] inline-flex items-center gap-2 rounded-xl bg-[#14532D] hover:bg-[#166534] dark:bg-emerald-700 text-white px-4 py-2.5 text-sm font-semibold cursor-pointer"
              >
                <CloudUpload className="w-4 h-4" />
                <span>{t.uploadToDrive}</span>
              </button>

              <button
                type="button"
                disabled={driveLoading}
                onClick={handleRefreshDrive}
                className="min-h-[46px] inline-flex items-center gap-2 rounded-xl border border-slate-300 dark:border-emerald-200/20 px-4 py-2.5 text-sm font-medium text-slate-700 dark:text-slate-200 cursor-pointer"
              >
                <RefreshCw className={`w-4 h-4 ${driveLoading ? 'animate-spin' : ''}`} />
                <span>{t.refreshDriveBackups}</span>
              </button>
            </div>

            {driveFiles.length === 0 ? (
              <p className="text-xs text-slate-500 dark:text-slate-400">{t.noDriveBackups}</p>
            ) : (
              <div className="rounded-xl border border-slate-200 dark:border-emerald-200/15 divide-y divide-slate-100 dark:divide-emerald-200/10">
                {driveFiles.map((f) => (
                  <div
                    key={f.id}
                    className="p-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-2"
                  >
                    <div className="min-w-0">
                      <p className="text-sm font-semibold text-slate-900 dark:text-slate-100 truncate">
                        {f.name}
                      </p>
                      <p className="text-xs text-slate-500 dark:text-slate-400 tabular-nums">
                        {formatDisplayDate(f.createdTime, lang)}
                      </p>
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      <button
                        type="button"
                        onClick={() => handleSelectDriveRestore(f.id)}
                        className="min-h-[40px] inline-flex items-center gap-1.5 rounded-lg bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-800/20 px-3 py-1.5 text-xs font-semibold text-emerald-900 dark:text-emerald-200 cursor-pointer"
                      >
                        <HardDriveDownload className="w-3.5 h-3.5" />
                        <span>{t.restoreFromDrive}</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => setDriveFileToDelete(f)}
                        className="min-h-[40px] inline-flex items-center gap-1 rounded-lg border border-red-200 dark:border-red-900/50 px-3 py-1.5 text-xs font-semibold text-red-700 dark:text-red-300 cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        <span>{t.deleteFromDrive}</span>
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </section>

      {/* 5. Android Studio Project Info (shown on Web/PWA only) */}
      {!isNativeApp() && (
        <section className="rounded-2xl bg-white dark:bg-[#132219] border border-emerald-950/10 dark:border-emerald-200/10 p-6 shadow-xs space-y-3">
          <h3 className="text-base font-bold text-slate-900 dark:text-slate-100">
            {t.androidExportSection}
          </h3>
          <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
            {t.androidExportDesc}
          </p>
          <div className="flex flex-wrap gap-3">
            <a
              href="/TRIMOOL_AYURVEDA_Capacitor_Android.zip"
              download="TRIMOOL_AYURVEDA_Capacitor_Android.zip"
              className="min-h-[44px] inline-flex items-center gap-2 rounded-xl bg-[#14532D] hover:bg-[#166534] dark:bg-emerald-700 px-4 py-2 text-sm font-semibold text-white transition-colors"
            >
              <Download className="w-4 h-4" />
              <span>TRIMOOL_AYURVEDA_Capacitor_Android.zip</span>
            </a>
            <a
              href="/TRIMOOL_AYURVEDA_Android_Project.zip"
              download="TRIMOOL_AYURVEDA_Android_Project.zip"
              className="min-h-[44px] inline-flex items-center gap-2 rounded-xl border border-emerald-800/25 dark:border-emerald-300/25 bg-emerald-50/70 dark:bg-emerald-950/40 px-4 py-2 text-sm font-semibold text-emerald-950 dark:text-emerald-100 hover:bg-emerald-100/70 transition-colors"
            >
              <Download className="w-4 h-4" />
              <span>TRIMOOL_AYURVEDA_Android_Project.zip</span>
            </a>
          </div>
        </section>
      )}

      {/* Decrypt & Confirm Restore Modal */}
      {pendingEnvelope && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4"
          role="dialog"
          aria-modal="true"
        >
          <div className="w-full max-w-md rounded-2xl bg-white dark:bg-[#132219] border border-emerald-950/10 dark:border-emerald-200/10 p-6 shadow-xl space-y-4">
            <h3 className="text-lg font-bold text-slate-900 dark:text-slate-100">
              {t.restoreModalTitle}
            </h3>

            {!verifiedPayload ? (
              <form onSubmit={handleVerifyBackup} className="space-y-4">
                <p className="text-sm text-slate-600 dark:text-slate-300">
                  {t.restorePassphrasePrompt}
                </p>
                <input
                  type="password"
                  autoFocus
                  value={restorePassphrase}
                  onChange={(e) => {
                    setRestorePassphrase(e.target.value);
                    setRestoreError('');
                  }}
                  placeholder={t.passphrasePlaceholder}
                  className="w-full min-h-[46px] rounded-xl border border-slate-300 dark:border-emerald-200/20 bg-white dark:bg-[#0B1510] px-4 py-2.5 text-sm text-slate-900 dark:text-slate-100"
                />
                {restoreError && (
                  <p className="text-sm font-medium text-red-700 dark:text-red-300">
                    {restoreError}
                  </p>
                )}
                <div className="flex justify-end gap-2.5">
                  <button
                    type="button"
                    onClick={() => setPendingEnvelope(null)}
                    className="min-h-[44px] rounded-xl border border-slate-200 dark:border-emerald-200/15 px-4 py-2 text-sm font-medium cursor-pointer"
                  >
                    {t.cancel}
                  </button>
                  <button
                    type="submit"
                    className="min-h-[44px] rounded-xl bg-[#14532D] text-white px-5 py-2 text-sm font-semibold cursor-pointer"
                  >
                    {t.decryptAndVerify}
                  </button>
                </div>
              </form>
            ) : (
              <div className="space-y-4">
                <p className="text-sm text-slate-700 dark:text-slate-200">
                  {t.restoreConfirmSummary}
                </p>
                <div className="grid grid-cols-3 gap-2 rounded-xl bg-emerald-50/70 dark:bg-emerald-950/40 p-3 text-center tabular-nums">
                  <div>
                    <div className="text-lg font-bold text-slate-900 dark:text-slate-100">
                      {verifiedPayload.patients.length}
                    </div>
                    <div className="text-xs text-slate-600 dark:text-slate-300">
                      {t.patientsCountLabel}
                    </div>
                  </div>
                  <div>
                    <div className="text-lg font-bold text-slate-900 dark:text-slate-100">
                      {verifiedPayload.visits.length}
                    </div>
                    <div className="text-xs text-slate-600 dark:text-slate-300">
                      {t.visitsCountLabel}
                    </div>
                  </div>
                  <div>
                    <div className="text-lg font-bold text-slate-900 dark:text-slate-100">
                      {verifiedPayload.prescriptionImages.length +
                        verifiedPayload.reportImages.length}
                    </div>
                    <div className="text-xs text-slate-600 dark:text-slate-300">
                      {t.imagesCountLabel}
                    </div>
                  </div>
                </div>
                <p className="text-xs text-amber-800 dark:text-amber-300">
                  {t.restoreReplaceWarning}
                </p>
                <div className="flex justify-end gap-2.5">
                  <button
                    type="button"
                    onClick={() => setPendingEnvelope(null)}
                    className="min-h-[44px] rounded-xl border border-slate-200 dark:border-emerald-200/15 px-4 py-2 text-sm font-medium cursor-pointer"
                  >
                    {t.cancel}
                  </button>
                  <button
                    type="button"
                    disabled={busy}
                    onClick={handleConfirmRestore}
                    className="min-h-[44px] rounded-xl bg-[#14532D] hover:bg-[#166534] text-white px-5 py-2 text-sm font-semibold cursor-pointer"
                  >
                    {t.confirmRestore}
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Confirm Delete Drive Backup */}
      <ConfirmDialog
        open={driveFileToDelete !== null}
        title={t.deleteDriveConfirmTitle}
        description={t.deleteDriveConfirmDesc}
        confirmLabel={t.confirmDelete}
        cancelLabel={t.cancel}
        onConfirm={handleConfirmDeleteDriveFile}
        onCancel={() => setDriveFileToDelete(null)}
      />
    </div>
  );
};

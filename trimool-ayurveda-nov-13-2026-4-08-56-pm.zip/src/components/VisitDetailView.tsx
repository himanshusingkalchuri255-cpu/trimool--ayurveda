import React, { useEffect, useRef, useState } from 'react';
import {
  ArrowLeft,
  Calendar,
  Camera,
  Check,
  FileText,
  ImagePlus,
  Pill,
  Trash2,
} from 'lucide-react';
import {
  addMedicalImages,
  deleteMedicalImage,
  deleteVisitCascade,
  getVisitWithImages,
  updateVisitDate,
  type DecryptedMedicalImage,
} from '../db/database';
import { formatDisplayDate, translations } from '../i18n/translations';
import type { ImageCategory, Language, Patient, Visit } from '../types';
import {
  capturePhotoWithNativeCamera,
  isNativeApp,
  pickPhotosFromNativeGallery,
} from '../utils/platform';
import { CameraCaptureModal } from './CameraCaptureModal';
import { ConfirmDialog } from './ConfirmDialog';
import { PhotoViewerModal } from './PhotoViewerModal';

interface VisitDetailViewProps {
  visitId: string;
  language: Language;
  encryptLocalMedia: boolean;
  onBackToProfile: (patientId: string) => void;
}

export const VisitDetailView: React.FC<VisitDetailViewProps> = ({
  visitId,
  language,
  encryptLocalMedia,
  onBackToProfile,
}) => {
  const t = translations[language];

  const [visit, setVisit] = useState<Visit | null>(null);
  const [patient, setPatient] = useState<Patient | null>(null);
  const [prescriptions, setPrescriptions] = useState<DecryptedMedicalImage[]>([]);
  const [reports, setReports] = useState<DecryptedMedicalImage[]>([]);
  const [loading, setLoading] = useState(true);

  // Separate active section tab (never mixed!)
  const [activeCategory, setActiveCategory] = useState<ImageCategory>('prescription');

  // Visit date editing
  const [editingDate, setEditingDate] = useState(false);
  const [dateInput, setDateInput] = useState('');

  // Camera & Gallery controls
  const [cameraCategory, setCameraCategory] = useState<ImageCategory | null>(null);
  const rxGalleryInputRef = useRef<HTMLInputElement | null>(null);
  const repGalleryInputRef = useRef<HTMLInputElement | null>(null);

  // Fullscreen viewer
  const [viewerState, setViewerState] = useState<{
    category: ImageCategory;
    index: number;
  } | null>(null);

  // Confirmations
  const [confirmDeleteVisit, setConfirmDeleteVisit] = useState(false);
  const [photoToDelete, setPhotoToDelete] = useState<DecryptedMedicalImage | null>(null);

  const loadVisit = async () => {
    setLoading(true);
    try {
      const data = await getVisitWithImages(visitId);
      setVisit(data.visit);
      setPatient(data.patient);
      setPrescriptions(data.prescriptions);
      setReports(data.reports);
      if (data.visit) {
        setDateInput(data.visit.visitDate);
      }
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadVisit();
  }, [visitId]);

  const handleSaveDate = async () => {
    if (!visit || !dateInput) return;
    const updated = await updateVisitDate(visit.id, dateInput);
    setVisit(updated);
    setEditingDate(false);
  };

  const handleDeleteVisit = async () => {
    if (!visit) return;
    const pid = visit.patientId;
    await deleteVisitCascade(visit.id);
    setConfirmDeleteVisit(false);
    onBackToProfile(pid);
  };

  const readFileAsDataUrl = (file: File): Promise<{
    dataUrl: string;
    fileName: string;
    mimeType: string;
    sizeBytes: number;
  }> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => {
        if (typeof reader.result === 'string') {
          resolve({
            dataUrl: reader.result,
            fileName: file.name || `photo_${Date.now()}.jpg`,
            mimeType: file.type || 'image/jpeg',
            sizeBytes: file.size,
          });
        } else {
          reject(new Error('Failed to read file'));
        }
      };
      reader.onerror = () => reject(reader.error);
      reader.readAsDataURL(file);
    });
  };

  const handleGallerySelection = async (
    e: React.ChangeEvent<HTMLInputElement>,
    category: ImageCategory
  ) => {
    const fileList = e.target.files;
    if (!fileList || fileList.length === 0 || !visit) return;
    const files = Array.from(fileList);
    const encoded = await Promise.all(files.map(readFileAsDataUrl));
    const added = await addMedicalImages(
      visit.id,
      visit.patientId,
      category,
      encoded,
      encryptLocalMedia
    );
    if (category === 'prescription') {
      setPrescriptions((prev) => [...prev, ...added]);
    } else {
      setReports((prev) => [...prev, ...added]);
    }
    e.target.value = '';
  };

  const handleCameraSave = async (
    file: { dataUrl: string; fileName: string; mimeType: string; sizeBytes: number }
  ) => {
    if (!visit || !cameraCategory) return;
    const added = await addMedicalImages(
      visit.id,
      visit.patientId,
      cameraCategory,
      [file],
      encryptLocalMedia
    );
    if (cameraCategory === 'prescription') {
      setPrescriptions((prev) => [...prev, ...added]);
    } else {
      setReports((prev) => [...prev, ...added]);
    }
  };

  const handleCaptureCameraClick = async () => {
    if (!visit) return;
    if (isNativeApp()) {
      try {
        const captured = await capturePhotoWithNativeCamera(activeCategory);
        if (!captured) return;
        const added = await addMedicalImages(
          visit.id,
          visit.patientId,
          activeCategory,
          [captured],
          encryptLocalMedia
        );
        if (activeCategory === 'prescription') {
          setPrescriptions((prev) => [...prev, ...added]);
        } else {
          setReports((prev) => [...prev, ...added]);
        }
        return;
      } catch {
        // Fallback to in-app WebView modal if native camera plugin fails
      }
    }
    setCameraCategory(activeCategory);
  };

  const handlePickGalleryClick = async () => {
    if (!visit) return;
    if (isNativeApp()) {
      try {
        const picked = await pickPhotosFromNativeGallery(activeCategory);
        if (picked.length === 0) return;
        const added = await addMedicalImages(
          visit.id,
          visit.patientId,
          activeCategory,
          picked,
          encryptLocalMedia
        );
        if (activeCategory === 'prescription') {
          setPrescriptions((prev) => [...prev, ...added]);
        } else {
          setReports((prev) => [...prev, ...added]);
        }
        return;
      } catch {
        // Fallback to WebView file chooser if native photo picker fails
      }
    }
    if (activeCategory === 'prescription') {
      rxGalleryInputRef.current?.click();
    } else {
      repGalleryInputRef.current?.click();
    }
  };

  const handleConfirmDeletePhoto = async () => {
    if (!photoToDelete) return;
    await deleteMedicalImage(photoToDelete.id, photoToDelete.category);
    if (photoToDelete.category === 'prescription') {
      setPrescriptions((prev) => prev.filter((img) => img.id !== photoToDelete.id));
    } else {
      setReports((prev) => prev.filter((img) => img.id !== photoToDelete.id));
    }
    setViewerState(null);
    setPhotoToDelete(null);
  };

  if (loading) {
    return (
      <div className="mx-auto max-w-4xl rounded-2xl bg-white dark:bg-[#132219] border border-emerald-950/10 dark:border-emerald-200/10 p-8 text-center text-sm text-slate-500">
        ...
      </div>
    );
  }

  if (!visit || !patient) {
    return null;
  }

  const currentImages = activeCategory === 'prescription' ? prescriptions : reports;
  const viewerImages =
    viewerState?.category === 'prescription'
      ? prescriptions
      : viewerState?.category === 'report'
      ? reports
      : [];

  return (
    <div className="mx-auto max-w-4xl space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-3 min-w-0">
          <button
            type="button"
            onClick={() => onBackToProfile(patient.id)}
            className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl border border-emerald-950/10 dark:border-emerald-200/15 bg-white dark:bg-[#132219] text-slate-700 dark:text-slate-200 hover:bg-emerald-50 dark:hover:bg-emerald-950/50 transition-colors cursor-pointer"
            aria-label={t.backHome}
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div className="min-w-0">
            <h2 className="text-xl font-bold text-slate-900 dark:text-slate-100 truncate">
              {patient.name}
            </h2>
            <p className="text-xs font-medium text-emerald-800 dark:text-emerald-300 tabular-nums">
              {patient.id} · {t.visitDetails}
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={() => setConfirmDeleteVisit(true)}
          className="min-h-[44px] shrink-0 inline-flex items-center gap-2 rounded-xl border border-red-200 dark:border-red-900/50 px-3.5 py-2 text-sm font-medium text-red-700 dark:text-red-300 hover:bg-red-50 dark:hover:bg-red-950/40 transition-colors cursor-pointer"
        >
          <Trash2 className="w-4 h-4" />
          <span className="hidden sm:inline">{t.deleteVisit}</span>
        </button>
      </div>

      {/* Visit Date Card */}
      <div className="rounded-2xl bg-white dark:bg-[#132219] border border-emerald-950/10 dark:border-emerald-200/10 p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-xs">
        <div className="flex items-center gap-3">
          <div className="h-11 w-11 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 flex items-center justify-center shrink-0">
            <Calendar className="w-5 h-5" />
          </div>
          <div>
            <p className="text-xs text-slate-500 dark:text-slate-400">{t.visitDate}</p>
            {!editingDate ? (
              <p className="text-lg font-bold text-slate-900 dark:text-slate-100 tabular-nums">
                {formatDisplayDate(visit.visitDate, language)}
              </p>
            ) : (
              <div className="mt-1 flex items-center gap-2">
                <input
                  type="date"
                  value={dateInput}
                  onChange={(e) => setDateInput(e.target.value)}
                  className="min-h-[40px] rounded-lg border border-slate-300 dark:border-emerald-200/20 bg-white dark:bg-[#0B1510] px-3 py-1 text-sm text-slate-900 dark:text-slate-100"
                />
                <button
                  type="button"
                  onClick={handleSaveDate}
                  className="min-h-[40px] inline-flex items-center gap-1 rounded-lg bg-[#14532D] hover:bg-[#166534] text-white px-3 py-1.5 text-xs font-semibold cursor-pointer"
                >
                  <Check className="w-4 h-4" />
                  <span>{t.saveDate}</span>
                </button>
              </div>
            )}
          </div>
        </div>

        {!editingDate && (
          <button
            type="button"
            onClick={() => setEditingDate(true)}
            className="min-h-[44px] self-start sm:self-auto rounded-xl border border-slate-200 dark:border-emerald-200/15 px-4 py-2 text-sm font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-emerald-950/40 transition-colors cursor-pointer"
          >
            {t.editVisitDate}
          </button>
        )}
      </div>

      {/* Strictly Separated Section Switcher: PRESCRIPTION vs REPORTS */}
      <div className="grid grid-cols-2 gap-2 p-1.5 rounded-2xl bg-emerald-950/5 dark:bg-[#08100C] border border-emerald-950/10 dark:border-emerald-200/10">
        <button
          type="button"
          onClick={() => setActiveCategory('prescription')}
          className={`min-h-[50px] flex items-center justify-center gap-2 rounded-xl px-4 py-3 text-sm font-bold transition-colors cursor-pointer ${
            activeCategory === 'prescription'
              ? 'bg-[#14532D] text-white shadow-xs dark:bg-emerald-700'
              : 'text-slate-700 dark:text-slate-300 hover:bg-white/60 dark:hover:bg-emerald-950/40'
          }`}
        >
          <Pill className="w-4 h-4 shrink-0" />
          <span className="truncate">{t.prescriptionsTab}</span>
          <span className="tabular-nums opacity-85">({prescriptions.length})</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveCategory('report')}
          className={`min-h-[50px] flex items-center justify-center gap-2 rounded-xl px-4 py-3 text-sm font-bold transition-colors cursor-pointer ${
            activeCategory === 'report'
              ? 'bg-[#14532D] text-white shadow-xs dark:bg-emerald-700'
              : 'text-slate-700 dark:text-slate-300 hover:bg-white/60 dark:hover:bg-emerald-950/40'
          }`}
        >
          <FileText className="w-4 h-4 shrink-0" />
          <span className="truncate">{t.reportsTab}</span>
          <span className="tabular-nums opacity-85">({reports.length})</span>
        </button>
      </div>

      {/* Active Category Panel */}
      <section className="rounded-2xl bg-white dark:bg-[#132219] border border-emerald-950/10 dark:border-emerald-200/10 p-5 sm:p-6 shadow-xs space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h3 className="text-base font-bold text-slate-900 dark:text-slate-100">
              {activeCategory === 'prescription' ? t.prescriptionsTab : t.reportsTab}
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              {t.photoSavedTo}: {patient.id} · {formatDisplayDate(visit.visitDate, language)}
            </p>
          </div>

          <div className="grid grid-cols-2 gap-2.5">
            <button
              type="button"
              onClick={handleCaptureCameraClick}
              className="min-h-[46px] inline-flex items-center justify-center gap-2 rounded-xl bg-[#14532D] hover:bg-[#166534] dark:bg-emerald-700 dark:hover:bg-emerald-600 px-4 py-2.5 text-sm font-semibold text-white transition-colors cursor-pointer"
            >
              <Camera className="w-4 h-4 shrink-0" />
              <span className="truncate">{t.captureFromCamera}</span>
            </button>

            <button
              type="button"
              onClick={handlePickGalleryClick}
              className="min-h-[46px] inline-flex items-center justify-center gap-2 rounded-xl border border-emerald-800/25 dark:border-emerald-300/25 bg-emerald-50/70 dark:bg-emerald-950/50 hover:bg-emerald-100/70 dark:hover:bg-emerald-950/80 px-4 py-2.5 text-sm font-semibold text-emerald-950 dark:text-emerald-100 transition-colors cursor-pointer"
            >
              <ImagePlus className="w-4 h-4 shrink-0" />
              <span className="truncate">{t.uploadFromGallery}</span>
            </button>
          </div>
        </div>

        {/* Dedicated Hidden File Inputs (strictly separate per category) */}
        <input
          ref={rxGalleryInputRef}
          type="file"
          accept="image/*"
          multiple
          className="hidden"
          onChange={(e) => handleGallerySelection(e, 'prescription')}
        />
        <input
          ref={repGalleryInputRef}
          type="file"
          accept="image/*"
          multiple
          className="hidden"
          onChange={(e) => handleGallerySelection(e, 'report')}
        />

        {/* Photo Grid */}
        {currentImages.length === 0 ? (
          <div className="rounded-xl border border-dashed border-slate-300 dark:border-emerald-200/20 p-10 text-center text-sm text-slate-500 dark:text-slate-400">
            {activeCategory === 'prescription' ? t.noPrescriptions : t.noReports}
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3.5">
            {currentImages.map((img, idx) => (
              <div
                key={img.id}
                className="group relative rounded-xl overflow-hidden border border-slate-200 dark:border-emerald-200/15 bg-slate-100 dark:bg-[#0B1510] aspect-[3/4]"
              >
                <button
                  type="button"
                  onClick={() => setViewerState({ category: activeCategory, index: idx })}
                  className="w-full h-full block cursor-pointer focus:outline-none focus:ring-2 focus:ring-emerald-700"
                >
                  <img
                    src={img.dataUrl}
                    alt={img.fileName}
                    className="w-full h-full object-cover"
                  />
                </button>
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    setPhotoToDelete(img);
                  }}
                  className="absolute top-2 right-2 min-h-[36px] min-w-[36px] flex items-center justify-center rounded-lg bg-black/65 hover:bg-red-700 text-white transition-colors cursor-pointer"
                  aria-label={t.deletePhoto}
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        )}
      </section>

      {/* Live Camera Capture Modal */}
      <CameraCaptureModal
        open={cameraCategory !== null}
        category={cameraCategory || 'prescription'}
        language={language}
        onSave={handleCameraSave}
        onClose={() => setCameraCategory(null)}
      />

      {/* Fullscreen Pinch-Zoom Viewer */}
      {viewerState && viewerImages.length > 0 && (
        <PhotoViewerModal
          images={viewerImages}
          initialIndex={viewerState.index}
          language={language}
          onClose={() => setViewerState(null)}
          onRequestDelete={(img) => setPhotoToDelete(img)}
        />
      )}

      {/* Delete Visit Confirmation */}
      <ConfirmDialog
        open={confirmDeleteVisit}
        title={t.deleteVisitConfirmTitle}
        description={t.deleteVisitConfirmDesc}
        confirmLabel={t.confirmDelete}
        cancelLabel={t.cancel}
        onConfirm={handleDeleteVisit}
        onCancel={() => setConfirmDeleteVisit(false)}
      />

      {/* Delete Photo Confirmation */}
      <ConfirmDialog
        open={photoToDelete !== null}
        title={t.deletePhotoTitle}
        description={t.deletePhotoDesc}
        confirmLabel={t.deletePhoto}
        cancelLabel={t.cancel}
        onConfirm={handleConfirmDeletePhoto}
        onCancel={() => setPhotoToDelete(null)}
      />
    </div>
  );
};

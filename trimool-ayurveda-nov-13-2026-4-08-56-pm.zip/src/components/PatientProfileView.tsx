import React, { useEffect, useState } from 'react';
import {
  ArrowLeft,
  CalendarPlus,
  ChevronRight,
  Edit3,
  Trash2,
} from 'lucide-react';
import {
  addVisitForPatient,
  deletePatientCascade,
  getPatientProfileData,
  type VisitSummary,
} from '../db/database';
import { formatDisplayDate, getGenderLabel, translations } from '../i18n/translations';
import type { Language, Patient } from '../types';
import { ConfirmDialog } from './ConfirmDialog';

interface PatientProfileViewProps {
  patientId: string;
  language: Language;
  onBack: () => void;
  onEditPatient: (patient: Patient) => void;
  onOpenVisit: (visitId: string) => void;
  onPatientDeleted: () => void;
}

export const PatientProfileView: React.FC<PatientProfileViewProps> = ({
  patientId,
  language,
  onBack,
  onEditPatient,
  onOpenVisit,
  onPatientDeleted,
}) => {
  const t = translations[language];
  const [patient, setPatient] = useState<Patient | null>(null);
  const [visits, setVisits] = useState<VisitSummary[]>([]);
  const [loading, setLoading] = useState(true);
  const [addingVisit, setAddingVisit] = useState(false);
  const [confirmDeleteOpen, setConfirmDeleteOpen] = useState(false);

  const loadProfile = async () => {
    setLoading(true);
    try {
      const data = await getPatientProfileData(patientId);
      setPatient(data.patient);
      setVisits(data.visits);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadProfile();
  }, [patientId]);

  const handleAddVisit = async () => {
    if (!patient) return;
    setAddingVisit(true);
    try {
      const visit = await addVisitForPatient(patient.id);
      onOpenVisit(visit.id);
    } finally {
      setAddingVisit(false);
    }
  };

  const handleDeletePatient = async () => {
    if (!patient) return;
    await deletePatientCascade(patient.id);
    setConfirmDeleteOpen(false);
    onPatientDeleted();
  };

  if (loading) {
    return (
      <div className="mx-auto max-w-3xl rounded-2xl bg-white dark:bg-[#132219] border border-emerald-950/10 dark:border-emerald-200/10 p-8 text-center text-sm text-slate-500">
        ...
      </div>
    );
  }

  if (!patient) {
    return (
      <div className="mx-auto max-w-3xl space-y-4">
        <button
          type="button"
          onClick={onBack}
          className="min-h-[44px] inline-flex items-center gap-2 rounded-xl border border-emerald-950/10 bg-white px-4 py-2 text-sm font-medium cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>{t.backHome}</span>
        </button>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-3 min-w-0">
          <button
            type="button"
            onClick={onBack}
            className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl border border-emerald-950/10 dark:border-emerald-200/15 bg-white dark:bg-[#132219] text-slate-700 dark:text-slate-200 hover:bg-emerald-50 dark:hover:bg-emerald-950/50 transition-colors cursor-pointer"
            aria-label={t.backHome}
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h2 className="text-xl font-bold text-slate-900 dark:text-slate-100 truncate">
            {t.patientProfile}
          </h2>
        </div>

        <button
          type="button"
          onClick={() => onEditPatient(patient)}
          className="min-h-[44px] shrink-0 inline-flex items-center gap-2 rounded-xl border border-emerald-900/15 dark:border-emerald-200/20 bg-white dark:bg-[#132219] px-4 py-2 text-sm font-medium text-emerald-900 dark:text-emerald-200 hover:bg-emerald-50 dark:hover:bg-emerald-950/50 transition-colors cursor-pointer"
        >
          <Edit3 className="w-4 h-4" />
          <span className="whitespace-nowrap">{t.editPatientDetails}</span>
        </button>
      </div>

      {/* Patient Details Card */}
      <section className="rounded-2xl bg-white dark:bg-[#132219] border border-emerald-950/10 dark:border-emerald-200/10 p-6 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4 pb-5 border-b border-slate-100 dark:border-emerald-200/10">
          <div>
            <p className="text-xs font-semibold text-emerald-800 dark:text-emerald-300 tabular-nums">
              {t.patientId}: {patient.id}
            </p>
            <h3 className="mt-1 text-2xl font-bold text-slate-900 dark:text-slate-100">
              {patient.name}
            </h3>
          </div>
          <button
            type="button"
            onClick={handleAddVisit}
            disabled={addingVisit}
            className="min-h-[48px] shrink-0 inline-flex items-center justify-center gap-2 rounded-xl bg-[#14532D] hover:bg-[#166534] dark:bg-emerald-700 dark:hover:bg-emerald-600 px-5 py-3 text-sm font-semibold text-white transition-colors cursor-pointer"
          >
            <CalendarPlus className="w-5 h-5" />
            <span className="whitespace-nowrap">{t.addNewVisit}</span>
          </button>
        </div>

        <dl className="mt-5 grid grid-cols-2 sm:grid-cols-4 gap-4 text-sm">
          <div>
            <dt className="text-xs text-slate-500 dark:text-slate-400">{t.age}</dt>
            <dd className="mt-0.5 font-semibold text-slate-900 dark:text-slate-100 tabular-nums">
              {patient.age} {t.yearsShort}
            </dd>
          </div>
          <div>
            <dt className="text-xs text-slate-500 dark:text-slate-400">{t.gender}</dt>
            <dd className="mt-0.5 font-semibold text-slate-900 dark:text-slate-100">
              {getGenderLabel(patient.gender, language)}
            </dd>
          </div>
          <div>
            <dt className="text-xs text-slate-500 dark:text-slate-400">{t.mobile}</dt>
            <dd className="mt-0.5 font-semibold text-slate-900 dark:text-slate-100 tabular-nums">
              {patient.mobile || t.noMobile}
            </dd>
          </div>
          <div>
            <dt className="text-xs text-slate-500 dark:text-slate-400">{t.registrationDate}</dt>
            <dd className="mt-0.5 font-semibold text-slate-900 dark:text-slate-100 tabular-nums">
              {formatDisplayDate(patient.registrationDate, language)}
            </dd>
          </div>
          <div className="col-span-2 sm:col-span-4">
            <dt className="text-xs text-slate-500 dark:text-slate-400">{t.address}</dt>
            <dd className="mt-0.5 font-medium text-slate-800 dark:text-slate-200">
              {patient.address || t.noAddress}
            </dd>
          </div>
        </dl>
      </section>

      {/* Visit History */}
      <section className="space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-bold text-slate-900 dark:text-slate-100">
            {t.visitHistory}
          </h3>
          <span className="text-xs font-medium text-slate-500 dark:text-slate-400 tabular-nums">
            {visits.length}
          </span>
        </div>

        {visits.length === 0 ? (
          <div className="rounded-2xl bg-white dark:bg-[#132219] border border-emerald-950/10 dark:border-emerald-200/10 p-6 text-center text-sm text-slate-500 dark:text-slate-400">
            {t.noVisits}
          </div>
        ) : (
          <div className="rounded-2xl bg-white dark:bg-[#132219] border border-emerald-950/10 dark:border-emerald-200/10 divide-y divide-slate-100 dark:divide-emerald-200/10 overflow-hidden shadow-xs">
            {visits.map(({ visit, prescriptionCount, reportCount }) => (
              <button
                key={visit.id}
                type="button"
                onClick={() => onOpenVisit(visit.id)}
                className="w-full min-h-[68px] px-5 py-4 text-left flex items-center justify-between gap-4 hover:bg-emerald-50/60 dark:hover:bg-emerald-950/40 transition-colors cursor-pointer"
              >
                <div className="min-w-0">
                  <div className="text-base font-semibold text-slate-900 dark:text-slate-100 tabular-nums">
                    {formatDisplayDate(visit.visitDate, language)}
                  </div>
                  <div className="mt-1 flex flex-wrap items-center gap-x-2 text-xs text-slate-600 dark:text-slate-300 tabular-nums">
                    <span>
                      {t.prescriptionsCount}: {prescriptionCount}
                    </span>
                    <span aria-hidden="true">·</span>
                    <span>
                      {t.reportsCount}: {reportCount}
                    </span>
                  </div>
                </div>
                <ChevronRight className="w-5 h-5 text-slate-400 shrink-0" />
              </button>
            ))}
          </div>
        )}
      </section>

      {/* Safe Delete Patient */}
      <div className="pt-2 flex justify-end">
        <button
          type="button"
          onClick={() => setConfirmDeleteOpen(true)}
          className="min-h-[44px] inline-flex items-center gap-2 rounded-xl border border-red-200 dark:border-red-900/50 px-4 py-2 text-sm font-medium text-red-700 dark:text-red-300 hover:bg-red-50 dark:hover:bg-red-950/40 transition-colors cursor-pointer"
        >
          <Trash2 className="w-4 h-4" />
          <span>{t.deletePatient}</span>
        </button>
      </div>

      <ConfirmDialog
        open={confirmDeleteOpen}
        title={t.deletePatientConfirmTitle}
        description={t.deletePatientConfirmDesc}
        confirmLabel={t.confirmDelete}
        cancelLabel={t.cancel}
        onConfirm={handleDeletePatient}
        onCancel={() => setConfirmDeleteOpen(false)}
      />
    </div>
  );
};

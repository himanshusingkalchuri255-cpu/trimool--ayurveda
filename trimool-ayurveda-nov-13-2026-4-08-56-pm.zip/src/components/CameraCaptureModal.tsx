import React, { useEffect, useRef, useState } from 'react';
import { Camera, Check, RotateCcw, Upload, X } from 'lucide-react';
import { translations } from '../i18n/translations';
import type { ImageCategory, Language } from '../types';
import { useRegisterBackOverlay } from '../utils/backHandler';

interface CameraCaptureModalProps {
  open: boolean;
  category: ImageCategory;
  language: Language;
  onSave: (file: { dataUrl: string; fileName: string; mimeType: string; sizeBytes: number }) => void;
  onClose: () => void;
}

export const CameraCaptureModal: React.FC<CameraCaptureModalProps> = ({
  open,
  category,
  language,
  onSave,
  onClose,
}) => {
  const t = translations[language];
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const fallbackInputRef = useRef<HTMLInputElement | null>(null);

  const [status, setStatus] = useState<'starting' | 'streaming' | 'preview' | 'error'>('starting');
  const [capturedUrl, setCapturedUrl] = useState<string | null>(null);
  const [capturedSize, setCapturedSize] = useState<number>(0);

  useRegisterBackOverlay(open, () => {
    stopStream();
    onClose();
  });

  const stopStream = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }
  };

  const startCamera = async () => {
    stopStream();
    setCapturedUrl(null);
    setStatus('starting');
    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        setStatus('error');
        return;
      }
      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: { ideal: 'environment' },
          width: { ideal: 1920 },
          height: { ideal: 1080 },
        },
        audio: false,
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play();
      }
      setStatus('streaming');
    } catch {
      setStatus('error');
    }
  };

  useEffect(() => {
    if (open) {
      startCamera();
    } else {
      stopStream();
      setCapturedUrl(null);
    }
    return () => stopStream();
  }, [open]);

  if (!open) return null;

  const handleCapture = () => {
    const video = videoRef.current;
    if (!video) return;
    const width = video.videoWidth || 1280;
    const height = video.videoHeight || 720;
    const canvas = document.createElement('canvas');
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.drawImage(video, 0, 0, width, height);
    const dataUrl = canvas.toDataURL('image/jpeg', 0.92);
    setCapturedUrl(dataUrl);
    setCapturedSize(Math.round((dataUrl.length * 3) / 4));
    stopStream();
    setStatus('preview');
  };

  const handleNativeFallbackFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setCapturedUrl(reader.result);
        setCapturedSize(file.size);
        stopStream();
        setStatus('preview');
      }
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  const handleConfirmSave = () => {
    if (!capturedUrl) return;
    const prefix = category === 'prescription' ? 'prescription' : 'report';
    onSave({
      dataUrl: capturedUrl,
      fileName: `${prefix}_${Date.now()}.jpg`,
      mimeType: 'image/jpeg',
      sizeBytes: capturedSize,
    });
    onClose();
  };

  return (
    <div
      className="fixed inset-0 z-50 flex flex-col bg-black text-white"
      role="dialog"
      aria-modal="true"
    >
      {/* Top Bar */}
      <div className="flex items-center justify-between px-4 py-3 bg-black/80 border-b border-white/10">
        <h2 className="text-base font-semibold truncate">
          {category === 'prescription' ? t.cameraTitlePrescription : t.cameraTitleReport}
        </h2>
        <button
          type="button"
          onClick={() => {
            stopStream();
            onClose();
          }}
          className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl hover:bg-white/10 cursor-pointer"
          aria-label={t.close}
        >
          <X className="w-6 h-6" />
        </button>
      </div>

      {/* Viewfinder / Preview */}
      <div className="relative flex-1 flex items-center justify-center overflow-hidden bg-neutral-950 p-3">
        {status === 'starting' && (
          <p className="text-sm text-neutral-300">{t.cameraStarting}</p>
        )}

        <video
          ref={videoRef}
          playsInline
          muted
          className={`max-h-full max-w-full rounded-xl object-contain ${
            status === 'streaming' ? 'block' : 'hidden'
          }`}
        />

        {status === 'preview' && capturedUrl && (
          <img
            src={capturedUrl}
            alt="Captured preview"
            className="max-h-full max-w-full rounded-xl object-contain"
          />
        )}

        {status === 'error' && (
          <div className="max-w-sm text-center space-y-4 px-4">
            <p className="text-sm text-neutral-200 leading-relaxed">{t.cameraError}</p>
            <button
              type="button"
              onClick={() => fallbackInputRef.current?.click()}
              className="min-h-[48px] w-full flex items-center justify-center gap-2 rounded-xl bg-emerald-700 hover:bg-emerald-600 px-5 py-3 text-sm font-semibold text-white cursor-pointer"
            >
              <Upload className="w-5 h-5" />
              <span>{t.useDeviceCamera}</span>
            </button>
          </div>
        )}

        <input
          ref={fallbackInputRef}
          type="file"
          accept="image/*"
          capture="environment"
          className="hidden"
          onChange={handleNativeFallbackFile}
        />
      </div>

      {/* Bottom Controls */}
      <div className="px-4 py-4 bg-black/90 border-t border-white/10 flex items-center justify-center gap-4">
        {status === 'streaming' && (
          <>
            <button
              type="button"
              onClick={handleCapture}
              className="min-h-[52px] flex items-center gap-2 rounded-full bg-white text-slate-950 px-8 py-3 text-sm font-bold shadow-lg hover:bg-emerald-50 active:scale-95 transition cursor-pointer"
            >
              <Camera className="w-5 h-5" />
              <span>{t.capturePhoto}</span>
            </button>
            <button
              type="button"
              onClick={() => fallbackInputRef.current?.click()}
              className="min-h-[48px] flex items-center gap-2 rounded-xl border border-white/25 px-4 py-2.5 text-xs font-medium text-white hover:bg-white/10 cursor-pointer"
            >
              <Upload className="w-4 h-4" />
              <span>{t.useDeviceCamera}</span>
            </button>
          </>
        )}

        {status === 'preview' && (
          <>
            <button
              type="button"
              onClick={startCamera}
              className="min-h-[48px] flex items-center gap-2 rounded-xl border border-white/25 px-5 py-3 text-sm font-medium text-white hover:bg-white/10 cursor-pointer"
            >
              <RotateCcw className="w-4 h-4" />
              <span>{t.retake}</span>
            </button>
            <button
              type="button"
              onClick={handleConfirmSave}
              className="min-h-[48px] flex items-center gap-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 px-6 py-3 text-sm font-semibold text-white cursor-pointer"
            >
              <Check className="w-5 h-5" />
              <span>{t.savePhoto}</span>
            </button>
          </>
        )}
      </div>
    </div>
  );
};

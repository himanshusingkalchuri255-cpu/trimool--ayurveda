import { useCallback, useEffect, useRef, useState } from 'react';
import { App as CapacitorApp } from '@capacitor/app';
import { SplashScreen } from '@capacitor/splash-screen';
import { StatusBar, Style } from '@capacitor/status-bar';
import { Lock, Search, Settings, UserPlus, Users, WifiOff } from 'lucide-react';
import { LockScreen } from './components/LockScreen';
import { PatientFormView } from './components/PatientFormView';
import { PatientProfileView } from './components/PatientProfileView';
import { SearchPatientView } from './components/SearchPatientView';
import { SettingsView } from './components/SettingsView';
import { TrimoolLogo } from './components/TrimoolLogo';
import { VisitDetailView } from './components/VisitDetailView';
import {
  DEFAULT_SETTINGS,
  getSettings,
  getTotalPatientCount,
} from './db/database';
import { useOnlineStatus } from './hooks/useOnlineStatus';
import { translations } from './i18n/translations';
import type { AppSettings, Patient } from './types';
import { handleOverlayBackPress } from './utils/backHandler';
import { isNativeAndroid, isNativeApp } from './utils/platform';

type Screen =
  | { name: 'home' }
  | { name: 'directory' }
  | { name: 'add_patient' }
  | { name: 'edit_patient'; patient: Patient }
  | { name: 'search' }
  | { name: 'profile'; patientId: string }
  | { name: 'visit'; visitId: string; patientId?: string }
  | { name: 'settings' };

export default function App() {
  const [settings, setSettings] = useState<AppSettings>(DEFAULT_SETTINGS);
  const [settingsLoaded, setSettingsLoaded] = useState(false);
  const [unlocked, setUnlocked] = useState(false);
  const [totalPatients, setTotalPatients] = useState<number>(0);
  const [screen, setScreen] = useState<Screen>({ name: 'home' });
  const isOnline = useOnlineStatus();

  const refreshTotalPatients = useCallback(async () => {
    const count = await getTotalPatientCount();
    setTotalPatients(count);
  }, []);

  useEffect(() => {
    let active = true;
    Promise.all([getSettings(), getTotalPatientCount()]).then(([s, count]) => {
      if (!active) return;
      setSettings(s);
      setTotalPatients(count);
      setUnlocked(!s.pinEnabled);
      setSettingsLoaded(true);
    });
    return () => {
      active = false;
    };
  }, []);

  // Sync Tailwind dark mode class on <html> and native Android StatusBar
  useEffect(() => {
    const root = document.documentElement;
    if (settings.theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }

    if (isNativeAndroid()) {
      StatusBar.setStyle({ style: Style.Dark }).catch(() => {});
      StatusBar.setBackgroundColor({
        color: settings.theme === 'dark' ? '#0B1510' : '#14532D',
      }).catch(() => {});
    }
  }, [settings.theme]);

  // Hide Capacitor splash screen once settings and initial DB check complete
  useEffect(() => {
    if (settingsLoaded && isNativeApp()) {
      SplashScreen.hide({ fadeOutDuration: 200 }).catch(() => {});
    }
  }, [settingsLoaded]);

  const goHome = useCallback(() => {
    refreshTotalPatients();
    setScreen({ name: 'home' });
  }, [refreshTotalPatients]);

  const navStateRef = useRef({
    screen,
    unlocked,
    pinEnabled: settings.pinEnabled,
    goHome,
  });
  navStateRef.current = {
    screen,
    unlocked,
    pinEnabled: settings.pinEnabled,
    goHome,
  };

  // Android hardware back button handling
  useEffect(() => {
    if (!isNativeAndroid()) return;
    let listenerHandle: { remove: () => Promise<void> } | null = null;
    CapacitorApp.addListener('backButton', () => {
      if (handleOverlayBackPress()) {
        return;
      }
      const current = navStateRef.current;
      if (current.pinEnabled && !current.unlocked) {
        CapacitorApp.exitApp();
        return;
      }
      if (current.screen.name === 'home') {
        CapacitorApp.exitApp();
        return;
      }
      if (current.screen.name === 'visit' && current.screen.patientId) {
        setScreen({ name: 'profile', patientId: current.screen.patientId });
        return;
      }
      if (current.screen.name === 'edit_patient') {
        setScreen({ name: 'profile', patientId: current.screen.patient.id });
        return;
      }
      current.goHome();
    }).then((handle) => {
      listenerHandle = handle;
    });

    return () => {
      listenerHandle?.remove();
    };
  }, []);

  const t = translations[settings.language];

  if (!settingsLoaded) {
    return (
      <div className="min-h-screen bg-[#F4F7F5] dark:bg-[#0B1510] flex items-center justify-center">
        <TrimoolLogo className="w-14 h-14" />
      </div>
    );
  }

  if (settings.pinEnabled && !unlocked && settings.pinSalt && settings.pinHash) {
    return (
      <LockScreen
        language={settings.language}
        pinSalt={settings.pinSalt}
        pinHash={settings.pinHash}
        biometricEnabled={settings.biometricEnabled}
        biometricCredentialId={settings.biometricCredentialId}
        onUnlock={() => setUnlocked(true)}
      />
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-[#F4F7F5] dark:bg-[#0B1510] text-slate-900 dark:text-slate-100">
      {/* Compact Top App Bar */}
      <header className="sticky top-0 z-30 bg-white/90 dark:bg-[#111E17]/90 backdrop-blur-md border-b border-emerald-950/10 dark:border-emerald-200/10">
        <div className="mx-auto max-w-5xl px-4 sm:px-6 h-16 flex items-center justify-between gap-4">
          <button
            type="button"
            onClick={goHome}
            className="flex items-center gap-3 text-left cursor-pointer focus:outline-none"
          >
            <TrimoolLogo className="w-9 h-9 shrink-0" />
            <span className="font-display text-lg sm:text-xl font-bold tracking-tight text-[#14532D] dark:text-emerald-200 whitespace-nowrap">
              {t.appName}
            </span>
          </button>

          <div className="flex items-center gap-2 shrink-0">
            {settings.pinEnabled && (
              <button
                type="button"
                onClick={() => setUnlocked(false)}
                className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl border border-emerald-950/10 dark:border-emerald-200/15 text-slate-700 dark:text-slate-200 hover:bg-emerald-50 dark:hover:bg-emerald-950/50 transition-colors cursor-pointer"
                aria-label={t.lockApp}
                title={t.lockApp}
              >
                <Lock className="w-5 h-5" />
              </button>
            )}
            <button
              type="button"
              onClick={() => setScreen({ name: 'settings' })}
              className="min-h-[44px] inline-flex items-center gap-2 rounded-xl border border-emerald-950/10 dark:border-emerald-200/15 bg-white dark:bg-[#132219] px-3.5 py-2 text-sm font-medium text-slate-700 dark:text-slate-200 hover:bg-emerald-50 dark:hover:bg-emerald-950/50 transition-colors cursor-pointer"
              aria-label={t.settings}
            >
              <Settings className="w-4 h-4" />
              <span className="hidden sm:inline whitespace-nowrap">{t.settings}</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 mx-auto w-full max-w-5xl px-4 sm:px-6 py-6 sm:py-10">
        {screen.name === 'home' && (
          <div className="mx-auto max-w-xl sm:max-w-3xl space-y-5">
            {/* Home Screen contains ONLY the three requested main options */}
            {/* Option 1: TOTAL PATIENT */}
            <button
              type="button"
              onClick={() => setScreen({ name: 'directory' })}
              className="w-full rounded-3xl bg-[#14532D] dark:bg-emerald-900 text-white p-7 sm:p-9 shadow-sm hover:bg-[#166534] dark:hover:bg-emerald-800 transition-colors text-left flex items-center justify-between gap-6 cursor-pointer"
            >
              <div>
                <p className="text-sm sm:text-base font-semibold tracking-wide text-emerald-100">
                  {t.totalPatient}
                </p>
                <p className="mt-2 text-5xl sm:text-6xl font-bold tabular-nums tracking-tight">
                  {totalPatients}
                </p>
              </div>
              <div className="h-14 w-14 sm:h-16 sm:w-16 rounded-2xl bg-white/10 flex items-center justify-center shrink-0">
                <Users className="w-7 h-7 sm:w-8 sm:h-8 text-emerald-100" />
              </div>
            </button>

            {/* Option 2 & 3: ADD NEW and SEARCH PATIENT */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-5">
              <button
                type="button"
                onClick={() => setScreen({ name: 'add_patient' })}
                className="min-h-[128px] rounded-3xl bg-white dark:bg-[#132219] border border-emerald-950/10 dark:border-emerald-200/15 p-6 sm:p-7 text-left shadow-xs hover:border-emerald-700/40 hover:bg-emerald-50/40 dark:hover:bg-emerald-950/40 transition-colors flex flex-col justify-between gap-4 cursor-pointer"
              >
                <div className="h-12 w-12 rounded-2xl bg-emerald-100 dark:bg-emerald-950 text-[#14532D] dark:text-emerald-300 flex items-center justify-center">
                  <UserPlus className="w-6 h-6" />
                </div>
                <span className="text-xl font-bold text-slate-900 dark:text-slate-100">
                  {t.addNew}
                </span>
              </button>

              <button
                type="button"
                onClick={() => setScreen({ name: 'search' })}
                className="min-h-[128px] rounded-3xl bg-white dark:bg-[#132219] border border-emerald-950/10 dark:border-emerald-200/15 p-6 sm:p-7 text-left shadow-xs hover:border-emerald-700/40 hover:bg-emerald-50/40 dark:hover:bg-emerald-950/40 transition-colors flex flex-col justify-between gap-4 cursor-pointer"
              >
                <div className="h-12 w-12 rounded-2xl bg-emerald-100 dark:bg-emerald-950 text-[#14532D] dark:text-emerald-300 flex items-center justify-center">
                  <Search className="w-6 h-6" />
                </div>
                <span className="text-xl font-bold text-slate-900 dark:text-slate-100">
                  {t.searchPatient}
                </span>
              </button>
            </div>
          </div>
        )}

        {screen.name === 'directory' && (
          <SearchPatientView
            language={settings.language}
            mode="directory"
            onBack={goHome}
            onSelectPatient={(patientId) => setScreen({ name: 'profile', patientId })}
          />
        )}

        {screen.name === 'search' && (
          <SearchPatientView
            language={settings.language}
            mode="search"
            onBack={goHome}
            onSelectPatient={(patientId) => setScreen({ name: 'profile', patientId })}
          />
        )}

        {screen.name === 'add_patient' && (
          <PatientFormView
            language={settings.language}
            onCancel={goHome}
            onCreated={(patient, firstVisitId) => {
              refreshTotalPatients();
              setScreen({ name: 'visit', visitId: firstVisitId, patientId: patient.id });
            }}
            onUpdated={() => goHome()}
            onOpenExistingPatient={(patientId) => setScreen({ name: 'profile', patientId })}
          />
        )}

        {screen.name === 'edit_patient' && (
          <PatientFormView
            language={settings.language}
            existingPatient={screen.patient}
            onCancel={() =>
              setScreen({ name: 'profile', patientId: screen.patient.id })
            }
            onCreated={() => {}}
            onUpdated={(updated) =>
              setScreen({ name: 'profile', patientId: updated.id })
            }
            onOpenExistingPatient={(patientId) => setScreen({ name: 'profile', patientId })}
          />
        )}

        {screen.name === 'profile' && (
          <PatientProfileView
            patientId={screen.patientId}
            language={settings.language}
            onBack={goHome}
            onEditPatient={(patient) => setScreen({ name: 'edit_patient', patient })}
            onOpenVisit={(visitId) =>
              setScreen({ name: 'visit', visitId, patientId: screen.patientId })
            }
            onPatientDeleted={goHome}
          />
        )}

        {screen.name === 'visit' && (
          <VisitDetailView
            visitId={screen.visitId}
            language={settings.language}
            encryptLocalMedia={settings.encryptLocalMedia}
            onBackToProfile={(patientId) => setScreen({ name: 'profile', patientId })}
          />
        )}

        {screen.name === 'settings' && (
          <SettingsView
            settings={settings}
            onSettingsUpdated={(updated) => setSettings(updated)}
            onBack={goHome}
            onLockNow={() => setUnlocked(false)}
            onDataRestored={() => {
              refreshTotalPatients();
            }}
          />
        )}
      </main>

      {/* Non-intrusive offline indicator only when offline */}
      {!isOnline && (
        <div className="fixed bottom-4 left-4 z-40 flex items-center gap-2 rounded-xl bg-amber-600 px-3.5 py-2 text-xs font-semibold text-white shadow-lg">
          <WifiOff className="w-4 h-4" />
          <span>{t.offlineReady}</span>
        </div>
      )}
    </div>
  );
}

export type Language = 'en' | 'hi';
export type ThemeMode = 'light' | 'dark';
export type Gender = 'Male' | 'Female' | 'Other';
export type ImageCategory = 'prescription' | 'report';

export interface Patient {
  id: string; // e.g. TA-00001
  name: string;
  nameLower: string;
  age: number;
  gender: Gender;
  mobile: string;
  address: string;
  registrationDate: string; // ISO string
  updatedAt: string; // ISO string
}

export interface Visit {
  id: string; // e.g. V-1731400000000-abc1
  patientId: string; // FK -> Patient.id
  visitDate: string; // YYYY-MM-DD
  createdAt: string; // ISO string
}

export interface StoredMedicalImage {
  id: string;
  visitId: string; // FK -> Visit.id
  patientId: string; // FK -> Patient.id
  category: ImageCategory;
  fileName: string;
  mimeType: string;
  sizeBytes: number;
  capturedAt: string; // ISO string
  encrypted: boolean;
  // When encrypted === false: base64 dataUrl; when encrypted === true: AES-GCM envelope JSON string
  payload: string;
}

export interface AppSettings {
  key: 'app_settings';
  language: Language;
  theme: ThemeMode;
  pinEnabled: boolean;
  pinSalt: string | null;
  pinHash: string | null;
  biometricEnabled: boolean;
  biometricCredentialId: string | null;
  encryptLocalMedia: boolean;
  nextPatientSeq: number;
  lastBackupAt: string | null;
}

export interface DecryptedBackupPayload {
  app: 'TRIMOOL AYURVEDA';
  schemaVersion: 1;
  exportedAt: string;
  nextPatientSeq: number;
  patients: Patient[];
  visits: Visit[];
  prescriptionImages: Array<Omit<StoredMedicalImage, 'encrypted' | 'payload'> & { dataUrl: string }>;
  reportImages: Array<Omit<StoredMedicalImage, 'encrypted' | 'payload'> & { dataUrl: string }>;
}

export interface EncryptedBackupEnvelope {
  format: 'TRIMOOL_AYURVEDA_ENCRYPTED_BACKUP';
  version: 1;
  algorithm: 'AES-256-GCM';
  kdf: 'PBKDF2-SHA256';
  iterations: number;
  salt: string;
  iv: string;
  ciphertext: string;
  createdAt: string;
}

export interface DriveBackupFile {
  id: string;
  name: string;
  createdTime: string;
  size?: string;
}

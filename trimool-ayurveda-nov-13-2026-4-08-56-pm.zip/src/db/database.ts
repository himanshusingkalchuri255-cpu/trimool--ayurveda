import { getTodayDateString } from '../i18n/translations';
import type {
  AppSettings,
  DecryptedBackupPayload,
  Gender,
  ImageCategory,
  Patient,
  StoredMedicalImage,
  Visit,
} from '../types';
import { decryptLocalMediaString, encryptLocalMediaString } from '../utils/crypto';

const DB_NAME = 'TrimoolAyurvedaDB';
const DB_VERSION = 1;

const STORE_PATIENTS = 'patients';
const STORE_VISITS = 'visits';
const STORE_PRESCRIPTIONS = 'prescriptionImages';
const STORE_REPORTS = 'reportImages';
const STORE_SETTINGS = 'settings';

export const DEFAULT_SETTINGS: AppSettings = {
  key: 'app_settings',
  language: 'en',
  theme: 'light',
  pinEnabled: false,
  pinSalt: null,
  pinHash: null,
  biometricEnabled: false,
  biometricCredentialId: null,
  encryptLocalMedia: true,
  nextPatientSeq: 1,
  lastBackupAt: null,
};

function openDatabase(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(STORE_PATIENTS)) {
        const patientStore = db.createObjectStore(STORE_PATIENTS, { keyPath: 'id' });
        patientStore.createIndex('by_nameLower', 'nameLower', { unique: false });
        patientStore.createIndex('by_mobile', 'mobile', { unique: false });
      }
      if (!db.objectStoreNames.contains(STORE_VISITS)) {
        const visitStore = db.createObjectStore(STORE_VISITS, { keyPath: 'id' });
        visitStore.createIndex('by_patientId', 'patientId', { unique: false });
      }
      if (!db.objectStoreNames.contains(STORE_PRESCRIPTIONS)) {
        const rxStore = db.createObjectStore(STORE_PRESCRIPTIONS, { keyPath: 'id' });
        rxStore.createIndex('by_visitId', 'visitId', { unique: false });
        rxStore.createIndex('by_patientId', 'patientId', { unique: false });
      }
      if (!db.objectStoreNames.contains(STORE_REPORTS)) {
        const repStore = db.createObjectStore(STORE_REPORTS, { keyPath: 'id' });
        repStore.createIndex('by_visitId', 'visitId', { unique: false });
        repStore.createIndex('by_patientId', 'patientId', { unique: false });
      }
      if (!db.objectStoreNames.contains(STORE_SETTINGS)) {
        db.createObjectStore(STORE_SETTINGS, { keyPath: 'key' });
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

function reqToPromise<T>(req: IDBRequest<T>): Promise<T> {
  return new Promise((resolve, reject) => {
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

function txDone(tx: IDBTransaction): Promise<void> {
  return new Promise((resolve, reject) => {
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
    tx.onabort = () => reject(tx.error || new Error('Transaction aborted'));
  });
}

function formatPatientId(seq: number): string {
  return `TA-${String(seq).padStart(5, '0')}`;
}

function generateId(prefix: string): string {
  const rand = Math.random().toString(36).slice(2, 8);
  return `${prefix}-${Date.now()}-${rand}`;
}

function normalizeMobile(mobile: string): string {
  return mobile.replace(/\D/g, '').slice(-10);
}

export async function getSettings(): Promise<AppSettings> {
  const db = await openDatabase();
  try {
    const tx = db.transaction(STORE_SETTINGS, 'readonly');
    const existing = await reqToPromise<AppSettings | undefined>(
      tx.objectStore(STORE_SETTINGS).get('app_settings')
    );
    if (existing) {
      return { ...DEFAULT_SETTINGS, ...existing };
    }
    return { ...DEFAULT_SETTINGS };
  } finally {
    db.close();
  }
}

export async function saveSettings(partial: Partial<AppSettings>): Promise<AppSettings> {
  const db = await openDatabase();
  try {
    const tx = db.transaction(STORE_SETTINGS, 'readwrite');
    const store = tx.objectStore(STORE_SETTINGS);
    const current =
      (await reqToPromise<AppSettings | undefined>(store.get('app_settings'))) ||
      DEFAULT_SETTINGS;
    const updated: AppSettings = { ...DEFAULT_SETTINGS, ...current, ...partial, key: 'app_settings' };
    store.put(updated);
    await txDone(tx);
    return updated;
  } finally {
    db.close();
  }
}

export async function getTotalPatientCount(): Promise<number> {
  const db = await openDatabase();
  try {
    const tx = db.transaction(STORE_PATIENTS, 'readonly');
    return await reqToPromise<number>(tx.objectStore(STORE_PATIENTS).count());
  } finally {
    db.close();
  }
}

export async function getAllPatients(): Promise<Patient[]> {
  const db = await openDatabase();
  try {
    const tx = db.transaction(STORE_PATIENTS, 'readonly');
    const all = await reqToPromise<Patient[]>(tx.objectStore(STORE_PATIENTS).getAll());
    return all.sort((a, b) => b.registrationDate.localeCompare(a.registrationDate));
  } finally {
    db.close();
  }
}

export async function findPotentialDuplicates(name: string, mobile: string): Promise<Patient[]> {
  const cleanName = name.trim().toLowerCase();
  const cleanMob = normalizeMobile(mobile);
  const db = await openDatabase();
  try {
    const tx = db.transaction(STORE_PATIENTS, 'readonly');
    const all = await reqToPromise<Patient[]>(tx.objectStore(STORE_PATIENTS).getAll());
    return all.filter((p) => {
      const mobileMatch = cleanMob.length >= 6 && normalizeMobile(p.mobile) === cleanMob;
      const nameMatch = cleanName.length >= 2 && p.nameLower === cleanName;
      return mobileMatch || nameMatch;
    });
  } finally {
    db.close();
  }
}

export async function registerPatientWithFirstVisit(input: {
  name: string;
  age: number;
  gender: Gender;
  mobile: string;
  address: string;
}): Promise<{ patient: Patient; firstVisit: Visit }> {
  const db = await openDatabase();
  try {
    const tx = db.transaction([STORE_PATIENTS, STORE_VISITS, STORE_SETTINGS], 'readwrite');
    const settingsStore = tx.objectStore(STORE_SETTINGS);
    const patientStore = tx.objectStore(STORE_PATIENTS);
    const visitStore = tx.objectStore(STORE_VISITS);

    const settings =
      (await reqToPromise<AppSettings | undefined>(settingsStore.get('app_settings'))) ||
      { ...DEFAULT_SETTINGS };

    let seq = settings.nextPatientSeq || 1;
    let candidateId = formatPatientId(seq);
    // Guarantee uniqueness even if restored records exist
    while (await reqToPromise<Patient | undefined>(patientStore.get(candidateId))) {
      seq += 1;
      candidateId = formatPatientId(seq);
    }

    const nowIso = new Date().toISOString();
    const trimmedName = input.name.trim();
    const patient: Patient = {
      id: candidateId,
      name: trimmedName,
      nameLower: trimmedName.toLowerCase(),
      age: input.age,
      gender: input.gender,
      mobile: input.mobile.trim(),
      address: input.address.trim(),
      registrationDate: nowIso,
      updatedAt: nowIso,
    };

    const firstVisit: Visit = {
      id: generateId('V'),
      patientId: patient.id,
      visitDate: getTodayDateString(),
      createdAt: nowIso,
    };

    patientStore.add(patient);
    visitStore.add(firstVisit);
    settingsStore.put({
      ...DEFAULT_SETTINGS,
      ...settings,
      key: 'app_settings',
      nextPatientSeq: seq + 1,
    });

    await txDone(tx);
    return { patient, firstVisit };
  } finally {
    db.close();
  }
}

export async function updatePatientDetails(
  patientId: string,
  updates: {
    name: string;
    age: number;
    gender: Gender;
    mobile: string;
    address: string;
  }
): Promise<Patient> {
  const db = await openDatabase();
  try {
    const tx = db.transaction(STORE_PATIENTS, 'readwrite');
    const store = tx.objectStore(STORE_PATIENTS);
    const existing = await reqToPromise<Patient | undefined>(store.get(patientId));
    if (!existing) throw new Error('Patient not found');
    const trimmedName = updates.name.trim();
    const updated: Patient = {
      ...existing,
      name: trimmedName,
      nameLower: trimmedName.toLowerCase(),
      age: updates.age,
      gender: updates.gender,
      mobile: updates.mobile.trim(),
      address: updates.address.trim(),
      updatedAt: new Date().toISOString(),
    };
    store.put(updated);
    await txDone(tx);
    return updated;
  } finally {
    db.close();
  }
}

export interface VisitSummary {
  visit: Visit;
  prescriptionCount: number;
  reportCount: number;
}

export async function getPatientProfileData(patientId: string): Promise<{
  patient: Patient | null;
  visits: VisitSummary[];
}> {
  const db = await openDatabase();
  try {
    const tx = db.transaction(
      [STORE_PATIENTS, STORE_VISITS, STORE_PRESCRIPTIONS, STORE_REPORTS],
      'readonly'
    );
    const patient = await reqToPromise<Patient | undefined>(
      tx.objectStore(STORE_PATIENTS).get(patientId)
    );
    if (!patient) return { patient: null, visits: [] };

    const visits = await reqToPromise<Visit[]>(
      tx.objectStore(STORE_VISITS).index('by_patientId').getAll(patientId)
    );
    const rxList = await reqToPromise<StoredMedicalImage[]>(
      tx.objectStore(STORE_PRESCRIPTIONS).index('by_patientId').getAll(patientId)
    );
    const repList = await reqToPromise<StoredMedicalImage[]>(
      tx.objectStore(STORE_REPORTS).index('by_patientId').getAll(patientId)
    );

    const rxCounts = new Map<string, number>();
    for (const img of rxList) {
      rxCounts.set(img.visitId, (rxCounts.get(img.visitId) || 0) + 1);
    }
    const repCounts = new Map<string, number>();
    for (const img of repList) {
      repCounts.set(img.visitId, (repCounts.get(img.visitId) || 0) + 1);
    }

    // Sort newest visit first by visitDate, then createdAt
    visits.sort((a, b) => {
      const cmp = b.visitDate.localeCompare(a.visitDate);
      if (cmp !== 0) return cmp;
      return b.createdAt.localeCompare(a.createdAt);
    });

    return {
      patient,
      visits: visits.map((visit) => ({
        visit,
        prescriptionCount: rxCounts.get(visit.id) || 0,
        reportCount: repCounts.get(visit.id) || 0,
      })),
    };
  } finally {
    db.close();
  }
}

export async function addVisitForPatient(patientId: string, visitDate?: string): Promise<Visit> {
  const db = await openDatabase();
  try {
    const tx = db.transaction(STORE_VISITS, 'readwrite');
    const visit: Visit = {
      id: generateId('V'),
      patientId,
      visitDate: visitDate || getTodayDateString(),
      createdAt: new Date().toISOString(),
    };
    tx.objectStore(STORE_VISITS).add(visit);
    await txDone(tx);
    return visit;
  } finally {
    db.close();
  }
}

export async function updateVisitDate(visitId: string, newDate: string): Promise<Visit> {
  const db = await openDatabase();
  try {
    const tx = db.transaction(STORE_VISITS, 'readwrite');
    const store = tx.objectStore(STORE_VISITS);
    const existing = await reqToPromise<Visit | undefined>(store.get(visitId));
    if (!existing) throw new Error('Visit not found');
    const updated: Visit = { ...existing, visitDate: newDate };
    store.put(updated);
    await txDone(tx);
    return updated;
  } finally {
    db.close();
  }
}

export async function deleteVisitCascade(visitId: string): Promise<void> {
  const db = await openDatabase();
  try {
    const tx = db.transaction(
      [STORE_VISITS, STORE_PRESCRIPTIONS, STORE_REPORTS],
      'readwrite'
    );
    tx.objectStore(STORE_VISITS).delete(visitId);

    const rxKeys = await reqToPromise<IDBValidKey[]>(
      tx.objectStore(STORE_PRESCRIPTIONS).index('by_visitId').getAllKeys(visitId)
    );
    for (const k of rxKeys) tx.objectStore(STORE_PRESCRIPTIONS).delete(k);

    const repKeys = await reqToPromise<IDBValidKey[]>(
      tx.objectStore(STORE_REPORTS).index('by_visitId').getAllKeys(visitId)
    );
    for (const k of repKeys) tx.objectStore(STORE_REPORTS).delete(k);

    await txDone(tx);
  } finally {
    db.close();
  }
}

export async function deletePatientCascade(patientId: string): Promise<void> {
  const db = await openDatabase();
  try {
    const tx = db.transaction(
      [STORE_PATIENTS, STORE_VISITS, STORE_PRESCRIPTIONS, STORE_REPORTS],
      'readwrite'
    );
    tx.objectStore(STORE_PATIENTS).delete(patientId);

    const visitKeys = await reqToPromise<IDBValidKey[]>(
      tx.objectStore(STORE_VISITS).index('by_patientId').getAllKeys(patientId)
    );
    for (const k of visitKeys) tx.objectStore(STORE_VISITS).delete(k);

    const rxKeys = await reqToPromise<IDBValidKey[]>(
      tx.objectStore(STORE_PRESCRIPTIONS).index('by_patientId').getAllKeys(patientId)
    );
    for (const k of rxKeys) tx.objectStore(STORE_PRESCRIPTIONS).delete(k);

    const repKeys = await reqToPromise<IDBValidKey[]>(
      tx.objectStore(STORE_REPORTS).index('by_patientId').getAllKeys(patientId)
    );
    for (const k of repKeys) tx.objectStore(STORE_REPORTS).delete(k);

    await txDone(tx);
  } finally {
    db.close();
  }
}

export interface DecryptedMedicalImage {
  id: string;
  visitId: string;
  patientId: string;
  category: ImageCategory;
  fileName: string;
  mimeType: string;
  sizeBytes: number;
  capturedAt: string;
  dataUrl: string;
}

export async function addMedicalImages(
  visitId: string,
  patientId: string,
  category: ImageCategory,
  items: Array<{ dataUrl: string; fileName: string; mimeType: string; sizeBytes: number }>,
  encryptMedia: boolean
): Promise<DecryptedMedicalImage[]> {
  const storeName = category === 'prescription' ? STORE_PRESCRIPTIONS : STORE_REPORTS;
  const prepared: Array<{ record: StoredMedicalImage; dataUrl: string }> = [];

  for (const item of items) {
    const payload = encryptMedia
      ? await encryptLocalMediaString(item.dataUrl)
      : item.dataUrl;
    const record: StoredMedicalImage = {
      id: generateId(category === 'prescription' ? 'RX' : 'RP'),
      visitId,
      patientId,
      category,
      fileName: item.fileName,
      mimeType: item.mimeType,
      sizeBytes: item.sizeBytes,
      capturedAt: new Date().toISOString(),
      encrypted: encryptMedia,
      payload,
    };
    prepared.push({ record, dataUrl: item.dataUrl });
  }

  const db = await openDatabase();
  try {
    const tx = db.transaction(storeName, 'readwrite');
    const store = tx.objectStore(storeName);
    for (const p of prepared) {
      store.add(p.record);
    }
    await txDone(tx);
    return prepared.map((p) => ({
      id: p.record.id,
      visitId: p.record.visitId,
      patientId: p.record.patientId,
      category: p.record.category,
      fileName: p.record.fileName,
      mimeType: p.record.mimeType,
      sizeBytes: p.record.sizeBytes,
      capturedAt: p.record.capturedAt,
      dataUrl: p.dataUrl,
    }));
  } finally {
    db.close();
  }
}

export async function getVisitWithImages(visitId: string): Promise<{
  visit: Visit | null;
  patient: Patient | null;
  prescriptions: DecryptedMedicalImage[];
  reports: DecryptedMedicalImage[];
}> {
  const db = await openDatabase();
  let visit: Visit | undefined;
  let patient: Patient | undefined;
  let rxRaw: StoredMedicalImage[] = [];
  let repRaw: StoredMedicalImage[] = [];

  try {
    const tx = db.transaction(
      [STORE_VISITS, STORE_PATIENTS, STORE_PRESCRIPTIONS, STORE_REPORTS],
      'readonly'
    );
    visit = await reqToPromise<Visit | undefined>(tx.objectStore(STORE_VISITS).get(visitId));
    if (!visit) {
      return { visit: null, patient: null, prescriptions: [], reports: [] };
    }
    patient = await reqToPromise<Patient | undefined>(
      tx.objectStore(STORE_PATIENTS).get(visit.patientId)
    );
    rxRaw = await reqToPromise<StoredMedicalImage[]>(
      tx.objectStore(STORE_PRESCRIPTIONS).index('by_visitId').getAll(visitId)
    );
    repRaw = await reqToPromise<StoredMedicalImage[]>(
      tx.objectStore(STORE_REPORTS).index('by_visitId').getAll(visitId)
    );
  } finally {
    db.close();
  }

  const decodeAll = async (list: StoredMedicalImage[]): Promise<DecryptedMedicalImage[]> => {
    const sorted = [...list].sort((a, b) => a.capturedAt.localeCompare(b.capturedAt));
    const result: DecryptedMedicalImage[] = [];
    for (const item of sorted) {
      const dataUrl = item.encrypted
        ? await decryptLocalMediaString(item.payload)
        : item.payload;
      result.push({
        id: item.id,
        visitId: item.visitId,
        patientId: item.patientId,
        category: item.category,
        fileName: item.fileName,
        mimeType: item.mimeType,
        sizeBytes: item.sizeBytes,
        capturedAt: item.capturedAt,
        dataUrl,
      });
    }
    return result;
  };

  return {
    visit: visit || null,
    patient: patient || null,
    prescriptions: await decodeAll(rxRaw),
    reports: await decodeAll(repRaw),
  };
}

export async function deleteMedicalImage(imageId: string, category: ImageCategory): Promise<void> {
  const storeName = category === 'prescription' ? STORE_PRESCRIPTIONS : STORE_REPORTS;
  const db = await openDatabase();
  try {
    const tx = db.transaction(storeName, 'readwrite');
    tx.objectStore(storeName).delete(imageId);
    await txDone(tx);
  } finally {
    db.close();
  }
}

export async function exportFullDatabasePayload(): Promise<DecryptedBackupPayload> {
  const db = await openDatabase();
  let patients: Patient[] = [];
  let visits: Visit[] = [];
  let rxRaw: StoredMedicalImage[] = [];
  let repRaw: StoredMedicalImage[] = [];
  let settings: AppSettings | undefined;

  try {
    const tx = db.transaction(
      [STORE_PATIENTS, STORE_VISITS, STORE_PRESCRIPTIONS, STORE_REPORTS, STORE_SETTINGS],
      'readonly'
    );
    patients = await reqToPromise<Patient[]>(tx.objectStore(STORE_PATIENTS).getAll());
    visits = await reqToPromise<Visit[]>(tx.objectStore(STORE_VISITS).getAll());
    rxRaw = await reqToPromise<StoredMedicalImage[]>(tx.objectStore(STORE_PRESCRIPTIONS).getAll());
    repRaw = await reqToPromise<StoredMedicalImage[]>(tx.objectStore(STORE_REPORTS).getAll());
    settings = await reqToPromise<AppSettings | undefined>(
      tx.objectStore(STORE_SETTINGS).get('app_settings')
    );
  } finally {
    db.close();
  }

  const unwrap = async (list: StoredMedicalImage[]) => {
    const out: Array<Omit<StoredMedicalImage, 'encrypted' | 'payload'> & { dataUrl: string }> = [];
    for (const item of list) {
      const dataUrl = item.encrypted
        ? await decryptLocalMediaString(item.payload)
        : item.payload;
      out.push({
        id: item.id,
        visitId: item.visitId,
        patientId: item.patientId,
        category: item.category,
        fileName: item.fileName,
        mimeType: item.mimeType,
        sizeBytes: item.sizeBytes,
        capturedAt: item.capturedAt,
        dataUrl,
      });
    }
    return out;
  };

  return {
    app: 'TRIMOOL AYURVEDA',
    schemaVersion: 1,
    exportedAt: new Date().toISOString(),
    nextPatientSeq: settings?.nextPatientSeq || patients.length + 1,
    patients,
    visits,
    prescriptionImages: await unwrap(rxRaw),
    reportImages: await unwrap(repRaw),
  };
}

export async function restoreFullDatabasePayload(
  payload: DecryptedBackupPayload,
  encryptMedia: boolean
): Promise<void> {
  const prepareImages = async (
    list: DecryptedBackupPayload['prescriptionImages']
  ): Promise<StoredMedicalImage[]> => {
    const out: StoredMedicalImage[] = [];
    for (const item of list) {
      const encoded = encryptMedia
        ? await encryptLocalMediaString(item.dataUrl)
        : item.dataUrl;
      out.push({
        id: item.id,
        visitId: item.visitId,
        patientId: item.patientId,
        category: item.category,
        fileName: item.fileName,
        mimeType: item.mimeType,
        sizeBytes: item.sizeBytes,
        capturedAt: item.capturedAt,
        encrypted: encryptMedia,
        payload: encoded,
      });
    }
    return out;
  };

  const rxPrepared = await prepareImages(payload.prescriptionImages || []);
  const repPrepared = await prepareImages(payload.reportImages || []);

  const db = await openDatabase();
  try {
    const tx = db.transaction(
      [STORE_PATIENTS, STORE_VISITS, STORE_PRESCRIPTIONS, STORE_REPORTS, STORE_SETTINGS],
      'readwrite'
    );
    const pStore = tx.objectStore(STORE_PATIENTS);
    const vStore = tx.objectStore(STORE_VISITS);
    const rxStore = tx.objectStore(STORE_PRESCRIPTIONS);
    const repStore = tx.objectStore(STORE_REPORTS);
    const sStore = tx.objectStore(STORE_SETTINGS);

    pStore.clear();
    vStore.clear();
    rxStore.clear();
    repStore.clear();

    for (const p of payload.patients) pStore.put(p);
    for (const v of payload.visits) vStore.put(v);
    for (const img of rxPrepared) rxStore.put(img);
    for (const img of repPrepared) repStore.put(img);

    const existingSettings =
      (await reqToPromise<AppSettings | undefined>(sStore.get('app_settings'))) ||
      { ...DEFAULT_SETTINGS };
    sStore.put({
      ...DEFAULT_SETTINGS,
      ...existingSettings,
      key: 'app_settings',
      nextPatientSeq: Math.max(
        payload.nextPatientSeq || 1,
        payload.patients.length + 1
      ),
    });

    await txDone(tx);
  } finally {
    db.close();
  }
}

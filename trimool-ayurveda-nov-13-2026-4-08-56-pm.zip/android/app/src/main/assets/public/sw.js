/**
 * Copyright 2018 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// If the loader is already loaded, just stop.
if (!self.define) {
  let registry = {};

  // Used for `eval` and `importScripts` where we can't get script URL by other means.
  // In both cases, it's safe to use a global var because those functions are synchronous.
  let nextDefineUri;

  const singleRequire = (uri, parentUri) => {
    uri = new URL(uri + ".js", parentUri).href;
    return registry[uri] || (
      
        new Promise(resolve => {
          if ("document" in self) {
            const script = document.createElement("script");
            script.src = uri;
            script.onload = resolve;
            document.head.appendChild(script);
          } else {
            nextDefineUri = uri;
            importScripts(uri);
            resolve();
          }
        })
      
      .then(() => {
        let promise = registry[uri];
        if (!promise) {
          throw new Error(`Module ${uri} didn’t register its module`);
        }
        return promise;
      })
    );
  };

  self.define = (depsNames, factory) => {
    const uri = nextDefineUri || ("document" in self ? document.currentScript.src : "") || location.href;
    if (registry[uri]) {
      // Module is already loading or loaded.
      return;
    }
    let exports = {};
    const require = depUri => singleRequire(depUri, uri);
    const specialDeps = {
      module: { uri },
      exports,
      require
    };
    registry[uri] = Promise.all(depsNames.map(
      depName => specialDeps[depName] || require(depName)
    )).then(deps => {
      factory(...deps);
      return exports;
    });
  };
}
define(['./workbox-afac4cd2'], (function (workbox) { 'use strict';

  self.skipWaiting();
  workbox.clientsClaim();
  /**
   * The precacheAndRoute() method efficiently caches and responds to
   * requests for URLs in the manifest.
   * See https://goo.gl/S9QRab
   */
  workbox.precacheAndRoute([{
    "url": "pwa-maskable-512x512.png",
    "revision": "b56c865c03d0f841851a57d7cabf9a2d"
  }, {
    "url": "pwa-512x512.png",
    "revision": "5ee0951fb64fb6c24f3cbcacc61264e0"
  }, {
    "url": "pwa-192x192.png",
    "revision": "0b97bbefcc0da861aa0f6284e154abf6"
  }, {
    "url": "index.html",
    "revision": "931d8cc272e27a90d641d2aa142769a4"
  }, {
    "url": "icon.svg",
    "revision": "899ce38f010bc9782b97c47dbafd4a51"
  }, {
    "url": "apple-touch-icon.png",
    "revision": "b235ec3323de1002c2b83e27290afcbd"
  }, {
    "url": "assets/workbox-window.prod.es5-Bd17z0YL.js",
    "revision": null
  }, {
    "url": "assets/web-DWHSmOKQ.js",
    "revision": null
  }, {
    "url": "assets/web-CtitkEmq.js",
    "revision": null
  }, {
    "url": "assets/web-BdCAPHLQ.js",
    "revision": null
  }, {
    "url": "assets/web-BVVxQz-E.js",
    "revision": null
  }, {
    "url": "assets/web-BLonZZfj.js",
    "revision": null
  }, {
    "url": "assets/index-rZ4LYVGe.js",
    "revision": null
  }, {
    "url": "assets/index-W34Ky6_D.css",
    "revision": null
  }, {
    "url": "apple-touch-icon.png",
    "revision": "b235ec3323de1002c2b83e27290afcbd"
  }, {
    "url": "icon.svg",
    "revision": "899ce38f010bc9782b97c47dbafd4a51"
  }, {
    "url": "pwa-192x192.png",
    "revision": "0b97bbefcc0da861aa0f6284e154abf6"
  }, {
    "url": "pwa-512x512.png",
    "revision": "5ee0951fb64fb6c24f3cbcacc61264e0"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "b56c865c03d0f841851a57d7cabf9a2d"
  }, {
    "url": "manifest.webmanifest",
    "revision": "3089d2cd593f2e80f087dcb05d558671"
  }], {});
  workbox.cleanupOutdatedCaches();
  workbox.registerRoute(new workbox.NavigationRoute(workbox.createHandlerBoundToURL("index.html")));
  workbox.registerRoute(/^https:\/\/fonts\.googleapis\.com\/.*/i, new workbox.CacheFirst({
    "cacheName": "google-fonts-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 10,
      maxAgeSeconds: 31536000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');
  workbox.registerRoute(/^https:\/\/fonts\.gstatic\.com\/.*/i, new workbox.CacheFirst({
    "cacheName": "gstatic-fonts-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 10,
      maxAgeSeconds: 31536000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');

}));

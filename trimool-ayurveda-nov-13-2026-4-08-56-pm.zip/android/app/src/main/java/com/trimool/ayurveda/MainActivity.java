package com.trimool.ayurveda;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}

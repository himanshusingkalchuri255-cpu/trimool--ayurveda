# TRIMOOL AYURVEDA — Capacitor Native Android Build Guide

This package converts the existing **TRIMOOL AYURVEDA** React + Vite + PWA application into a standalone Native Android app (`com.trimool.ayurveda`) using Capacitor 8, keeping all clinic features, IndexedDB persistence, AES-256-GCM encryption, Hindi/English localization, Light/Dark themes, PIN & native BiometricPrompt unlock, Camera/Gallery capture, and encrypted Backup/Restore intact.

---

## 1. Prerequisites (Local Machine)

- **Node.js 20+** and **npm**
- **JDK 21** (bundled with Android Studio Ladybug / Meerkat or newer)
- **Android Studio** with **Android SDK Platform 36** (or SDK Build-Tools & Platform-Tools)

> Note: The AI Studio cloud container runs Linux/Node.js without JDK or Android SDK, so the final `.apk` compilation step runs locally on your machine or CI using the included `android/` Gradle project.

---

## 2. Build & Generate the Installable Android APK

From the extracted project root folder:

```bash
# 1. Install npm dependencies
npm install

# 2. Build production web assets into dist/
npm run build

# 3. Sync web assets & Capacitor Android plugins into android/
npx cap sync android
```

### Option A — Build Debug APK from Terminal (Fastest)

```bash
cd android
./gradlew assembleDebug    # Windows: gradlew.bat assembleDebug
```

The installable APK is generated at:
`android/app/build/outputs/apk/debug/app-debug.apk`

Install directly onto a connected Android phone via USB debugging:
```bash
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

### Option B — Open & Build in Android Studio

```bash
npx cap open android
```

Then inside Android Studio:
1. Wait for Gradle Sync to finish.
2. Click **Build → Build Bundle(s) / APK(s) → Build APK(s)** (for debug APK) or **Build → Generate Signed Bundle / APK...** (for release APK).
3. Run directly on your device or emulator via **Run ▶**.

### Option C — Build APK Automatically on GitHub Actions (No PC Android Studio Needed)

A ready workflow is included at `.github/workflows/build-apk.yml`:
1. Push this project to a GitHub repository (`main` or `master` branch).
2. Open the **Actions** tab on GitHub (or click **Run workflow** on **Build Android APK**).
3. After ~3 minutes, download the **`trimool-ayurveda-debug-apk`** artifact (`app-debug.apk`) directly onto your Android phone.

---

## 3. Transferring Existing PWA Data to the Android App

Because the Web/PWA and Native Android WebView have separate local storage sandboxes, migrate existing clinic records safely in 2 steps:

1. Open your existing **TRIMOOL AYURVEDA PWA** → **Settings** → **Encrypted Local Backup & Restore**.
2. Enter a strong passphrase (min 6 chars) and tap **Save Encrypted Backup** (`.trimool-backup.json`), or upload it via **Google Drive Backup**.
3. Open the **Trimool Ayurveda Android App** → **Settings** → **Restore from Backup File**, select the `.trimool-backup.json` file, enter the same passphrase, verify the patient/visit/photo counts, and tap **Confirm & Restore Records**.

All patients, `TA-00001` IDs, visit dates, prescription photos, and report photos are restored intact inside the Android app's offline database.

# TRIMOOL AYURVEDA — Native Android Studio Project & APK Build Guide

## Environment Disclosure
This workspace runs in a Node.js/Web container without the Android SDK, `java`/`javac`, Kotlin compiler, or Gradle binary installed. Therefore:
- `./gradlew assembleDebug` and Android instrumentation tests could **not** be executed inside this container.
- No fake APK has been generated.
- The complete native Android Studio project (`com.trimool.ayurveda`) has been written in `android-project/` and packaged into `TRIMOOL_AYURVEDA_Android_Project.zip`.
- The existing offline PWA in `src/` remains intact and functional on port `3000`.

---

## Opening in Android Studio & Generating the APK

1. Extract `TRIMOOL_AYURVEDA_Android_Project.zip` (or open `android-project/` directly).
2. Launch **Android Studio** (Ladybug / 2024.2 or newer) with JDK 17 configured.
3. Click **File > Open...** and select the `TRIMOOL_AYURVEDA` / `android-project` folder.
4. Wait for Android Studio to download Gradle 8.9 (as configured in `gradle/wrapper/gradle-wrapper.properties`) and complete **Gradle Sync**.
   - *(If running `./gradlew` directly from CLI on a fresh machine, run `gradle wrapper` once if `gradle/wrapper/gradle-wrapper.jar` is not yet cached, or use Android Studio's **Build** menu directly.)*
5. Build the Debug APK:
   - In Android Studio: **Build > Build Bundle(s) / APK(s) > Build APK(s)**
   - Or via terminal inside the project root:
     ```bash
     ./gradlew assembleDebug
     ```
   - Output Debug APK: `app/build/outputs/apk/debug/app-debug.apk`
6. Run Tests:
   ```bash
   ./gradlew testDebugUnitTest
   ./gradlew connectedDebugAndroidTest
   ```
7. Build a Signed Release APK:
   - In Android Studio: **Build > Generate Signed Bundle / APK... > APK**
   - Select or create a release keystore, choose `release`, and generate `app/release/app-release.apk`.

## Installing & Using on an Android Phone

1. Transfer `app-debug.apk` or `app-release.apk` to your Android phone (Android 8.0+ / API 26+).
2. Open the APK file on the phone and allow installation from that source if prompted.
3. Launch **Trimool Ayurveda**:
   - The Home Screen shows **TOTAL PATIENT**, **ADD NEW**, and **SEARCH PATIENT**.
   - Open **Settings** (top-right gear) to switch between **English** and **हिंदी (Hindi)**, toggle **Dark Mode**, configure an **App PIN Lock** and **Biometric Unlock**, or export/restore **AES-256-GCM Encrypted Backups** to any folder via Android Storage Access Framework.

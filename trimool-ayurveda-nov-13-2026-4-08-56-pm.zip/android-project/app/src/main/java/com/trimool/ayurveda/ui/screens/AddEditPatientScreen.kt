package com.trimool.ayurveda.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.trimool.ayurveda.R
import com.trimool.ayurveda.data.db.PatientEntity
import com.trimool.ayurveda.domain.Gender

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddEditPatientScreen(
    existingPatient: PatientEntity?,
    duplicates: List<PatientEntity>,
    onClearDuplicates: () -> Unit,
    onSaveNew: (name: String, age: Int, gender: Gender, mobile: String, address: String, bypassDuplicate: Boolean) -> Unit,
    onSaveEdit: (patientId: String, name: String, age: Int, gender: Gender, mobile: String, address: String) -> Unit,
    onOpenExistingPatient: (String) -> Unit,
    onBack: () -> Unit
) {
    val isEditing = existingPatient != null

    var name by remember(existingPatient) { mutableStateOf(existingPatient?.name ?: "") }
    var ageText by remember(existingPatient) { mutableStateOf(existingPatient?.age?.toString() ?: "") }
    var gender by remember(existingPatient) {
        mutableStateOf(existingPatient?.let { Gender.fromStorage(it.gender) } ?: Gender.MALE)
    }
    var mobile by remember(existingPatient) { mutableStateOf(existingPatient?.mobile ?: "") }
    var address by remember(existingPatient) { mutableStateOf(existingPatient?.address ?: "") }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    val errName = stringResource(R.string.err_name_required)
    val errAge = stringResource(R.string.err_age_invalid)

    fun validateAndExtractAge(): Int? {
        if (name.trim().isEmpty()) {
            errorMsg = errName
            return null
        }
        val parsedAge = ageText.trim().toIntOrNull()
        if (parsedAge == null || parsedAge !in 0..125) {
            errorMsg = errAge
            return null
        }
        errorMsg = null
        return parsedAge
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        if (isEditing) stringResource(R.string.edit_patient_details)
                        else stringResource(R.string.register_patient)
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = stringResource(R.string.back)
                        )
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            if (!isEditing && duplicates.isNotEmpty()) {
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.errorContainer
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                Icons.Default.Warning,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onErrorContainer
                            )
                            Text(
                                text = stringResource(R.string.duplicate_warning_title),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onErrorContainer
                            )
                        }
                        Text(
                            text = stringResource(R.string.duplicate_warning_desc),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onErrorContainer
                        )
                        duplicates.forEach { dup ->
                            Card(modifier = Modifier.fillMaxWidth()) {
                                Column(
                                    modifier = Modifier.padding(12.dp),
                                    verticalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Text(
                                        text = "${dup.name} (${dup.id})",
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    Text(
                                        text = "${dup.age} ${stringResource(R.string.years_short)} · ${dup.mobile.ifBlank { "-" }}",
                                        style = MaterialTheme.typography.bodySmall
                                    )
                                    Button(onClick = { onOpenExistingPatient(dup.id) }) {
                                        Text(stringResource(R.string.open_existing_patient))
                                    }
                                }
                            }
                        }
                        OutlinedButton(
                            onClick = {
                                val validAge = validateAndExtractAge() ?: return@OutlinedButton
                                onSaveNew(name, validAge, gender, mobile, address, true)
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(stringResource(R.string.create_anyway))
                        }
                    }
                }
            }

            OutlinedTextField(
                value = name,
                onValueChange = {
                    name = it
                    onClearDuplicates()
                },
                label = { Text("${stringResource(R.string.patient_name)} (${stringResource(R.string.required_label)})") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = ageText,
                onValueChange = { ageText = it.filter { ch -> ch.isDigit() }.take(3) },
                label = { Text("${stringResource(R.string.age)} (${stringResource(R.string.required_label)})") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            Text(
                text = "${stringResource(R.string.gender)} (${stringResource(R.string.required_label)})",
                style = MaterialTheme.typography.labelLarge
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = gender == Gender.MALE,
                    onClick = { gender = Gender.MALE },
                    label = { Text(stringResource(R.string.gender_male)) }
                )
                FilterChip(
                    selected = gender == Gender.FEMALE,
                    onClick = { gender = Gender.FEMALE },
                    label = { Text(stringResource(R.string.gender_female)) }
                )
                FilterChip(
                    selected = gender == Gender.OTHER,
                    onClick = { gender = Gender.OTHER },
                    label = { Text(stringResource(R.string.gender_other)) }
                )
            }

            OutlinedTextField(
                value = mobile,
                onValueChange = {
                    mobile = it
                    onClearDuplicates()
                },
                label = { Text("${stringResource(R.string.mobile_number)} (${stringResource(R.string.optional_label)})") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = address,
                onValueChange = { address = it },
                label = { Text("${stringResource(R.string.address)} (${stringResource(R.string.optional_label)})") },
                minLines = 2,
                modifier = Modifier.fillMaxWidth()
            )

            if (errorMsg != null) {
                Text(
                    text = errorMsg!!,
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodyMedium
                )
            }

            Spacer(Modifier.height(6.dp))

            Button(
                onClick = {
                    val validAge = validateAndExtractAge() ?: return@Button
                    if (isEditing && existingPatient != null) {
                        onSaveEdit(existingPatient.id, name, validAge, gender, mobile, address)
                    } else {
                        onSaveNew(name, validAge, gender, mobile, address, false)
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
            ) {
                Text(
                    if (isEditing) stringResource(R.string.save_changes)
                    else stringResource(R.string.save_and_start_visit)
                )
            }
        }
    }
}

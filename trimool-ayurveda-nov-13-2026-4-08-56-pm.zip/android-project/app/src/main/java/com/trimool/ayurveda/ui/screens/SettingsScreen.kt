package com.trimool.ayurveda.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatDelegate
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.core.os.LocaleListCompat
import com.trimool.ayurveda.R
import com.trimool.ayurveda.data.db.AppSettingsEntity
import com.trimool.ayurveda.domain.BackupValidationSummary
import com.trimool.ayurveda.domain.ClinicDateFormatter
import com.trimool.ayurveda.security.ClinicSecurityManager

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    settings: AppSettingsEntity,
    backupMessage: String?,
    backupError: String?,
    validatedBackup: BackupValidationSummary?,
    onLanguageSelected: (String) -> Unit,
    onDarkModeToggle: (Boolean) -> Unit,
    onEnablePin: (String) -> Unit,
    onDisablePin: () -> Unit,
    onBiometricToggle: (Boolean) -> Unit,
    onExportBackup: (Uri, String) -> Unit,
    onValidateRestoreFile: (Uri, String) -> Unit,
    onConfirmRestore: () -> Unit,
    onDismissRestoreDialog: () -> Unit,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val bioAvailable = remember { ClinicSecurityManager.canUseBiometric(context) }

    var pinInput by remember { mutableStateOf("") }
    var pinConfirm by remember { mutableStateOf("") }
    var pinError by remember { mutableStateOf<String?>(null) }

    var backupPassphrase by remember { mutableStateOf("") }
    var passphraseError by remember { mutableStateOf<String?>(null) }

    val errPinInvalid = stringResource(R.string.err_pin_invalid)
    val errPassphraseShort = stringResource(R.string.err_passphrase_short)

    val createBackupLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null) {
            onExportBackup(uri, backupPassphrase)
        }
    }

    val openBackupLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            onValidateRestoreFile(uri, backupPassphrase)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.settings)) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = stringResource(R.string.back)
                        )
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. Language & Theme
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = stringResource(R.string.language_and_theme),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )

                    Text(
                        text = stringResource(R.string.app_language),
                        style = MaterialTheme.typography.labelLarge
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = settings.language == "en",
                            onClick = {
                                onLanguageSelected("en")
                                AppCompatDelegate.setApplicationLocales(
                                    LocaleListCompat.forLanguageTags("en")
                                )
                            },
                            label = { Text(stringResource(R.string.english)) }
                        )
                        FilterChip(
                            selected = settings.language == "hi",
                            onClick = {
                                onLanguageSelected("hi")
                                AppCompatDelegate.setApplicationLocales(
                                    LocaleListCompat.forLanguageTags("hi")
                                )
                            },
                            label = { Text(stringResource(R.string.hindi)) }
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = stringResource(R.string.dark_mode),
                            style = MaterialTheme.typography.bodyLarge
                        )
                        Switch(
                            checked = settings.darkMode,
                            onCheckedChange = onDarkModeToggle
                        )
                    }
                }
            }

            // 2. Security & Privacy
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = stringResource(R.string.security_privacy),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )

                    Text(
                        text = if (settings.pinEnabled) stringResource(R.string.pin_active)
                        else stringResource(R.string.pin_inactive),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    if (settings.pinEnabled) {
                        OutlinedButton(onClick = onDisablePin) {
                            Text(stringResource(R.string.disable_pin))
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = stringResource(R.string.biometric_unlock),
                                    style = MaterialTheme.typography.bodyLarge
                                )
                                Text(
                                    text = if (bioAvailable) stringResource(R.string.biometric_supported)
                                    else stringResource(R.string.biometric_not_supported),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Switch(
                                checked = settings.biometricEnabled,
                                enabled = bioAvailable,
                                onCheckedChange = onBiometricToggle
                            )
                        }
                    } else {
                        OutlinedTextField(
                            value = pinInput,
                            onValueChange = {
                                pinInput = it.filter { ch -> ch.isDigit() }.take(6)
                                pinError = null
                            },
                            label = { Text(stringResource(R.string.new_pin)) },
                            visualTransformation = PasswordVisualTransformation(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = pinConfirm,
                            onValueChange = {
                                pinConfirm = it.filter { ch -> ch.isDigit() }.take(6)
                                pinError = null
                            },
                            label = { Text(stringResource(R.string.confirm_pin)) },
                            visualTransformation = PasswordVisualTransformation(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        if (pinError != null) {
                            Text(
                                text = pinError!!,
                                color = MaterialTheme.colorScheme.error,
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                        Button(
                            onClick = {
                                if (pinInput.length in 4..6 && pinInput == pinConfirm) {
                                    onEnablePin(pinInput)
                                    pinInput = ""
                                    pinConfirm = ""
                                } else {
                                    pinError = errPinInvalid
                                }
                            }
                        ) {
                            Text(stringResource(R.string.enable_pin))
                        }
                    }
                }
            }

            // 3. Encrypted Backup & Restore (SAF)
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = stringResource(R.string.backup_and_restore),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = stringResource(R.string.backup_desc),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    OutlinedTextField(
                        value = backupPassphrase,
                        onValueChange = {
                            backupPassphrase = it
                            passphraseError = null
                        },
                        label = { Text(stringResource(R.string.backup_passphrase)) },
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    if (passphraseError != null) {
                        Text(
                            text = passphraseError!!,
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                    if (backupError != null) {
                        Text(
                            text = backupError,
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                    if (backupMessage != null) {
                        Text(
                            text = backupMessage,
                            color = MaterialTheme.colorScheme.primary,
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    Button(
                        onClick = {
                            if (backupPassphrase.length < 6) {
                                passphraseError = errPassphraseShort
                            } else {
                                val fileName =
                                    "trimool-ayurveda-backup-${ClinicDateFormatter.todayDateIso()}.json"
                                createBackupLauncher.launch(fileName)
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(stringResource(R.string.export_encrypted_backup))
                    }

                    OutlinedButton(
                        onClick = {
                            if (backupPassphrase.length < 6) {
                                passphraseError = errPassphraseShort
                            } else {
                                openBackupLauncher.launch(arrayOf("application/json", "*/*"))
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(stringResource(R.string.restore_encrypted_backup))
                    }
                }
            }

            Spacer(Modifier.height(16.dp))
        }
    }

    if (validatedBackup != null) {
        AlertDialog(
            onDismissRequest = onDismissRestoreDialog,
            title = { Text(stringResource(R.string.restore_verify_title)) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = stringResource(
                            R.string.restore_summary_format,
                            validatedBackup.patientCount,
                            validatedBackup.visitCount,
                            validatedBackup.photoCount
                        ),
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = stringResource(R.string.restore_prevent_duplicate_note),
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            },
            confirmButton = {
                Button(onClick = onConfirmRestore) {
                    Text(stringResource(R.string.confirm_restore))
                }
            },
            dismissButton = {
                TextButton(onClick = onDismissRestoreDialog) {
                    Text(stringResource(R.string.cancel))
                }
            }
        )
    }
}

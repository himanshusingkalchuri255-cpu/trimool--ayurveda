package com.trimool.ayurveda

import android.app.Application
import com.trimool.ayurveda.backup.EncryptedBackupManager
import com.trimool.ayurveda.data.db.ClinicDatabase
import com.trimool.ayurveda.data.repository.ClinicRepository

class TrimoolAyurvedaApp : Application() {
    val database: ClinicDatabase by lazy { ClinicDatabase.getInstance(this) }
    val repository: ClinicRepository by lazy { ClinicRepository(this, database) }
    val backupManager: EncryptedBackupManager by lazy { EncryptedBackupManager(this, database) }
}

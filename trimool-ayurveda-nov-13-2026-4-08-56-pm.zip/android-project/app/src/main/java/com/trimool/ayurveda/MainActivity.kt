package com.trimool.ayurveda

import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.lifecycle.viewmodel.compose.viewModel
import com.trimool.ayurveda.ui.ClinicViewModel
import com.trimool.ayurveda.ui.navigation.ClinicNavGraph
import com.trimool.ayurveda.ui.screens.LockScreen
import com.trimool.ayurveda.ui.theme.TrimoolAyurvedaTheme

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val viewModel: ClinicViewModel = viewModel()
            val settings by viewModel.settings.collectAsState()
            val isUnlocked by viewModel.isUnlocked.collectAsState()
            val lockChecked by viewModel.lockChecked.collectAsState()

            TrimoolAyurvedaTheme(darkTheme = settings.darkMode) {
                if (lockChecked) {
                    if (settings.pinEnabled && !isUnlocked) {
                        LockScreen(
                            biometricEnabled = settings.biometricEnabled,
                            onVerifyPin = viewModel::unlockWithPin,
                            onBiometricSuccess = viewModel::unlockWithBiometricSuccess
                        )
                    } else {
                        ClinicNavGraph(viewModel = viewModel)
                    }
                }
            }
        }
    }
}

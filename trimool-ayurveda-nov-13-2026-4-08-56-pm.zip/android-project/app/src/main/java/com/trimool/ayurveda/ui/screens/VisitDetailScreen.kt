package com.trimool.ayurveda.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.trimool.ayurveda.R
import com.trimool.ayurveda.data.db.PatientEntity
import com.trimool.ayurveda.data.db.VisitEntity
import com.trimool.ayurveda.domain.ClinicDateFormatter
import com.trimool.ayurveda.domain.ImageCategory
import com.trimool.ayurveda.domain.MedicalPhotoUi
import com.trimool.ayurveda.ui.components.ConfirmationDialog
import com.trimool.ayurveda.ui.components.DecryptedPhotoThumbnail
import com.trimool.ayurveda.ui.components.PinchZoomPhotoViewerDialog
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneOffset

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VisitDetailScreen(
    patient: PatientEntity?,
    visit: VisitEntity?,
    prescriptions: List<MedicalPhotoUi>,
    reports: List<MedicalPhotoUi>,
    loadPhotoBytes: suspend (String) -> ByteArray?,
    onUpdateVisitDate: (String) -> Unit,
    onDeleteVisit: () -> Unit,
    onOpenCamera: (ImageCategory) -> Unit,
    onGalleryPicked: (ImageCategory, List<Uri>) -> Unit,
    onDeletePhoto: (MedicalPhotoUi) -> Unit,
    onBack: () -> Unit
) {
    if (visit == null || patient == null) return

    var selectedTab by remember { mutableIntStateOf(0) }
    val activeCategory = if (selectedTab == 0) ImageCategory.PRESCRIPTION else ImageCategory.REPORT
    val activePhotos = if (activeCategory == ImageCategory.PRESCRIPTION) prescriptions else reports

    var showDatePicker by remember { mutableStateOf(false) }
    var showDeleteVisitDialog by remember { mutableStateOf(false) }
    var photoToDelete by remember { mutableStateOf<MedicalPhotoUi?>(null) }
    var viewerIndex by remember { mutableStateOf<Int?>(null) }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia(maxItems = 20)
    ) { uris ->
        if (uris.isNotEmpty()) {
            onGalleryPicked(activeCategory, uris)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(patient.name, fontWeight = FontWeight.Bold)
                        Text(
                            text = "${patient.id} · ${stringResource(R.string.visit_details)}",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = stringResource(R.string.back)
                        )
                    }
                },
                actions = {
                    IconButton(onClick = { showDeleteVisitDialog = true }) {
                        Icon(
                            Icons.Default.Delete,
                            contentDescription = stringResource(R.string.delete_visit)
                        )
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Card(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            Icons.Default.DateRange,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Column {
                            Text(
                                text = stringResource(R.string.visit_date),
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = ClinicDateFormatter.formatDisplayDate(visit.visitDate),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                    OutlinedButton(onClick = { showDatePicker = true }) {
                        Text(stringResource(R.string.edit_visit_date))
                    }
                }
            }

            // Strictly separated Prescription & Reports tabs
            TabRow(selectedTabIndex = selectedTab) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("${stringResource(R.string.prescription)} (${prescriptions.size})") }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("${stringResource(R.string.reports)} (${reports.size})") }
                )
            }

            Row(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Button(
                    onClick = { onOpenCamera(activeCategory) },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.CameraAlt, contentDescription = null)
                    Spacer(Modifier.padding(3.dp))
                    Text(stringResource(R.string.capture_camera))
                }
                OutlinedButton(
                    onClick = {
                        photoPickerLauncher.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.PhotoLibrary, contentDescription = null)
                    Spacer(Modifier.padding(3.dp))
                    Text(stringResource(R.string.upload_gallery))
                }
            }

            if (activePhotos.isEmpty()) {
                Text(
                    text = if (activeCategory == ImageCategory.PRESCRIPTION) {
                        stringResource(R.string.no_prescriptions)
                    } else {
                        stringResource(R.string.no_reports)
                    },
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 24.dp)
                )
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(minSize = 140.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                ) {
                    itemsIndexed(activePhotos, key = { _, item -> item.id }) { index, photo ->
                        DecryptedPhotoThumbnail(
                            photo = photo,
                            loadBytes = loadPhotoBytes,
                            onClick = { viewerIndex = index },
                            onDeleteClick = { photoToDelete = photo }
                        )
                    }
                }
            }
        }
    }

    if (showDatePicker) {
        val initialMillis = remember(visit.visitDate) {
            runCatching {
                LocalDate.parse(visit.visitDate).atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli()
            }.getOrNull()
        }
        val datePickerState = rememberDatePickerState(initialSelectedDateMillis = initialMillis)
        DatePickerDialog(
            onDismissRequest = { showDatePicker = false },
            confirmButton = {
                TextButton(
                    onClick = {
                        val millis = datePickerState.selectedDateMillis
                        if (millis != null) {
                            val newDate = Instant.ofEpochMilli(millis)
                                .atZone(ZoneOffset.UTC)
                                .toLocalDate()
                                .toString()
                            onUpdateVisitDate(newDate)
                        }
                        showDatePicker = false
                    }
                ) {
                    Text(stringResource(R.string.save))
                }
            },
            dismissButton = {
                TextButton(onClick = { showDatePicker = false }) {
                    Text(stringResource(R.string.cancel))
                }
            }
        ) {
            DatePicker(state = datePickerState)
        }
    }

    if (viewerIndex != null && activePhotos.isNotEmpty()) {
        PinchZoomPhotoViewerDialog(
            photos = activePhotos,
            initialIndex = viewerIndex!!,
            loadBytes = loadPhotoBytes,
            onRequestDelete = { photoToDelete = it },
            onDismiss = { viewerIndex = null }
        )
    }

    if (photoToDelete != null) {
        ConfirmationDialog(
            title = stringResource(R.string.delete_photo_title),
            description = stringResource(R.string.delete_photo_desc),
            confirmLabel = stringResource(R.string.delete),
            cancelLabel = stringResource(R.string.cancel),
            onConfirm = {
                val target = photoToDelete!!
                photoToDelete = null
                viewerIndex = null
                onDeletePhoto(target)
            },
            onDismiss = { photoToDelete = null }
        )
    }

    if (showDeleteVisitDialog) {
        ConfirmationDialog(
            title = stringResource(R.string.delete_visit_title),
            description = stringResource(R.string.delete_visit_desc),
            confirmLabel = stringResource(R.string.confirm_delete),
            cancelLabel = stringResource(R.string.cancel),
            onConfirm = {
                showDeleteVisitDialog = false
                onDeleteVisit()
            },
            onDismiss = { showDeleteVisitDialog = false }
        )
    }
}

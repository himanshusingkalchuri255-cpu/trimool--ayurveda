package com.trimool.ayurveda.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface PatientDao {
    @Query("SELECT COUNT(*) FROM patients")
    fun observeTotalCount(): Flow<Int>

    @Query("SELECT * FROM patients ORDER BY registrationDateIso DESC")
    fun observeAllByNewest(): Flow<List<PatientEntity>>

    @Query("SELECT * FROM patients ORDER BY nameLower ASC")
    fun observeAllByName(): Flow<List<PatientEntity>>

    @Query("SELECT * FROM patients ORDER BY id ASC")
    fun observeAllById(): Flow<List<PatientEntity>>

    @Query(
        """
        SELECT * FROM patients
        WHERE nameLower LIKE '%' || :query || '%'
           OR mobile LIKE '%' || :query || '%'
           OR LOWER(id) LIKE '%' || :query || '%'
        ORDER BY nameLower ASC
        LIMIT 200
        """
    )
    fun searchPatients(query: String): Flow<List<PatientEntity>>

    @Query(
        """
        SELECT * FROM patients
        WHERE (:cleanMobile != '' AND REPLACE(REPLACE(REPLACE(mobile, ' ', ''), '-', ''), '+', '') LIKE '%' || :cleanMobile)
           OR nameLower = :nameLower
        ORDER BY registrationDateIso DESC
        """
    )
    suspend fun findPotentialDuplicates(nameLower: String, cleanMobile: String): List<PatientEntity>

    @Query("SELECT * FROM patients WHERE id = :patientId LIMIT 1")
    fun observePatientById(patientId: String): Flow<PatientEntity?>

    @Query("SELECT * FROM patients WHERE id = :patientId LIMIT 1")
    suspend fun getPatientById(patientId: String): PatientEntity?

    @Query("SELECT EXISTS(SELECT 1 FROM patients WHERE id = :patientId)")
    suspend fun existsById(patientId: String): Boolean

    @Query("SELECT * FROM patients")
    suspend fun getAllPatientsOnce(): List<PatientEntity>

    // ABORT guarantees an existing patient record is never silently overwritten
    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertPatient(patient: PatientEntity)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertPatientIfMissing(patient: PatientEntity): Long

    @Update
    suspend fun updatePatient(patient: PatientEntity)

    @Query("DELETE FROM patients WHERE id = :patientId")
    suspend fun deletePatientById(patientId: String)
}

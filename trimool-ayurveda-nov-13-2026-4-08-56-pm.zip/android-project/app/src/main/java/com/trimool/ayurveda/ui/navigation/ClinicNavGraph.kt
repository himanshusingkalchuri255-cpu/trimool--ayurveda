package com.trimool.ayurveda.ui.navigation

import android.net.Uri
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.res.stringResource
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.trimool.ayurveda.R
import com.trimool.ayurveda.camera.CameraCaptureScreen
import com.trimool.ayurveda.domain.ImageCategory
import com.trimool.ayurveda.ui.ClinicViewModel
import com.trimool.ayurveda.ui.screens.AddEditPatientScreen
import com.trimool.ayurveda.ui.screens.HomeScreen
import com.trimool.ayurveda.ui.screens.PatientDirectoryScreen
import com.trimool.ayurveda.ui.screens.PatientProfileScreen
import com.trimool.ayurveda.ui.screens.SearchPatientScreen
import com.trimool.ayurveda.ui.screens.SettingsScreen
import com.trimool.ayurveda.ui.screens.VisitDetailScreen

object Routes {
    const val HOME = "home"
    const val DIRECTORY = "directory"
    const val ADD_PATIENT = "add_patient"
    const val EDIT_PATIENT = "edit_patient/{patientId}"
    const val SEARCH = "search"
    const val PROFILE = "profile/{patientId}"
    const val VISIT = "visit/{visitId}"
    const val CAMERA = "camera/{patientId}/{visitId}/{category}"
    const val SETTINGS = "settings"

    fun editPatient(patientId: String) = "edit_patient/${Uri.encode(patientId)}"
    fun profile(patientId: String) = "profile/${Uri.encode(patientId)}"
    fun visit(visitId: String) = "visit/${Uri.encode(visitId)}"
    fun camera(patientId: String, visitId: String, category: ImageCategory) =
        "camera/${Uri.encode(patientId)}/${Uri.encode(visitId)}/${category.name}"
}

@Composable
fun ClinicNavGraph(viewModel: ClinicViewModel) {
    val navController = rememberNavController()
    val settings by viewModel.settings.collectAsState()
    val totalPatients by viewModel.totalPatientCount.collectAsState()

    val backupExportedSuccess = stringResource(R.string.backup_exported_success)
    val restoreSuccess = stringResource(R.string.restore_success)
    val errBackupDecrypt = stringResource(R.string.err_backup_decrypt)

    NavHost(
        navController = navController,
        startDestination = Routes.HOME
    ) {
        composable(Routes.HOME) {
            HomeScreen(
                totalPatients = totalPatients,
                pinEnabled = settings.pinEnabled,
                onOpenDirectory = { navController.navigate(Routes.DIRECTORY) },
                onAddNew = {
                    viewModel.clearDuplicates()
                    navController.navigate(Routes.ADD_PATIENT)
                },
                onSearchPatient = { navController.navigate(Routes.SEARCH) },
                onOpenSettings = {
                    viewModel.clearBackupMessages()
                    navController.navigate(Routes.SETTINGS)
                },
                onLockNow = { viewModel.lockNow() }
            )
        }

        composable(Routes.DIRECTORY) {
            val patients by viewModel.directoryPatients.collectAsState()
            val query by viewModel.directoryQuery.collectAsState()
            val sortOrder by viewModel.sortOrder.collectAsState()

            PatientDirectoryScreen(
                patients = patients,
                query = query,
                sortOrder = sortOrder,
                onQueryChange = viewModel::setDirectoryQuery,
                onSortChange = viewModel::setSortOrder,
                onSelectPatient = { pid -> navController.navigate(Routes.profile(pid)) },
                onBack = { navController.popBackStack() }
            )
        }

        composable(Routes.ADD_PATIENT) {
            val duplicates by viewModel.potentialDuplicates.collectAsState()

            AddEditPatientScreen(
                existingPatient = null,
                duplicates = duplicates,
                onClearDuplicates = viewModel::clearDuplicates,
                onSaveNew = { name, age, gender, mobile, address, bypass ->
                    viewModel.submitNewPatient(
                        name = name,
                        age = age,
                        gender = gender,
                        mobile = mobile,
                        address = address,
                        bypassDuplicateCheck = bypass
                    ) { _, firstVisitId ->
                        navController.navigate(Routes.visit(firstVisitId)) {
                            popUpTo(Routes.HOME)
                        }
                    }
                },
                onSaveEdit = { _, _, _, _, _, _ -> },
                onOpenExistingPatient = { pid ->
                    viewModel.clearDuplicates()
                    navController.navigate(Routes.profile(pid)) {
                        popUpTo(Routes.HOME)
                    }
                },
                onBack = { navController.popBackStack() }
            )
        }

        composable(
            route = Routes.EDIT_PATIENT,
            arguments = listOf(navArgument("patientId") { type = NavType.StringType })
        ) { entry ->
            val patientId = entry.arguments?.getString("patientId").orEmpty()
            val patient by viewModel.observePatient(patientId).collectAsState(initial = null)

            AddEditPatientScreen(
                existingPatient = patient,
                duplicates = emptyList(),
                onClearDuplicates = {},
                onSaveNew = { _, _, _, _, _, _ -> },
                onSaveEdit = { pid, name, age, gender, mobile, address ->
                    viewModel.updateExistingPatient(pid, name, age, gender, mobile, address) {
                        navController.popBackStack()
                    }
                },
                onOpenExistingPatient = {},
                onBack = { navController.popBackStack() }
            )
        }

        composable(Routes.SEARCH) {
            val query by viewModel.searchQuery.collectAsState()
            val results by viewModel.searchResults.collectAsState()

            SearchPatientScreen(
                query = query,
                results = results,
                onQueryChange = viewModel::setSearchQuery,
                onSelectPatient = { pid -> navController.navigate(Routes.profile(pid)) },
                onBack = { navController.popBackStack() }
            )
        }

        composable(
            route = Routes.PROFILE,
            arguments = listOf(navArgument("patientId") { type = NavType.StringType })
        ) { entry ->
            val patientId = entry.arguments?.getString("patientId").orEmpty()
            val patient by viewModel.observePatient(patientId).collectAsState(initial = null)
            val visits by viewModel.observeVisits(patientId).collectAsState(initial = emptyList())

            PatientProfileScreen(
                patient = patient,
                visits = visits,
                onEditPatient = { navController.navigate(Routes.editPatient(patientId)) },
                onAddNewVisit = {
                    viewModel.createVisitForPatient(patientId) { visitId ->
                        navController.navigate(Routes.visit(visitId))
                    }
                },
                onOpenVisit = { visitId -> navController.navigate(Routes.visit(visitId)) },
                onDeletePatient = {
                    viewModel.deletePatient(patientId) {
                        navController.popBackStack(Routes.HOME, inclusive = false)
                    }
                },
                onBack = { navController.popBackStack() }
            )
        }

        composable(
            route = Routes.VISIT,
            arguments = listOf(navArgument("visitId") { type = NavType.StringType })
        ) { entry ->
            val visitId = entry.arguments?.getString("visitId").orEmpty()
            val visit by viewModel.observeVisit(visitId).collectAsState(initial = null)
            val patientId = visit?.patientId.orEmpty()
            val patient by viewModel.observePatient(patientId).collectAsState(initial = null)
            val prescriptions by viewModel.observePhotos(visitId, ImageCategory.PRESCRIPTION)
                .collectAsState(initial = emptyList())
            val reports by viewModel.observePhotos(visitId, ImageCategory.REPORT)
                .collectAsState(initial = emptyList())

            VisitDetailScreen(
                patient = patient,
                visit = visit,
                prescriptions = prescriptions,
                reports = reports,
                loadPhotoBytes = viewModel::readDecryptedPhotoBytes,
                onUpdateVisitDate = { newDate -> viewModel.updateVisitDate(visitId, newDate) },
                onDeleteVisit = {
                    viewModel.deleteVisit(visitId) {
                        navController.popBackStack()
                    }
                },
                onOpenCamera = { category ->
                    if (patientId.isNotEmpty()) {
                        navController.navigate(Routes.camera(patientId, visitId, category))
                    }
                },
                onGalleryPicked = { category, uris ->
                    if (patientId.isNotEmpty()) {
                        viewModel.saveGalleryPhotos(patientId, visitId, category, uris)
                    }
                },
                onDeletePhoto = viewModel::deletePhoto,
                onBack = { navController.popBackStack() }
            )
        }

        composable(
            route = Routes.CAMERA,
            arguments = listOf(
                navArgument("patientId") { type = NavType.StringType },
                navArgument("visitId") { type = NavType.StringType },
                navArgument("category") { type = NavType.StringType }
            )
        ) { entry ->
            val patientId = entry.arguments?.getString("patientId").orEmpty()
            val visitId = entry.arguments?.getString("visitId").orEmpty()
            val catRaw = entry.arguments?.getString("category").orEmpty()
            val category = runCatching { ImageCategory.valueOf(catRaw) }
                .getOrDefault(ImageCategory.PRESCRIPTION)

            CameraCaptureScreen(
                category = category,
                onPhotoSaved = { fileName, bytes ->
                    viewModel.saveCameraPhoto(patientId, visitId, category, fileName, bytes)
                },
                onBack = { navController.popBackStack() }
            )
        }

        composable(Routes.SETTINGS) {
            val backupMessage by viewModel.backupMessage.collectAsState()
            val backupError by viewModel.backupError.collectAsState()
            val validatedBackup by viewModel.validatedBackup.collectAsState()

            SettingsScreen(
                settings = settings,
                backupMessage = backupMessage,
                backupError = backupError,
                validatedBackup = validatedBackup,
                onLanguageSelected = viewModel::setLanguage,
                onDarkModeToggle = viewModel::setDarkMode,
                onEnablePin = viewModel::enablePin,
                onDisablePin = viewModel::disablePin,
                onBiometricToggle = viewModel::setBiometricEnabled,
                onExportBackup = { uri, pass ->
                    viewModel.exportBackup(uri, pass, backupExportedSuccess)
                },
                onValidateRestoreFile = { uri, pass ->
                    viewModel.validateBackupForRestore(uri, pass, errBackupDecrypt)
                },
                onConfirmRestore = {
                    viewModel.confirmRestore(restoreSuccess)
                },
                onDismissRestoreDialog = viewModel::clearValidatedBackup,
                onBack = { navController.popBackStack() }
            )
        }
    }
}

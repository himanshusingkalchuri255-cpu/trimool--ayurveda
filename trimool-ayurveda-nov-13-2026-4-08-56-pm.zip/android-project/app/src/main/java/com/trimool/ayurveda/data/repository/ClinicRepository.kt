package com.trimool.ayurveda.data.repository

import android.content.Context
import android.net.Uri
import androidx.room.withTransaction
import com.trimool.ayurveda.data.db.AppSettingsEntity
import com.trimool.ayurveda.data.db.ClinicDatabase
import com.trimool.ayurveda.data.db.PatientEntity
import com.trimool.ayurveda.data.db.PrescriptionImageEntity
import com.trimool.ayurveda.data.db.ReportImageEntity
import com.trimool.ayurveda.data.db.VisitEntity
import com.trimool.ayurveda.data.db.VisitWithPhotoCountsRow
import com.trimool.ayurveda.domain.ClinicDateFormatter
import com.trimool.ayurveda.domain.Gender
import com.trimool.ayurveda.domain.ImageCategory
import com.trimool.ayurveda.domain.MedicalPhotoUi
import com.trimool.ayurveda.domain.PatientSortOrder
import com.trimool.ayurveda.security.ClinicSecurityManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

class ClinicRepository(
    private val context: Context,
    private val db: ClinicDatabase
) {
    private val patientDao = db.patientDao()
    private val visitDao = db.visitDao()
    private val imageDao = db.medicalImageDao()
    private val settingsDao = db.settingsDao()

    private val privatePhotosRoot: File
        get() = File(context.filesDir, "clinic_encrypted_photos").apply { mkdirs() }

    fun observeTotalPatientCount(): Flow<Int> = patientDao.observeTotalCount()

    fun observePatients(sortOrder: PatientSortOrder): Flow<List<PatientEntity>> {
        return when (sortOrder) {
            PatientSortOrder.NEWEST -> patientDao.observeAllByNewest()
            PatientSortOrder.NAME -> patientDao.observeAllByName()
            PatientSortOrder.PATIENT_ID -> patientDao.observeAllById()
        }
    }

    fun searchPatients(query: String): Flow<List<PatientEntity>> {
        val clean = query.trim().lowercase()
        return patientDao.searchPatients(clean)
    }

    fun observePatient(patientId: String): Flow<PatientEntity?> =
        patientDao.observePatientById(patientId)

    fun observeVisitsForPatient(patientId: String): Flow<List<VisitWithPhotoCountsRow>> =
        visitDao.observeVisitsWithCounts(patientId)

    fun observeVisit(visitId: String): Flow<VisitEntity?> =
        visitDao.observeVisitById(visitId)

    fun observePhotosForVisit(visitId: String, category: ImageCategory): Flow<List<MedicalPhotoUi>> {
        return when (category) {
            ImageCategory.PRESCRIPTION -> imageDao.observePrescriptionsForVisit(visitId).map { list ->
                list.map {
                    MedicalPhotoUi(
                        id = it.id,
                        visitId = it.visitId,
                        patientId = it.patientId,
                        category = ImageCategory.PRESCRIPTION,
                        fileName = it.fileName,
                        encryptedFilePath = it.encryptedFilePath,
                        capturedAtIso = it.capturedAtIso
                    )
                }
            }
            ImageCategory.REPORT -> imageDao.observeReportsForVisit(visitId).map { list ->
                list.map {
                    MedicalPhotoUi(
                        id = it.id,
                        visitId = it.visitId,
                        patientId = it.patientId,
                        category = ImageCategory.REPORT,
                        fileName = it.fileName,
                        encryptedFilePath = it.encryptedFilePath,
                        capturedAtIso = it.capturedAtIso
                    )
                }
            }
        }
    }

    fun observeSettings(): Flow<AppSettingsEntity> =
        settingsDao.observeSettings().map { it ?: AppSettingsEntity() }

    suspend fun getSettingsOnce(): AppSettingsEntity =
        settingsDao.getSettingsOnce() ?: AppSettingsEntity()

    suspend fun updateSettings(transform: (AppSettingsEntity) -> AppSettingsEntity): AppSettingsEntity {
        val current = getSettingsOnce()
        val updated = transform(current)
        settingsDao.upsertSettings(updated)
        return updated
    }

    suspend fun findPotentialDuplicates(name: String, mobile: String): List<PatientEntity> {
        val cleanName = name.trim().lowercase()
        val cleanMobile = mobile.replace(Regex("\\D"), "").takeLast(10)
        if (cleanName.length < 2 && cleanMobile.length < 6) return emptyList()
        return patientDao.findPotentialDuplicates(
            nameLower = cleanName,
            cleanMobile = if (cleanMobile.length >= 6) cleanMobile else ""
        )
    }

    suspend fun registerPatientWithFirstVisit(
        name: String,
        age: Int,
        gender: Gender,
        mobile: String,
        address: String
    ): Pair<PatientEntity, VisitEntity> {
        return db.withTransaction {
            val settings = settingsDao.getSettingsOnce() ?: AppSettingsEntity()
            var seq = settings.nextPatientSeq
            var candidateId = ClinicDateFormatter.formatPatientId(seq)
            while (patientDao.existsById(candidateId)) {
                seq += 1
                candidateId = ClinicDateFormatter.formatPatientId(seq)
            }

            val nowIso = ClinicDateFormatter.nowTimestampIso()
            val trimmedName = name.trim()
            val patient = PatientEntity(
                id = candidateId,
                name = trimmedName,
                nameLower = trimmedName.lowercase(),
                age = age,
                gender = gender.storageValue,
                mobile = mobile.trim(),
                address = address.trim(),
                registrationDateIso = nowIso,
                updatedAtIso = nowIso
            )

            val firstVisit = VisitEntity(
                id = "V-${UUID.randomUUID()}",
                patientId = patient.id,
                visitDate = ClinicDateFormatter.todayDateIso(),
                createdAtIso = nowIso
            )

            patientDao.insertPatient(patient)
            visitDao.insertVisit(firstVisit)
            settingsDao.upsertSettings(settings.copy(nextPatientSeq = seq + 1))

            patient to firstVisit
        }
    }

    suspend fun updatePatientDetails(
        patientId: String,
        name: String,
        age: Int,
        gender: Gender,
        mobile: String,
        address: String
    ): PatientEntity? {
        val existing = patientDao.getPatientById(patientId) ?: return null
        val trimmed = name.trim()
        val updated = existing.copy(
            name = trimmed,
            nameLower = trimmed.lowercase(),
            age = age,
            gender = gender.storageValue,
            mobile = mobile.trim(),
            address = address.trim(),
            updatedAtIso = ClinicDateFormatter.nowTimestampIso()
        )
        patientDao.updatePatient(updated)
        return updated
    }

    suspend fun addNewVisit(patientId: String, visitDate: String = ClinicDateFormatter.todayDateIso()): VisitEntity {
        val visit = VisitEntity(
            id = "V-${UUID.randomUUID()}",
            patientId = patientId,
            visitDate = visitDate,
            createdAtIso = ClinicDateFormatter.nowTimestampIso()
        )
        visitDao.insertVisit(visit)
        return visit
    }

    suspend fun updateVisitDate(visitId: String, newDate: String) {
        visitDao.updateVisitDate(visitId, newDate)
    }

    suspend fun saveEncryptedPhotoBytes(
        patientId: String,
        visitId: String,
        category: ImageCategory,
        fileName: String,
        jpegBytes: ByteArray
    ) = withContext(Dispatchers.IO) {
        val photoId = (if (category == ImageCategory.PRESCRIPTION) "RX-" else "RP-") + UUID.randomUUID().toString()
        val categoryDir = File(privatePhotosRoot, "${patientId}/${visitId}/${category.name.lowercase()}").apply {
            mkdirs()
        }
        val destFile = File(categoryDir, "$photoId.enc")
        ClinicSecurityManager.writeEncryptedImage(context, destFile, jpegBytes)
        val nowIso = ClinicDateFormatter.nowTimestampIso()

        when (category) {
            ImageCategory.PRESCRIPTION -> {
                imageDao.insertPrescription(
                    PrescriptionImageEntity(
                        id = photoId,
                        visitId = visitId,
                        patientId = patientId,
                        fileName = fileName,
                        encryptedFilePath = destFile.absolutePath,
                        capturedAtIso = nowIso
                    )
                )
            }
            ImageCategory.REPORT -> {
                imageDao.insertReport(
                    ReportImageEntity(
                        id = photoId,
                        visitId = visitId,
                        patientId = patientId,
                        fileName = fileName,
                        encryptedFilePath = destFile.absolutePath,
                        capturedAtIso = nowIso
                    )
                )
            }
        }
    }

    suspend fun saveGalleryUris(
        patientId: String,
        visitId: String,
        category: ImageCategory,
        uris: List<Uri>
    ) = withContext(Dispatchers.IO) {
        for ((idx, uri) in uris.withIndex()) {
            val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: continue
            val name = "${category.name.lowercase()}_${System.currentTimeMillis()}_$idx.jpg"
            saveEncryptedPhotoBytes(patientId, visitId, category, name, bytes)
        }
    }

    suspend fun readDecryptedPhotoBytes(encryptedFilePath: String): ByteArray? = withContext(Dispatchers.IO) {
        val file = File(encryptedFilePath)
        if (!file.exists()) return@withContext null
        runCatching { ClinicSecurityManager.readEncryptedImage(context, file) }.getOrNull()
    }

    suspend fun deletePhoto(photo: MedicalPhotoUi) = withContext(Dispatchers.IO) {
        when (photo.category) {
            ImageCategory.PRESCRIPTION -> imageDao.deletePrescriptionById(photo.id)
            ImageCategory.REPORT -> imageDao.deleteReportById(photo.id)
        }
        File(photo.encryptedFilePath).delete()
    }

    suspend fun deleteVisitSafely(visitId: String) = withContext(Dispatchers.IO) {
        val rx = imageDao.getPrescriptionsForVisitOnce(visitId)
        val rep = imageDao.getReportsForVisitOnce(visitId)
        visitDao.deleteVisitById(visitId)
        (rx.map { it.encryptedFilePath } + rep.map { it.encryptedFilePath }).forEach { path ->
            File(path).delete()
        }
    }

    suspend fun deletePatientSafely(patientId: String) = withContext(Dispatchers.IO) {
        val rx = imageDao.getPrescriptionsForPatientOnce(patientId)
        val rep = imageDao.getReportsForPatientOnce(patientId)
        patientDao.deletePatientById(patientId)
        (rx.map { it.encryptedFilePath } + rep.map { it.encryptedFilePath }).forEach { path ->
            File(path).delete()
        }
    }
}

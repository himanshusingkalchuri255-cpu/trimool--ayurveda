package com.trimool.ayurveda.data.db

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "visits",
    foreignKeys = [
        ForeignKey(
            entity = PatientEntity::class,
            parentColumns = ["id"],
            childColumns = ["patientId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index(value = ["patientId"]),
        Index(value = ["visitDate"])
    ]
)
data class VisitEntity(
    @PrimaryKey
    val id: String,
    val patientId: String,
    val visitDate: String, // YYYY-MM-DD
    val createdAtIso: String
)

package com.trimool.ayurveda.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [
        PatientEntity::class,
        VisitEntity::class,
        PrescriptionImageEntity::class,
        ReportImageEntity::class,
        AppSettingsEntity::class
    ],
    version = 2,
    exportSchema = false
)
abstract class ClinicDatabase : RoomDatabase() {
    abstract fun patientDao(): PatientDao
    abstract fun visitDao(): VisitDao
    abstract fun medicalImageDao(): MedicalImageDao
    abstract fun settingsDao(): SettingsDao

    companion object {
        private const val DB_NAME = "trimool_ayurveda.db"

        // Explicit non-destructive migration preserving all patient, visit, and image records
        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    "CREATE INDEX IF NOT EXISTS index_patients_registrationDateIso ON patients(registrationDateIso)"
                )
                db.execSQL(
                    "CREATE INDEX IF NOT EXISTS index_visits_visitDate ON visits(visitDate)"
                )
            }
        }

        @Volatile
        private var INSTANCE: ClinicDatabase? = null

        fun getInstance(context: Context): ClinicDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    ClinicDatabase::class.java,
                    DB_NAME
                )
                    .addMigrations(MIGRATION_1_2)
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}

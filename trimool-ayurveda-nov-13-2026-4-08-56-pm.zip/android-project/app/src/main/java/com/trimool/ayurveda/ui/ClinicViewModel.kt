package com.trimool.ayurveda.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.trimool.ayurveda.TrimoolAyurvedaApp
import com.trimool.ayurveda.data.db.AppSettingsEntity
import com.trimool.ayurveda.data.db.PatientEntity
import com.trimool.ayurveda.data.db.VisitEntity
import com.trimool.ayurveda.data.db.VisitWithPhotoCountsRow
import com.trimool.ayurveda.domain.BackupValidationSummary
import com.trimool.ayurveda.domain.Gender
import com.trimool.ayurveda.domain.ImageCategory
import com.trimool.ayurveda.domain.MedicalPhotoUi
import com.trimool.ayurveda.domain.PatientSortOrder
import com.trimool.ayurveda.security.ClinicSecurityManager
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ClinicViewModel(application: Application) : AndroidViewModel(application) {
    private val app = application as TrimoolAyurvedaApp
    private val repo = app.repository
    private val backupManager = app.backupManager

    val settings: StateFlow<AppSettingsEntity> = repo.observeSettings()
        .stateIn(viewModelScope, SharingStarted.Eagerly, AppSettingsEntity())

    val totalPatientCount: StateFlow<Int> = repo.observeTotalPatientCount()
        .stateIn(viewModelScope, SharingStarted.Eagerly, 0)

    private val _isUnlocked = MutableStateFlow(false)
    val isUnlocked: StateFlow<Boolean> = _isUnlocked.asStateFlow()

    private val _lockChecked = MutableStateFlow(false)
    val lockChecked: StateFlow<Boolean> = _lockChecked.asStateFlow()

    init {
        viewModelScope.launch {
            val s = repo.getSettingsOnce()
            _isUnlocked.value = !s.pinEnabled
            _lockChecked.value = true
        }
    }

    // Directory search + sorting
    private val _directoryQuery = MutableStateFlow("")
    val directoryQuery: StateFlow<String> = _directoryQuery.asStateFlow()

    private val _sortOrder = MutableStateFlow(PatientSortOrder.NEWEST)
    val sortOrder: StateFlow<PatientSortOrder> = _sortOrder.asStateFlow()

    @OptIn(ExperimentalCoroutinesApi::class)
    val directoryPatients: StateFlow<List<PatientEntity>> =
        combine(_directoryQuery, _sortOrder) { q, sort -> q to sort }
            .flatMapLatest { (q, sort) ->
                if (q.isNotBlank()) repo.searchPatients(q) else repo.observePatients(sort)
            }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun setDirectoryQuery(q: String) {
        _directoryQuery.value = q
    }

    fun setSortOrder(order: PatientSortOrder) {
        _sortOrder.value = order
    }

    // Search screen
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    @OptIn(ExperimentalCoroutinesApi::class)
    val searchResults: StateFlow<List<PatientEntity>> = _searchQuery
        .flatMapLatest { q -> repo.searchPatients(q) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun setSearchQuery(q: String) {
        _searchQuery.value = q
    }

    // Profile & Visit History
    fun observePatient(patientId: String): Flow<PatientEntity?> = repo.observePatient(patientId)

    fun observeVisits(patientId: String): Flow<List<VisitWithPhotoCountsRow>> =
        repo.observeVisitsForPatient(patientId)

    fun observeVisit(visitId: String): Flow<VisitEntity?> = repo.observeVisit(visitId)

    fun observePhotos(visitId: String, category: ImageCategory): Flow<List<MedicalPhotoUi>> =
        repo.observePhotosForVisit(visitId, category)

    suspend fun readDecryptedPhotoBytes(path: String): ByteArray? =
        repo.readDecryptedPhotoBytes(path)

    // Registration & Duplicate checking
    private val _potentialDuplicates = MutableStateFlow<List<PatientEntity>>(emptyList())
    val potentialDuplicates: StateFlow<List<PatientEntity>> = _potentialDuplicates.asStateFlow()

    fun clearDuplicates() {
        _potentialDuplicates.value = emptyList()
    }

    fun submitNewPatient(
        name: String,
        age: Int,
        gender: Gender,
        mobile: String,
        address: String,
        bypassDuplicateCheck: Boolean,
        onCreated: (patientId: String, firstVisitId: String) -> Unit
    ) {
        viewModelScope.launch {
            if (!bypassDuplicateCheck) {
                val dups = repo.findPotentialDuplicates(name, mobile)
                if (dups.isNotEmpty()) {
                    _potentialDuplicates.value = dups
                    return@launch
                }
            }
            _potentialDuplicates.value = emptyList()
            val (patient, visit) = repo.registerPatientWithFirstVisit(name, age, gender, mobile, address)
            onCreated(patient.id, visit.id)
        }
    }

    fun updateExistingPatient(
        patientId: String,
        name: String,
        age: Int,
        gender: Gender,
        mobile: String,
        address: String,
        onDone: () -> Unit
    ) {
        viewModelScope.launch {
            repo.updatePatientDetails(patientId, name, age, gender, mobile, address)
            onDone()
        }
    }

    fun createVisitForPatient(patientId: String, onCreated: (String) -> Unit) {
        viewModelScope.launch {
            val visit = repo.addNewVisit(patientId)
            onCreated(visit.id)
        }
    }

    fun updateVisitDate(visitId: String, newDate: String) {
        viewModelScope.launch {
            repo.updateVisitDate(visitId, newDate)
        }
    }

    fun saveCameraPhoto(
        patientId: String,
        visitId: String,
        category: ImageCategory,
        fileName: String,
        bytes: ByteArray
    ) {
        viewModelScope.launch {
            repo.saveEncryptedPhotoBytes(patientId, visitId, category, fileName, bytes)
        }
    }

    fun saveGalleryPhotos(
        patientId: String,
        visitId: String,
        category: ImageCategory,
        uris: List<Uri>
    ) {
        viewModelScope.launch {
            repo.saveGalleryUris(patientId, visitId, category, uris)
        }
    }

    fun deletePhoto(photo: MedicalPhotoUi) {
        viewModelScope.launch {
            repo.deletePhoto(photo)
        }
    }

    fun deleteVisit(visitId: String, onDone: () -> Unit) {
        viewModelScope.launch {
            repo.deleteVisitSafely(visitId)
            onDone()
        }
    }

    fun deletePatient(patientId: String, onDone: () -> Unit) {
        viewModelScope.launch {
            repo.deletePatientSafely(patientId)
            onDone()
        }
    }

    // Security & Settings
    fun unlockWithPin(pin: String): Boolean {
        val s = settings.value
        val salt = s.pinSaltBase64 ?: return false
        val hash = s.pinHashBase64 ?: return false
        val ok = ClinicSecurityManager.verifyPin(pin, salt, hash)
        if (ok) _isUnlocked.value = true
        return ok
    }

    fun unlockWithBiometricSuccess() {
        _isUnlocked.value = true
    }

    fun lockNow() {
        if (settings.value.pinEnabled) {
            _isUnlocked.value = false
        }
    }

    fun enablePin(pin: String) {
        viewModelScope.launch {
            val salt = ClinicSecurityManager.generateSaltBase64()
            val hash = ClinicSecurityManager.hashPin(pin, salt)
            repo.updateSettings {
                it.copy(pinEnabled = true, pinSaltBase64 = salt, pinHashBase64 = hash)
            }
        }
    }

    fun disablePin() {
        viewModelScope.launch {
            repo.updateSettings {
                it.copy(
                    pinEnabled = false,
                    pinSaltBase64 = null,
                    pinHashBase64 = null,
                    biometricEnabled = false
                )
            }
            _isUnlocked.value = true
        }
    }

    fun setBiometricEnabled(enabled: Boolean) {
        viewModelScope.launch {
            repo.updateSettings { it.copy(biometricEnabled = enabled) }
        }
    }

    fun setDarkMode(dark: Boolean) {
        viewModelScope.launch {
            repo.updateSettings { it.copy(darkMode = dark) }
        }
    }

    fun setLanguage(lang: String) {
        viewModelScope.launch {
            repo.updateSettings { it.copy(language = lang) }
        }
    }

    // Encrypted Backup & Restore
    private val _backupMessage = MutableStateFlow<String?>(null)
    val backupMessage: StateFlow<String?> = _backupMessage.asStateFlow()

    private val _backupError = MutableStateFlow<String?>(null)
    val backupError: StateFlow<String?> = _backupError.asStateFlow()

    private val _validatedBackup = MutableStateFlow<BackupValidationSummary?>(null)
    val validatedBackup: StateFlow<BackupValidationSummary?> = _validatedBackup.asStateFlow()

    fun clearBackupMessages() {
        _backupMessage.value = null
        _backupError.value = null
    }

    fun clearValidatedBackup() {
        _validatedBackup.value = null
    }

    fun exportBackup(uri: Uri, passphrase: String, successMsg: String) {
        viewModelScope.launch {
            clearBackupMessages()
            runCatching {
                backupManager.exportToUri(uri, passphrase)
            }.onSuccess {
                _backupMessage.value = successMsg
            }.onFailure { err ->
                _backupError.value = err.message ?: "Backup failed"
            }
        }
    }

    fun validateBackupForRestore(uri: Uri, passphrase: String, invalidMsg: String) {
        viewModelScope.launch {
            clearBackupMessages()
            runCatching {
                backupManager.decryptAndValidateBackup(uri, passphrase)
            }.onSuccess { summary ->
                _validatedBackup.value = summary
            }.onFailure {
                _backupError.value = invalidMsg
            }
        }
    }

    fun confirmRestore(successMsg: String) {
        val summary = _validatedBackup.value ?: return
        viewModelScope.launch {
            clearBackupMessages()
            runCatching {
                backupManager.restoreValidatedBackup(summary)
            }.onSuccess {
                _validatedBackup.value = null
                _backupMessage.value = successMsg
            }.onFailure { err ->
                _backupError.value = err.message ?: "Restore failed"
            }
        }
    }
}

package com.trimool.ayurveda.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "app_settings")
data class AppSettingsEntity(
    @PrimaryKey
    val key: String = "app_settings",
    val language: String = "en", // "en" | "hi"
    val darkMode: Boolean = false,
    val pinEnabled: Boolean = false,
    val pinSaltBase64: String? = null,
    val pinHashBase64: String? = null,
    val biometricEnabled: Boolean = false,
    val nextPatientSeq: Int = 1,
    val lastBackupAtIso: String? = null
)

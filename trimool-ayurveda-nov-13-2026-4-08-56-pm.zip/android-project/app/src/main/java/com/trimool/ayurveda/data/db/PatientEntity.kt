package com.trimool.ayurveda.data.db

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "patients",
    indices = [
        Index(value = ["nameLower"]),
        Index(value = ["mobile"]),
        Index(value = ["registrationDateIso"])
    ]
)
data class PatientEntity(
    @PrimaryKey
    val id: String, // e.g., TA-00001
    val name: String,
    val nameLower: String,
    val age: Int,
    val gender: String, // "Male" | "Female" | "Other"
    val mobile: String,
    val address: String,
    val registrationDateIso: String,
    val updatedAtIso: String
)

package com.trimool.ayurveda.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

data class VisitWithPhotoCountsRow(
    val id: String,
    val patientId: String,
    val visitDate: String,
    val createdAtIso: String,
    val prescriptionCount: Int,
    val reportCount: Int
)

@Dao
interface VisitDao {
    @Query(
        """
        SELECT v.id, v.patientId, v.visitDate, v.createdAtIso,
               (SELECT COUNT(*) FROM prescription_images p WHERE p.visitId = v.id) AS prescriptionCount,
               (SELECT COUNT(*) FROM report_images r WHERE r.visitId = v.id) AS reportCount
        FROM visits v
        WHERE v.patientId = :patientId
        ORDER BY v.visitDate DESC, v.createdAtIso DESC
        """
    )
    fun observeVisitsWithCounts(patientId: String): Flow<List<VisitWithPhotoCountsRow>>

    @Query("SELECT * FROM visits WHERE id = :visitId LIMIT 1")
    fun observeVisitById(visitId: String): Flow<VisitEntity?>

    @Query("SELECT * FROM visits WHERE id = :visitId LIMIT 1")
    suspend fun getVisitById(visitId: String): VisitEntity?

    @Query("SELECT * FROM visits")
    suspend fun getAllVisitsOnce(): List<VisitEntity>

    // ABORT guarantees old visits are never overwritten
    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertVisit(visit: VisitEntity)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertVisitIfMissing(visit: VisitEntity): Long

    @Query("UPDATE visits SET visitDate = :newDate WHERE id = :visitId")
    suspend fun updateVisitDate(visitId: String, newDate: String)

    @Query("DELETE FROM visits WHERE id = :visitId")
    suspend fun deleteVisitById(visitId: String)
}

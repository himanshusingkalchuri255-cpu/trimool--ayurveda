package com.trimool.ayurveda.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.trimool.ayurveda.R
import com.trimool.ayurveda.data.db.PatientEntity
import com.trimool.ayurveda.data.db.VisitWithPhotoCountsRow
import com.trimool.ayurveda.domain.ClinicDateFormatter
import com.trimool.ayurveda.domain.Gender
import com.trimool.ayurveda.ui.components.ConfirmationDialog

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PatientProfileScreen(
    patient: PatientEntity?,
    visits: List<VisitWithPhotoCountsRow>,
    onEditPatient: () -> Unit,
    onAddNewVisit: () -> Unit,
    onOpenVisit: (String) -> Unit,
    onDeletePatient: () -> Unit,
    onBack: () -> Unit
) {
    var showDeleteDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.patient_profile)) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = stringResource(R.string.back)
                        )
                    }
                },
                actions = {
                    if (patient != null) {
                        IconButton(onClick = onEditPatient) {
                            Icon(
                                Icons.Default.Edit,
                                contentDescription = stringResource(R.string.edit_patient_details)
                            )
                        }
                        IconButton(onClick = { showDeleteDialog = true }) {
                            Icon(
                                Icons.Default.Delete,
                                contentDescription = stringResource(R.string.delete_patient)
                            )
                        }
                    }
                }
            )
        }
    ) { padding ->
        if (patient == null) return@Scaffold

        val genderLabel = when (Gender.fromStorage(patient.gender)) {
            Gender.MALE -> stringResource(R.string.gender_male)
            Gender.FEMALE -> stringResource(R.string.gender_female)
            Gender.OTHER -> stringResource(R.string.gender_other)
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(
                        modifier = Modifier.padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = "${stringResource(R.string.patient_id)}: ${patient.id}",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = patient.name,
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${patient.age} ${stringResource(R.string.years_short)} · $genderLabel",
                            style = MaterialTheme.typography.bodyLarge
                        )
                        Text(
                            text = "${stringResource(R.string.mobile_number)}: ${patient.mobile.ifBlank { stringResource(R.string.not_provided) }}",
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Text(
                            text = "${stringResource(R.string.address)}: ${patient.address.ifBlank { stringResource(R.string.no_address) }}",
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Text(
                            text = "${stringResource(R.string.registered_on)}: ${ClinicDateFormatter.formatDisplayDate(patient.registrationDateIso)}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Spacer(Modifier.height(8.dp))

                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Button(
                                onClick = onAddNewVisit,
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null)
                                Spacer(Modifier.padding(3.dp))
                                Text(stringResource(R.string.add_new_visit))
                            }
                            OutlinedButton(onClick = onEditPatient) {
                                Text(stringResource(R.string.edit_patient_details))
                            }
                        }
                    }
                }
            }

            item {
                Text(
                    text = "${stringResource(R.string.visit_history)} (${visits.size})",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(top = 6.dp)
                )
            }

            if (visits.isEmpty()) {
                item {
                    Text(
                        text = stringResource(R.string.no_visits),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                items(visits, key = { it.id }) { row ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onOpenVisit(row.id) }
                            .padding(vertical = 14.dp, horizontal = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = ClinicDateFormatter.formatDisplayDate(row.visitDate),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "${stringResource(R.string.prescription)}: ${row.prescriptionCount} · ${stringResource(R.string.reports)}: ${row.reportCount}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = null)
                    }
                    HorizontalDivider()
                }
            }

            item { Spacer(Modifier.height(16.dp)) }
        }
    }

    if (showDeleteDialog) {
        ConfirmationDialog(
            title = stringResource(R.string.delete_patient_title),
            description = stringResource(R.string.delete_patient_desc),
            confirmLabel = stringResource(R.string.confirm_delete),
            cancelLabel = stringResource(R.string.cancel),
            onConfirm = {
                showDeleteDialog = false
                onDeletePatient()
            },
            onDismiss = { showDeleteDialog = false }
        )
    }
}

package com.trimool.ayurveda.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.trimool.ayurveda.R
import com.trimool.ayurveda.data.db.PatientEntity
import com.trimool.ayurveda.domain.Gender
import com.trimool.ayurveda.domain.PatientSortOrder

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PatientDirectoryScreen(
    patients: List<PatientEntity>,
    query: String,
    sortOrder: PatientSortOrder,
    onQueryChange: (String) -> Unit,
    onSortChange: (PatientSortOrder) -> Unit,
    onSelectPatient: (String) -> Unit,
    onBack: () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("${stringResource(R.string.patient_directory)} (${patients.size})") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = stringResource(R.string.back)
                        )
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp)
        ) {
            OutlinedTextField(
                value = query,
                onValueChange = onQueryChange,
                placeholder = { Text(stringResource(R.string.search_hint)) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                trailingIcon = {
                    if (query.isNotEmpty()) {
                        IconButton(onClick = { onQueryChange("") }) {
                            Icon(Icons.Default.Clear, contentDescription = null)
                        }
                    }
                },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(Modifier.height(8.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = sortOrder == PatientSortOrder.NEWEST,
                    onClick = { onSortChange(PatientSortOrder.NEWEST) },
                    label = { Text(stringResource(R.string.sort_newest)) }
                )
                FilterChip(
                    selected = sortOrder == PatientSortOrder.NAME,
                    onClick = { onSortChange(PatientSortOrder.NAME) },
                    label = { Text(stringResource(R.string.sort_name)) }
                )
                FilterChip(
                    selected = sortOrder == PatientSortOrder.PATIENT_ID,
                    onClick = { onSortChange(PatientSortOrder.PATIENT_ID) },
                    label = { Text(stringResource(R.string.sort_id)) }
                )
            }

            Spacer(Modifier.height(8.dp))

            if (patients.isEmpty()) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(32.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = stringResource(R.string.no_patients_yet),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = stringResource(R.string.no_patients_hint),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                LazyColumn(modifier = Modifier.fillMaxSize()) {
                    items(patients, key = { it.id }) { patient ->
                        PatientListRow(patient = patient, onClick = { onSelectPatient(patient.id) })
                        HorizontalDivider()
                    }
                }
            }
        }
    }
}

@Composable
fun PatientListRow(
    patient: PatientEntity,
    onClick: () -> Unit
) {
    val genderLabel = when (Gender.fromStorage(patient.gender)) {
        Gender.MALE -> stringResource(R.string.gender_male)
        Gender.FEMALE -> stringResource(R.string.gender_female)
        Gender.OTHER -> stringResource(R.string.gender_other)
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 14.dp, horizontal = 4.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = patient.name,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                text = patient.id,
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary
            )
        }
        Spacer(Modifier.height(4.dp))
        val mobileSuffix = if (patient.mobile.isNotBlank()) " · ${patient.mobile}" else ""
        Text(
            text = "${patient.age} ${stringResource(R.string.years_short)} · $genderLabel$mobileSuffix",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        if (patient.address.isNotBlank()) {
            Text(
                text = patient.address,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

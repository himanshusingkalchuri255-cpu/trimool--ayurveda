package com.trimool.ayurveda.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface MedicalImageDao {
    @Query("SELECT * FROM prescription_images WHERE visitId = :visitId ORDER BY capturedAtIso ASC")
    fun observePrescriptionsForVisit(visitId: String): Flow<List<PrescriptionImageEntity>>

    @Query("SELECT * FROM report_images WHERE visitId = :visitId ORDER BY capturedAtIso ASC")
    fun observeReportsForVisit(visitId: String): Flow<List<ReportImageEntity>>

    @Query("SELECT * FROM prescription_images WHERE visitId = :visitId")
    suspend fun getPrescriptionsForVisitOnce(visitId: String): List<PrescriptionImageEntity>

    @Query("SELECT * FROM report_images WHERE visitId = :visitId")
    suspend fun getReportsForVisitOnce(visitId: String): List<ReportImageEntity>

    @Query("SELECT * FROM prescription_images WHERE patientId = :patientId")
    suspend fun getPrescriptionsForPatientOnce(patientId: String): List<PrescriptionImageEntity>

    @Query("SELECT * FROM report_images WHERE patientId = :patientId")
    suspend fun getReportsForPatientOnce(patientId: String): List<ReportImageEntity>

    @Query("SELECT * FROM prescription_images")
    suspend fun getAllPrescriptionsOnce(): List<PrescriptionImageEntity>

    @Query("SELECT * FROM report_images")
    suspend fun getAllReportsOnce(): List<ReportImageEntity>

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertPrescription(image: PrescriptionImageEntity)

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertReport(image: ReportImageEntity)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertPrescriptionIfMissing(image: PrescriptionImageEntity)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertReportIfMissing(image: ReportImageEntity)

    @Query("DELETE FROM prescription_images WHERE id = :imageId")
    suspend fun deletePrescriptionById(imageId: String)

    @Query("DELETE FROM report_images WHERE id = :imageId")
    suspend fun deleteReportById(imageId: String)
}

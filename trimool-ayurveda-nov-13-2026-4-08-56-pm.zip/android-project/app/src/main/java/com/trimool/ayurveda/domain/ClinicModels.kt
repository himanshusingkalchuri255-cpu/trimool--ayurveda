package com.trimool.ayurveda.domain

import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

enum class Gender(val storageValue: String) {
    MALE("Male"),
    FEMALE("Female"),
    OTHER("Other");

    companion object {
        fun fromStorage(value: String): Gender =
            entries.firstOrNull { it.storageValue.equals(value, ignoreCase = true) } ?: OTHER
    }
}

enum class ImageCategory {
    PRESCRIPTION,
    REPORT
}

enum class PatientSortOrder {
    NEWEST,
    NAME,
    PATIENT_ID
}

data class MedicalPhotoUi(
    val id: String,
    val visitId: String,
    val patientId: String,
    val category: ImageCategory,
    val fileName: String,
    val encryptedFilePath: String,
    val capturedAtIso: String
)

data class BackupValidationSummary(
    val exportedAtIso: String,
    val patientCount: Int,
    val visitCount: Int,
    val photoCount: Int,
    val rawPayloadJson: String
)

object ClinicDateFormatter {
    fun todayDateIso(): String = LocalDate.now().toString()

    fun nowTimestampIso(): String = Instant.now().toString()

    fun formatPatientId(seq: Int): String =
        "TA-" + seq.toString().padStart(5, '0')

    fun formatDisplayDate(dateOrIso: String, locale: Locale = Locale.getDefault()): String {
        return try {
            val localDate = if (dateOrIso.length > 10) {
                Instant.parse(dateOrIso).atZone(ZoneId.systemDefault()).toLocalDate()
            } else {
                LocalDate.parse(dateOrIso)
            }
            localDate.format(DateTimeFormatter.ofPattern("dd MMMM yyyy", locale))
        } catch (_: Exception) {
            dateOrIso
        }
    }
}

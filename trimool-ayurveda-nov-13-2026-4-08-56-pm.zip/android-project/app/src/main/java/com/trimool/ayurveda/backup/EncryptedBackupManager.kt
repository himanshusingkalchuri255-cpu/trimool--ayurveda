package com.trimool.ayurveda.backup

import android.content.Context
import android.net.Uri
import android.util.Base64
import androidx.room.withTransaction
import com.trimool.ayurveda.data.db.AppSettingsEntity
import com.trimool.ayurveda.data.db.ClinicDatabase
import com.trimool.ayurveda.data.db.PatientEntity
import com.trimool.ayurveda.data.db.PrescriptionImageEntity
import com.trimool.ayurveda.data.db.ReportImageEntity
import com.trimool.ayurveda.data.db.VisitEntity
import com.trimool.ayurveda.domain.BackupValidationSummary
import com.trimool.ayurveda.domain.ClinicDateFormatter
import com.trimool.ayurveda.security.ClinicSecurityManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.nio.charset.StandardCharsets
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

class EncryptedBackupManager(
    private val context: Context,
    private val db: ClinicDatabase
) {
    companion object {
        private const val FORMAT_HEADER = "TRIMOOL_AYURVEDA_ENCRYPTED_BACKUP"
        private const val KDF_ITERATIONS = 100_000
        private const val GCM_TAG_BITS = 128

        fun encryptPlaintextPayload(plaintextJson: String, passphrase: String): String {
            val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
            val iv = ByteArray(12).also { SecureRandom().nextBytes(it) }
            val key = deriveAesKey(passphrase, salt, KDF_ITERATIONS)

            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.ENCRYPT_MODE, key, GCMParameterSpec(GCM_TAG_BITS, iv))
            val ciphertext = cipher.doFinal(plaintextJson.toByteArray(StandardCharsets.UTF_8))

            return JSONObject().apply {
                put("format", FORMAT_HEADER)
                put("version", 1)
                put("algorithm", "AES-256-GCM")
                put("kdf", "PBKDF2-SHA256")
                put("iterations", KDF_ITERATIONS)
                put("salt", Base64.encodeToString(salt, Base64.NO_WRAP))
                put("iv", Base64.encodeToString(iv, Base64.NO_WRAP))
                put("ciphertext", Base64.encodeToString(ciphertext, Base64.NO_WRAP))
                put("createdAt", ClinicDateFormatter.nowTimestampIso())
            }.toString()
        }

        fun decryptEnvelopeToPayload(envelopeJson: String, passphrase: String): String {
            val envelope = JSONObject(envelopeJson)
            require(envelope.optString("format") == FORMAT_HEADER) { "Invalid backup format" }
            val iterations = envelope.optInt("iterations", KDF_ITERATIONS)
            val salt = Base64.decode(envelope.getString("salt"), Base64.NO_WRAP)
            val iv = Base64.decode(envelope.getString("iv"), Base64.NO_WRAP)
            val ciphertext = Base64.decode(envelope.getString("ciphertext"), Base64.NO_WRAP)

            val key = deriveAesKey(passphrase, salt, iterations)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(GCM_TAG_BITS, iv))
            val plainBytes = cipher.doFinal(ciphertext)
            return String(plainBytes, StandardCharsets.UTF_8)
        }

        private fun deriveAesKey(passphrase: String, salt: ByteArray, iterations: Int): SecretKeySpec {
            val spec = PBEKeySpec(passphrase.toCharArray(), salt, iterations, 256)
            val factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
            val encoded = factory.generateSecret(spec).encoded
            spec.clearPassword()
            return SecretKeySpec(encoded, "AES")
        }
    }

    suspend fun exportToUri(targetUri: Uri, passphrase: String) = withContext(Dispatchers.IO) {
        val patients = db.patientDao().getAllPatientsOnce()
        val visits = db.visitDao().getAllVisitsOnce()
        val prescriptions = db.medicalImageDao().getAllPrescriptionsOnce()
        val reports = db.medicalImageDao().getAllReportsOnce()
        val settings = db.settingsDao().getSettingsOnce() ?: AppSettingsEntity()

        val payload = JSONObject().apply {
            put("app", "TRIMOOL AYURVEDA")
            put("schemaVersion", 1)
            put("exportedAt", ClinicDateFormatter.nowTimestampIso())
            put("nextPatientSeq", settings.nextPatientSeq)

            put("patients", JSONArray().apply {
                patients.forEach { p ->
                    put(JSONObject().apply {
                        put("id", p.id)
                        put("name", p.name)
                        put("age", p.age)
                        put("gender", p.gender)
                        put("mobile", p.mobile)
                        put("address", p.address)
                        put("registrationDateIso", p.registrationDateIso)
                        put("updatedAtIso", p.updatedAtIso)
                    })
                }
            })

            put("visits", JSONArray().apply {
                visits.forEach { v ->
                    put(JSONObject().apply {
                        put("id", v.id)
                        put("patientId", v.patientId)
                        put("visitDate", v.visitDate)
                        put("createdAtIso", v.createdAtIso)
                    })
                }
            })

            put("prescriptionImages", JSONArray().apply {
                prescriptions.forEach { img ->
                    val file = File(img.encryptedFilePath)
                    if (file.exists()) {
                        val bytes = ClinicSecurityManager.readEncryptedImage(context, file)
                        put(JSONObject().apply {
                            put("id", img.id)
                            put("visitId", img.visitId)
                            put("patientId", img.patientId)
                            put("fileName", img.fileName)
                            put("capturedAtIso", img.capturedAtIso)
                            put("imageBase64", Base64.encodeToString(bytes, Base64.NO_WRAP))
                        })
                    }
                }
            })

            put("reportImages", JSONArray().apply {
                reports.forEach { img ->
                    val file = File(img.encryptedFilePath)
                    if (file.exists()) {
                        val bytes = ClinicSecurityManager.readEncryptedImage(context, file)
                        put(JSONObject().apply {
                            put("id", img.id)
                            put("visitId", img.visitId)
                            put("patientId", img.patientId)
                            put("fileName", img.fileName)
                            put("capturedAtIso", img.capturedAtIso)
                            put("imageBase64", Base64.encodeToString(bytes, Base64.NO_WRAP))
                        })
                    }
                }
            })
        }

        val encryptedJson = encryptPlaintextPayload(payload.toString(), passphrase)
        context.contentResolver.openOutputStream(targetUri)?.use { out ->
            out.write(encryptedJson.toByteArray(StandardCharsets.UTF_8))
        } ?: error("Unable to open backup destination")

        db.settingsDao().upsertSettings(
            settings.copy(lastBackupAtIso = ClinicDateFormatter.nowTimestampIso())
        )
    }

    suspend fun decryptAndValidateBackup(sourceUri: Uri, passphrase: String): BackupValidationSummary =
        withContext(Dispatchers.IO) {
            val rawEnvelope = context.contentResolver.openInputStream(sourceUri)?.use {
                it.readBytes().toString(StandardCharsets.UTF_8)
            } ?: error("Unable to read backup file")

            val payloadJson = decryptEnvelopeToPayload(rawEnvelope, passphrase)
            val root = JSONObject(payloadJson)
            require(root.optString("app") == "TRIMOOL AYURVEDA") { "Invalid backup application header" }

            val patients = root.getJSONArray("patients")
            val visits = root.getJSONArray("visits")
            val rxImages = root.getJSONArray("prescriptionImages")
            val repImages = root.getJSONArray("reportImages")

            BackupValidationSummary(
                exportedAtIso = root.optString("exportedAt", ""),
                patientCount = patients.length(),
                visitCount = visits.length(),
                photoCount = rxImages.length() + repImages.length(),
                rawPayloadJson = payloadJson
            )
        }

    // Restores missing records without overwriting existing patients/visits to prevent accidental duplicates or data loss
    suspend fun restoreValidatedBackup(summary: BackupValidationSummary) = withContext(Dispatchers.IO) {
        val root = JSONObject(summary.rawPayloadJson)
        val patientsArr = root.getJSONArray("patients")
        val visitsArr = root.getJSONArray("visits")
        val rxArr = root.getJSONArray("prescriptionImages")
        val repArr = root.getJSONArray("reportImages")
        val backupNextSeq = root.optInt("nextPatientSeq", 1)

        val photosRoot = File(context.filesDir, "clinic_encrypted_photos").apply { mkdirs() }

        val preparedRx = mutableListOf<PrescriptionImageEntity>()
        for (i in 0 until rxArr.length()) {
            val obj = rxArr.getJSONObject(i)
            val id = obj.getString("id")
            val visitId = obj.getString("visitId")
            val patientId = obj.getString("patientId")
            val bytes = Base64.decode(obj.getString("imageBase64"), Base64.NO_WRAP)
            val dest = File(photosRoot, "$patientId/$visitId/prescription/$id.enc")
            if (!dest.exists()) {
                ClinicSecurityManager.writeEncryptedImage(context, dest, bytes)
            }
            preparedRx.add(
                PrescriptionImageEntity(
                    id = id,
                    visitId = visitId,
                    patientId = patientId,
                    fileName = obj.optString("fileName", "$id.jpg"),
                    encryptedFilePath = dest.absolutePath,
                    capturedAtIso = obj.optString("capturedAtIso", ClinicDateFormatter.nowTimestampIso())
                )
            )
        }

        val preparedRep = mutableListOf<ReportImageEntity>()
        for (i in 0 until repArr.length()) {
            val obj = repArr.getJSONObject(i)
            val id = obj.getString("id")
            val visitId = obj.getString("visitId")
            val patientId = obj.getString("patientId")
            val bytes = Base64.decode(obj.getString("imageBase64"), Base64.NO_WRAP)
            val dest = File(photosRoot, "$patientId/$visitId/report/$id.enc")
            if (!dest.exists()) {
                ClinicSecurityManager.writeEncryptedImage(context, dest, bytes)
            }
            preparedRep.add(
                ReportImageEntity(
                    id = id,
                    visitId = visitId,
                    patientId = patientId,
                    fileName = obj.optString("fileName", "$id.jpg"),
                    encryptedFilePath = dest.absolutePath,
                    capturedAtIso = obj.optString("capturedAtIso", ClinicDateFormatter.nowTimestampIso())
                )
            )
        }

        db.withTransaction {
            val patientDao = db.patientDao()
            val visitDao = db.visitDao()
            val imageDao = db.medicalImageDao()

            for (i in 0 until patientsArr.length()) {
                val obj = patientsArr.getJSONObject(i)
                val name = obj.getString("name")
                patientDao.insertPatientIfMissing(
                    PatientEntity(
                        id = obj.getString("id"),
                        name = name,
                        nameLower = name.trim().lowercase(),
                        age = obj.getInt("age"),
                        gender = obj.getString("gender"),
                        mobile = obj.optString("mobile", ""),
                        address = obj.optString("address", ""),
                        registrationDateIso = obj.getString("registrationDateIso"),
                        updatedAtIso = obj.optString("updatedAtIso", obj.getString("registrationDateIso"))
                    )
                )
            }

            for (i in 0 until visitsArr.length()) {
                val obj = visitsArr.getJSONObject(i)
                visitDao.insertVisitIfMissing(
                    VisitEntity(
                        id = obj.getString("id"),
                        patientId = obj.getString("patientId"),
                        visitDate = obj.getString("visitDate"),
                        createdAtIso = obj.optString("createdAtIso", ClinicDateFormatter.nowTimestampIso())
                    )
                )
            }

            preparedRx.forEach { imageDao.insertPrescriptionIfMissing(it) }
            preparedRep.forEach { imageDao.insertReportIfMissing(it) }

            val currentSettings = db.settingsDao().getSettingsOnce() ?: AppSettingsEntity()
            val safeSeq = maxOf(currentSettings.nextPatientSeq, backupNextSeq, patientsArr.length() + 1)
            db.settingsDao().upsertSettings(currentSettings.copy(nextPatientSeq = safeSeq))
        }
    }
}

package com.trimool.ayurveda.data.db

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "prescription_images",
    foreignKeys = [
        ForeignKey(
            entity = VisitEntity::class,
            parentColumns = ["id"],
            childColumns = ["visitId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index(value = ["visitId"]),
        Index(value = ["patientId"])
    ]
)
data class PrescriptionImageEntity(
    @PrimaryKey
    val id: String,
    val visitId: String,
    val patientId: String,
    val fileName: String,
    val encryptedFilePath: String,
    val capturedAtIso: String
)

@Entity(
    tableName = "report_images",
    foreignKeys = [
        ForeignKey(
            entity = VisitEntity::class,
            parentColumns = ["id"],
            childColumns = ["visitId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index(value = ["visitId"]),
        Index(value = ["patientId"])
    ]
)
data class ReportImageEntity(
    @PrimaryKey
    val id: String,
    val visitId: String,
    val patientId: String,
    val fileName: String,
    val encryptedFilePath: String,
    val capturedAtIso: String
)

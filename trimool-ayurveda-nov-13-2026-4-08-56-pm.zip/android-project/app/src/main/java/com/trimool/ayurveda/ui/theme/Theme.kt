package com.trimool.ayurveda.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val ForestGreen = Color(0xFF14532D)
val ForestGreenContainer = Color(0xFFDCFCE7)
val LeafGreen = Color(0xFF166534)
val SoftNeutralBg = Color(0xFFF4F7F5)
val DarkBg = Color(0xFF0B1510)
val DarkSurface = Color(0xFF132219)
val LightMint = Color(0xFF86EFAC)

private val LightColors = lightColorScheme(
    primary = ForestGreen,
    onPrimary = Color.White,
    primaryContainer = ForestGreenContainer,
    onPrimaryContainer = Color(0xFF052E16),
    secondary = LeafGreen,
    onSecondary = Color.White,
    background = SoftNeutralBg,
    onBackground = Color(0xFF0F172A),
    surface = Color.White,
    onSurface = Color(0xFF0F172A),
    surfaceVariant = Color(0xFFEAF2ED),
    onSurfaceVariant = Color(0xFF334155)
)

private val DarkColors = darkColorScheme(
    primary = LightMint,
    onPrimary = Color(0xFF052E16),
    primaryContainer = Color(0xFF166534),
    onPrimaryContainer = Color(0xFFDCFCE7),
    secondary = Color(0xFF4ADE80),
    onSecondary = Color(0xFF052E16),
    background = DarkBg,
    onBackground = Color(0xFFF1F5F9),
    surface = DarkSurface,
    onSurface = Color(0xFFF1F5F9),
    surfaceVariant = Color(0xFF1A2F23),
    onSurfaceVariant = Color(0xFFCBD5E1)
)

@Composable
fun TrimoolAyurvedaTheme(
    darkTheme: Boolean,
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        content = content
    )
}

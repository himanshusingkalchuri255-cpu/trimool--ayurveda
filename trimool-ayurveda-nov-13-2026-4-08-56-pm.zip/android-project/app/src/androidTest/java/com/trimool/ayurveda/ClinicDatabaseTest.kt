package com.trimool.ayurveda

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.trimool.ayurveda.data.db.ClinicDatabase
import com.trimool.ayurveda.data.db.PatientEntity
import com.trimool.ayurveda.data.db.PrescriptionImageEntity
import com.trimool.ayurveda.data.db.ReportImageEntity
import com.trimool.ayurveda.data.db.VisitEntity
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class ClinicDatabaseTest {
    private lateinit var db: ClinicDatabase

    @Before
    fun setup() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        db = Room.inMemoryDatabaseBuilder(context, ClinicDatabase::class.java)
            .allowMainThreadQueries()
            .build()
    }

    @After
    fun tearDown() {
        db.close()
    }

    @Test
    fun registerPatientCreatesVisitAndKeepsPrescriptionAndReportsSeparate() = runTest {
        val patient = PatientEntity(
            id = "TA-00001",
            name = "Rahul Sharma",
            nameLower = "rahul sharma",
            age = 38,
            gender = "Male",
            mobile = "9876543210",
            address = "Indore",
            registrationDateIso = "2026-11-12T10:00:00Z",
            updatedAtIso = "2026-11-12T10:00:00Z"
        )
        val visit = VisitEntity(
            id = "V-1",
            patientId = "TA-00001",
            visitDate = "2026-11-12",
            createdAtIso = "2026-11-12T10:00:00Z"
        )

        db.patientDao().insertPatient(patient)
        db.visitDao().insertVisit(visit)

        db.medicalImageDao().insertPrescription(
            PrescriptionImageEntity(
                id = "RX-1",
                visitId = "V-1",
                patientId = "TA-00001",
                fileName = "rx.jpg",
                encryptedFilePath = "/tmp/rx.enc",
                capturedAtIso = "2026-11-12T10:05:00Z"
            )
        )
        db.medicalImageDao().insertReport(
            ReportImageEntity(
                id = "RP-1",
                visitId = "V-1",
                patientId = "TA-00001",
                fileName = "cbc.jpg",
                encryptedFilePath = "/tmp/cbc.enc",
                capturedAtIso = "2026-11-12T10:06:00Z"
            )
        )

        assertEquals(1, db.patientDao().observeTotalCount().first())
        val visits = db.visitDao().observeVisitsWithCounts("TA-00001").first()
        assertEquals(1, visits.size)
        assertEquals(1, visits.first().prescriptionCount)
        assertEquals(1, visits.first().reportCount)
    }
}

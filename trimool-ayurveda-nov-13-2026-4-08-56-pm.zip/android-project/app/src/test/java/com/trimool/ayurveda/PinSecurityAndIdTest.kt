package com.trimool.ayurveda

import com.trimool.ayurveda.domain.ClinicDateFormatter
import org.junit.Assert.assertEquals
import org.junit.Test

class PinSecurityAndIdTest {
    @Test
    fun patientIdFormatsZeroPaddedPrefix() {
        assertEquals("TA-00001", ClinicDateFormatter.formatPatientId(1))
        assertEquals("TA-00042", ClinicDateFormatter.formatPatientId(42))
        assertEquals("TA-12500", ClinicDateFormatter.formatPatientId(12500))
    }

    @Test
    fun todayDateFollowsIsoFormat() {
        val today = ClinicDateFormatter.todayDateIso()
        assertEquals(10, today.length)
        assertEquals('-', today[4])
        assertEquals('-', today[7])
    }
}

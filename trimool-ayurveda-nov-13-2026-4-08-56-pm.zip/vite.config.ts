import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import {defineConfig, type Plugin} from 'vite';
import {VitePWA} from 'vite-plugin-pwa';

function disableHmrWsGuardPlugin(): Plugin {
  return {
    name: 'ai-studio-disable-hmr-ws-guard',
    apply: 'serve',
    configureServer(server) {
      if (process.env.DISABLE_HMR !== 'true') return;
      server.middlewares.use((req, res, next) => {
        if (req.url?.startsWith('/dev-sw.js')) {
          res.setHeader('Content-Type', 'application/javascript');
          res.end(
            'self.addEventListener("install",()=>self.skipWaiting());self.addEventListener("activate",()=>{self.registration.unregister();});'
          );
          return;
        }
        next();
      });
    },
    transform(code, id) {
      if (process.env.DISABLE_HMR !== 'true') return null;
      const normalized = id.replace(/\\/g, '/');
      if (
        normalized.endsWith('/vite/dist/client/client.mjs') ||
        normalized.endsWith('/vite/dist/client/bundledDevClient.mjs')
      ) {
        return code.replaceAll(
          'ws.send(JSON.stringify(data));',
          'if (ws && ws.readyState === ws.OPEN) ws.send(JSON.stringify(data));'
        );
      }
      return null;
    },
  };
}

export default defineConfig(() => {
  return {
    plugins: [
      disableHmrWsGuardPlugin(),
      react(),
      tailwindcss(),
      VitePWA({
        registerType: 'autoUpdate',
        includeAssets: ['icon.svg', 'apple-touch-icon.png', 'pwa-192x192.png', 'pwa-512x512.png', 'pwa-maskable-512x512.png'],
        manifest: {
          id: '/',
          name: 'TRIMOOL AYURVEDA',
          short_name: 'TRIMOOL',
          description: 'Offline-first Ayurvedic clinic patient register, visit history, and encrypted prescription and medical report archive.',
          theme_color: '#14532D',
          background_color: '#F4F7F5',
          display: 'standalone',
          start_url: '/',
          scope: '/',
          icons: [
            {
              src: '/pwa-192x192.png',
              sizes: '192x192',
              type: 'image/png',
              purpose: 'any',
            },
            {
              src: '/pwa-512x512.png',
              sizes: '512x512',
              type: 'image/png',
              purpose: 'any',
            },
            {
              src: '/pwa-maskable-512x512.png',
              sizes: '512x512',
              type: 'image/png',
              purpose: 'maskable',
            },
          ],
        },
        workbox: {
          globPatterns: ['**/*.{js,css,html,ico,png,svg,woff,woff2}'],
          runtimeCaching: [
            {
              urlPattern: /^https:\/\/fonts\.googleapis\.com\/.*/i,
              handler: 'CacheFirst',
              options: {
                cacheName: 'google-fonts-cache',
                expiration: {
                  maxEntries: 10,
                  maxAgeSeconds: 60 * 60 * 24 * 365,
                },
                cacheableResponse: {
                  statuses: [0, 200],
                },
              },
            },
            {
              urlPattern: /^https:\/\/fonts\.gstatic\.com\/.*/i,
              handler: 'CacheFirst',
              options: {
                cacheName: 'gstatic-fonts-cache',
                expiration: {
                  maxEntries: 10,
                  maxAgeSeconds: 60 * 60 * 24 * 365,
                },
                cacheableResponse: {
                  statuses: [0, 200],
                },
              },
            },
          ],
        },
        devOptions: {
          enabled: process.env.DISABLE_HMR !== 'true',
          type: 'module',
        },
      }),
    ],
    resolve: {
      alias: {
        '@': path.resolve(__dirname, '.'),
      },
    },
    server: {
      // HMR is disabled in AI Studio via DISABLE_HMR env var.
      // Do not modify—file watching is disabled to prevent flickering during agent edits.
      hmr: process.env.DISABLE_HMR !== 'true',
      // Disable file watching when DISABLE_HMR is true to save CPU during agent edits.
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});

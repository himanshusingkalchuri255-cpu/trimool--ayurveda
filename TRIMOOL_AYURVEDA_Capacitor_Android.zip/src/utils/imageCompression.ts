export interface CompressibleImageInput {
  dataUrl: string;
  fileName: string;
  mimeType: string;
  sizeBytes: number;
}

const MAX_IMAGE_DIMENSION = 1600;
const JPEG_QUALITY = 0.78;
const SKIP_COMPRESSION_UNDER_BYTES = 180 * 1024; // 180 KB

function estimateDataUrlBytes(dataUrl: string): number {
  const commaIdx = dataUrl.indexOf(',');
  const b64Len = commaIdx >= 0 ? dataUrl.length - commaIdx - 1 : dataUrl.length;
  return Math.round((b64Len * 3) / 4);
}

function replaceExtensionWithJpg(fileName: string): string {
  const dotIdx = fileName.lastIndexOf('.');
  if (dotIdx <= 0) return `${fileName}.jpg`;
  return `${fileName.slice(0, dotIdx)}.jpg`;
}

function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error('Failed to decode image for compression'));
    img.src = src;
  });
}

/**
 * Compresses medical prescription and lab report photos client-side while
 * preserving crisp handwriting and small-text legibility (max 1600px, JPEG 0.78).
 * Falls back safely to the original image if compression fails or isn't smaller.
 */
export async function compressMedicalImage(
  input: CompressibleImageInput
): Promise<CompressibleImageInput> {
  if (!input.dataUrl.startsWith('data:image/')) {
    return input;
  }

  try {
    const img = await loadImage(input.dataUrl);
    const origW = img.naturalWidth || img.width;
    const origH = img.naturalHeight || img.height;
    if (!origW || !origH) {
      return input;
    }

    const originalBytes = input.sizeBytes || estimateDataUrlBytes(input.dataUrl);
    const needsResize = origW > MAX_IMAGE_DIMENSION || origH > MAX_IMAGE_DIMENSION;

    if (!needsResize && originalBytes <= SKIP_COMPRESSION_UNDER_BYTES) {
      return input;
    }

    let targetW = origW;
    let targetH = origH;
    if (needsResize) {
      if (origW >= origH) {
        targetW = MAX_IMAGE_DIMENSION;
        targetH = Math.max(1, Math.round((origH * MAX_IMAGE_DIMENSION) / origW));
      } else {
        targetH = MAX_IMAGE_DIMENSION;
        targetW = Math.max(1, Math.round((origW * MAX_IMAGE_DIMENSION) / origH));
      }
    }

    const canvas = document.createElement('canvas');
    canvas.width = targetW;
    canvas.height = targetH;
    const ctx = canvas.getContext('2d');
    if (!ctx) {
      return input;
    }

    // White backdrop prevents transparent PNGs from turning black in JPEG
    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(0, 0, targetW, targetH);
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = 'high';
    ctx.drawImage(img, 0, 0, targetW, targetH);

    const compressedUrl = canvas.toDataURL('image/jpeg', JPEG_QUALITY);
    if (!compressedUrl.startsWith('data:image/jpeg')) {
      return input;
    }

    const compressedBytes = estimateDataUrlBytes(compressedUrl);
    if (!needsResize && compressedBytes >= originalBytes) {
      return input;
    }
    if (compressedBytes >= originalBytes && originalBytes <= 500 * 1024) {
      return input;
    }

    return {
      dataUrl: compressedUrl,
      fileName: replaceExtensionWithJpg(input.fileName),
      mimeType: 'image/jpeg',
      sizeBytes: compressedBytes,
    };
  } catch {
    return input;
  }
}

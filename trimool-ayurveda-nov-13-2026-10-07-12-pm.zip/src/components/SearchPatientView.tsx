import React, { useEffect, useMemo, useState } from 'react';
import { ArrowLeft, ChevronRight, Search, X } from 'lucide-react';
import { getAllPatients } from '../db/database';
import { getGenderLabel, translations } from '../i18n/translations';
import type { Language, Patient } from '../types';

interface SearchPatientViewProps {
  language: Language;
  mode: 'search' | 'directory';
  onBack: () => void;
  onSelectPatient: (patientId: string) => void;
}

export const SearchPatientView: React.FC<SearchPatientViewProps> = ({
  language,
  mode,
  onBack,
  onSelectPatient,
}) => {
  const t = translations[language];
  const [patients, setPatients] = useState<Patient[]>([]);
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState('');

  useEffect(() => {
    let active = true;
    getAllPatients()
      .then((list) => {
        if (active) setPatients(list);
      })
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => {
      active = false;
    };
  }, []);

  const results = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) {
      return mode === 'directory' ? patients : [];
    }
    return patients.filter(
      (p) =>
        p.nameLower.includes(q) ||
        p.id.toLowerCase().includes(q) ||
        p.mobile.toLowerCase().includes(q)
    );
  }, [patients, query, mode]);

  return (
    <div className="mx-auto max-w-3xl space-y-5">
      <div className="flex items-center gap-3">
        <button
          type="button"
          onClick={onBack}
          className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl border border-emerald-950/10 dark:border-emerald-200/15 bg-white dark:bg-[#132219] text-slate-700 dark:text-slate-200 hover:bg-emerald-50 dark:hover:bg-emerald-950/50 transition-colors cursor-pointer"
          aria-label={t.backHome}
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-slate-100">
            {mode === 'directory' ? t.patientDirectory : t.searchTitle}
          </h2>
          {mode === 'directory' && (
            <p className="text-xs text-slate-600 dark:text-slate-400 tabular-nums">
              {t.totalPatient}: {patients.length}
            </p>
          )}
        </div>
      </div>

      {/* Live Search Input */}
      <div className="relative">
        <Search className="w-5 h-5 text-slate-400 absolute left-4 top-1/2 -translate-y-1/2 pointer-events-none" />
        <input
          type="text"
          autoFocus={mode === 'search'}
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder={t.searchPlaceholder}
          className="w-full min-h-[52px] rounded-2xl border border-emerald-950/15 dark:border-emerald-200/20 bg-white dark:bg-[#132219] pl-12 pr-12 py-3 text-base text-slate-900 dark:text-slate-100 shadow-xs focus:outline-none focus:ring-2 focus:ring-emerald-700"
        />
        {query && (
          <button
            type="button"
            onClick={() => setQuery('')}
            className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 absolute right-1 top-1/2 -translate-y-1/2 cursor-pointer"
            aria-label="Clear search"
          >
            <X className="w-5 h-5" />
          </button>
        )}
      </div>

      {/* Results List */}
      {loading ? (
        <div className="rounded-2xl bg-white dark:bg-[#132219] border border-emerald-950/10 dark:border-emerald-200/10 p-8 text-center text-sm text-slate-500 dark:text-slate-400">
          ...
        </div>
      ) : patients.length === 0 ? (
        <div className="rounded-2xl bg-white dark:bg-[#132219] border border-emerald-950/10 dark:border-emerald-200/10 p-8 text-center space-y-1">
          <p className="text-base font-semibold text-slate-800 dark:text-slate-200">
            {t.noPatientsYet}
          </p>
          <p className="text-sm text-slate-500 dark:text-slate-400">{t.noPatientsHint}</p>
        </div>
      ) : mode === 'search' && !query.trim() ? (
        <div className="rounded-2xl bg-white dark:bg-[#132219] border border-emerald-950/10 dark:border-emerald-200/10 p-8 text-center text-sm text-slate-600 dark:text-slate-300">
          {t.searchPrompt}
        </div>
      ) : results.length === 0 ? (
        <div className="rounded-2xl bg-white dark:bg-[#132219] border border-emerald-950/10 dark:border-emerald-200/10 p-8 text-center text-sm text-slate-600 dark:text-slate-300">
          {t.noSearchResults}
        </div>
      ) : (
        <div className="rounded-2xl bg-white dark:bg-[#132219] border border-emerald-950/10 dark:border-emerald-200/10 divide-y divide-slate-100 dark:divide-emerald-200/10 overflow-hidden shadow-xs">
          {results.map((patient) => (
            <button
              key={patient.id}
              type="button"
              onClick={() => onSelectPatient(patient.id)}
              className="w-full min-h-[72px] px-5 py-4 text-left flex items-center justify-between gap-4 hover:bg-emerald-50/60 dark:hover:bg-emerald-950/40 transition-colors cursor-pointer"
            >
              <div className="min-w-0 flex-1">
                <div className="flex flex-wrap items-baseline gap-x-2.5 gap-y-0.5">
                  <span className="text-base font-semibold text-slate-900 dark:text-slate-100">
                    {patient.name}
                  </span>
                  <span className="text-xs font-medium text-emerald-800 dark:text-emerald-300 tabular-nums">
                    {patient.id}
                  </span>
                </div>
                <div className="mt-1 flex flex-wrap items-center gap-x-2 gap-y-0.5 text-sm text-slate-600 dark:text-slate-300 tabular-nums">
                  {patient.age != null && (
                    <>
                      <span>
                        {patient.age} {t.yearsShort}
                      </span>
                      <span aria-hidden="true">·</span>
                    </>
                  )}
                  <span>{getGenderLabel(patient.gender, language)}</span>
                  {patient.mobile && (
                    <>
                      <span aria-hidden="true">·</span>
                      <span>
                        {t.mobileLabel}: {patient.mobile}
                      </span>
                    </>
                  )}
                </div>
                <p className="mt-0.5 text-xs text-slate-500 dark:text-slate-400 truncate">
                  {patient.address || t.noAddress}
                </p>
              </div>
              <ChevronRight className="w-5 h-5 text-slate-400 shrink-0" />
            </button>
          ))}
        </div>
      )}
    </div>
  );
};

import type { Gender, Language } from '../types';

export const translations = {
  en: {
    appName: 'TRIMOOL AYURVEDA',
    appSubtitle: 'Patient Record Register',
    offlineReady: 'Offline Mode — All records saved locally',
    installApp: 'Install App',
    installOnIOS: 'Install on iPhone',
    iosInstallTitle: 'Install TRIMOOL AYURVEDA',
    iosInstallStep1: 'Tap the Share button in Safari.',
    iosInstallStep2: 'Scroll down and tap "Add to Home Screen".',
    close: 'Close',

    // Home — ONLY 3 main options
    totalPatient: 'TOTAL PATIENT',
    addNew: 'ADD NEW',
    searchPatient: 'SEARCH PATIENT',
    settings: 'Settings',
    lockApp: 'Lock App',

    // Patient Directory (when tapping Total Patient)
    patientDirectory: 'Registered Patients',
    noPatientsYet: 'No patients registered yet',
    noPatientsHint: 'Use ADD NEW on the home screen to register your first patient.',
    backHome: 'Back',

    // Add / Edit Patient
    newPatientTitle: 'Register New Patient',
    editPatientTitle: 'Edit Patient Details',
    patientId: 'Patient ID',
    patientName: 'Patient Name',
    patientNamePlaceholder: 'Enter full name',
    age: 'Age',
    agePlaceholder: 'Years (optional)',
    gender: 'Sex / Gender',
    male: 'Male',
    female: 'Female',
    other: 'Other',
    mobile: 'Mobile Number',
    mobilePlaceholder: '10-digit mobile (optional)',
    address: 'Address',
    addressPlaceholder: 'Village / Town / Full address (optional)',
    required: 'Required',
    optional: 'Optional',
    saveAndCreateVisit: 'Save Patient & Start First Visit',
    saveChanges: 'Save Changes',
    cancel: 'Cancel',
    validationNameRequired: 'Patient name is required.',
    validationAgeRequired: 'Please enter a valid age (0–125).',

    // Duplicate warning
    duplicateTitle: 'Possible Existing Patient Found',
    duplicateDesc:
      'A registered patient with a matching mobile number or name already exists. Open their profile to add a new visit instead of creating a duplicate record.',
    openExistingProfile: 'Open Existing Profile',
    createNewAnyway: 'Create Separate New Record',

    // Search
    searchTitle: 'Search Patient',
    searchPlaceholder: 'Type patient name, mobile, or TA-ID...',
    searchPrompt: 'Start typing a patient name to see matching records instantly.',
    noSearchResults: 'No matching patients found',
    yearsShort: 'yrs',
    mobileLabel: 'Mob',
    noAddress: 'No address recorded',
    noMobile: 'Not provided',
    noAge: 'Not provided',

    // Patient Profile & Visit History
    patientProfile: 'Patient Profile',
    registrationDate: 'Registered On',
    editPatientDetails: 'Edit Patient Details',
    addNewVisit: 'Add New Visit',
    visitHistory: 'Visit History',
    noVisits: 'No visits recorded.',
    prescriptionsCount: 'Prescriptions',
    reportsCount: 'Reports',
    deletePatient: 'Delete Patient Record',
    deletePatientConfirmTitle: 'Delete Patient Permanently?',
    deletePatientConfirmDesc:
      'This will permanently remove this patient, all visit records, and all prescription and report photographs. This action cannot be undone.',
    confirmDelete: 'Delete Permanently',

    // Visit Detail
    visitDetails: 'Visit Details',
    visitDate: 'Visit Date',
    editVisitDate: 'Correct Date',
    saveDate: 'Save Date',
    deleteVisit: 'Delete Visit',
    deleteVisitConfirmTitle: 'Delete This Visit?',
    deleteVisitConfirmDesc:
      'This will permanently delete this visit and all prescription and report photographs attached to it.',
    prescriptionsTab: 'PRESCRIPTION',
    reportsTab: 'REPORTS',
    captureFromCamera: 'Capture from Camera',
    uploadFromGallery: 'Upload from Gallery',
    noPrescriptions: 'No prescription photographs added for this visit yet.',
    noReports: 'No medical report photographs added for this visit yet.',
    deletePhotoTitle: 'Delete Photograph?',
    deletePhotoDesc: 'Are you sure you want to remove this photograph from this visit?',
    deletePhoto: 'Delete Photo',
    photoSavedTo: 'Saved to',

    // Camera Modal
    cameraTitlePrescription: 'Capture Prescription',
    cameraTitleReport: 'Capture Medical Report',
    cameraStarting: 'Starting camera...',
    cameraError:
      'Unable to access live camera in this browser/frame. Use the device camera upload button below.',
    useDeviceCamera: 'Open Device Camera',
    capturePhoto: 'Capture Photo',
    retake: 'Retake',
    savePhoto: 'Save Photograph',

    // Fullscreen Viewer
    zoomIn: 'Zoom In',
    zoomOut: 'Zoom Out',
    resetZoom: 'Reset',
    pinchHint: 'Pinch or scroll to zoom · Drag to pan',

    // Security & Lock Screen
    unlockTitle: 'TRIMOOL AYURVEDA Locked',
    unlockSubtitle: 'Enter your clinic PIN to access patient records.',
    enterPin: 'Enter PIN',
    unlock: 'Unlock',
    useBiometric: 'Unlock with Fingerprint / Face',
    wrongPin: 'Incorrect PIN. Please try again.',
    biometricFailed: 'Biometric verification was cancelled or failed.',

    // Settings
    settingsTitle: 'Clinic Settings',
    appearanceAndLanguage: 'Language & Appearance',
    languageLabel: 'Application Language',
    themeLabel: 'Colour Theme',
    lightMode: 'Light Mode',
    darkMode: 'Dark Mode',
    securitySection: 'Security & Privacy',
    appPinLock: 'App PIN Lock',
    pinEnabledLabel: 'PIN lock is active',
    pinDisabledLabel: 'Protect patient records with a 4–6 digit PIN',
    setPinPlaceholder: 'Enter 4–6 digit PIN',
    confirmPinPlaceholder: 'Confirm PIN',
    enablePin: 'Enable PIN Lock',
    disablePin: 'Disable PIN Lock',
    pinMismatch: 'PINs do not match or must be 4–6 digits.',
    biometricLock: 'Biometric Authentication',
    biometricSupportedHint: 'Use device fingerprint or face unlock when unlocking the app',
    biometricUnsupportedHint: 'Biometric authenticator is not available in this browser/environment.',
    enableBiometric: 'Register Biometric Unlock',
    disableBiometric: 'Disable Biometric',
    encryptLocalPhotos: 'Encrypt Stored Photographs (AES-256-GCM)',
    encryptLocalPhotosHint: 'Encrypts prescription and report images inside local device storage',
    enabled: 'Enabled',
    disabled: 'Disabled',

    // Backup & Restore
    localBackupSection: 'Encrypted Local Backup & Restore',
    localBackupDesc:
      'Create a single AES-256-GCM encrypted backup file containing all patients, visits, prescriptions, and reports.',
    backupPassphrase: 'Backup Encryption Passphrase',
    passphrasePlaceholder: 'Enter a strong passphrase (min 6 chars)',
    passphraseTooShort: 'Please enter a passphrase of at least 6 characters.',
    createLocalBackup: 'Save Encrypted Backup',
    restoreLocalBackup: 'Restore from Backup File',
    lastBackup: 'Last Backup',
    neverBackedUp: 'Not backed up yet',

    // Google Drive Backup
    googleDriveSection: 'Google Drive Backup (Optional)',
    googleDriveDesc:
      'Optionally connect your Google account to save or restore encrypted backups. Normal clinic work always stays offline.',
    connectedAs: 'Connected as',
    signOut: 'Disconnect',
    uploadToDrive: 'Upload Encrypted Backup to Drive',
    refreshDriveBackups: 'Load Drive Backups',
    noDriveBackups: 'No TRIMOOL AYURVEDA backups found in Google Drive.',
    restoreFromDrive: 'Restore',
    deleteFromDrive: 'Delete',
    deleteDriveConfirmTitle: 'Delete Backup from Google Drive?',
    deleteDriveConfirmDesc: 'This will permanently delete this encrypted backup file from your Google Drive.',
    backupSuccess: 'Encrypted backup created successfully.',
    driveUploadSuccess: 'Encrypted backup uploaded to Google Drive.',
    restoreModalTitle: 'Restore Encrypted Backup',
    restorePassphrasePrompt: 'Enter the passphrase used when this backup was created:',
    decryptAndVerify: 'Decrypt & Inspect Backup',
    restoreConfirmSummary: 'Ready to restore the following encrypted records:',
    patientsCountLabel: 'Patients',
    visitsCountLabel: 'Visits',
    imagesCountLabel: 'Photographs',
    restoreReplaceWarning:
      'Restoring will replace current local records with the contents of this verified backup.',
    confirmRestore: 'Confirm & Restore Records',
    restoreSuccess: 'All patient records, visits, and photographs have been restored.',
    wrongPassphrase: 'Incorrect passphrase or corrupted backup file.',

    // Native Android Studio project info
    androidExportSection: 'Android Studio Kotlin Project & APK Guide',
    androidExportDesc:
      'This environment runs as an installable Android/Mobile Web App (PWA) with offline storage. Complete native Kotlin + Jetpack Compose + Room source files are included in the project repository (/android-project) ready to build in Android Studio.',
    pwaToAndroidHint:
      'Moving data between PWA and Android APK: Create an Encrypted Local Backup here, then open the Android app → Settings → Restore from Backup File and enter the same passphrase.',
  },
  hi: {
    appName: 'त्रिमूल आयुर्वेद',
    appSubtitle: 'रोगी अभिलेख पंजिका',
    offlineReady: 'ऑफ़लाइन मोड — सभी रिकॉर्ड फ़ोन में सुरक्षित हैं',
    installApp: 'ऐप इंस्टॉल करें',
    installOnIOS: 'iPhone पर इंस्टॉल करें',
    iosInstallTitle: 'त्रिमूल आयुर्वेद इंस्टॉल करें',
    iosInstallStep1: 'Safari में Share बटन दबाएं।',
    iosInstallStep2: 'नीचे स्क्रॉल करें और "Add to Home Screen" चुनें।',
    close: 'बंद करें',

    // Home
    totalPatient: 'कुल मरीज़',
    addNew: 'नया मरीज़',
    searchPatient: 'मरीज़ खोजें',
    settings: 'सेटिंग्स',
    lockApp: 'ऐप लॉक करें',

    // Directory
    patientDirectory: 'पंजीकृत मरीज़',
    noPatientsYet: 'अभी कोई मरीज़ पंजीकृत नहीं है',
    noPatientsHint: 'पहला मरीज़ जोड़ने के लिए होम स्क्रीन पर "नया मरीज़" चुनें।',
    backHome: 'वापस',

    // Add / Edit
    newPatientTitle: 'नया मरीज़ पंजीकृत करें',
    editPatientTitle: 'मरीज़ का विवरण बदलें',
    patientId: 'मरीज़ आईडी',
    patientName: 'मरीज़ का नाम',
    patientNamePlaceholder: 'पूरा नाम लिखें',
    age: 'उम्र (वर्ष)',
    agePlaceholder: 'उम्र (वैकल्पिक)',
    gender: 'लिंग',
    male: 'पुरुष',
    female: 'महिला',
    other: 'अन्य',
    mobile: 'मोबाइल नंबर',
    mobilePlaceholder: '10 अंकों का मोबाइल नंबर (वैकल्पिक)',
    address: 'पता',
    addressPlaceholder: 'गाँव / शहर / पूरा पता (वैकल्पिक)',
    required: 'आवश्यक',
    optional: 'वैकल्पिक',
    saveAndCreateVisit: 'मरीज़ सहेजें और पहली विज़िट शुरू करें',
    saveChanges: 'परिवर्तन सहेजें',
    cancel: 'रद्द करें',
    validationNameRequired: 'मरीज़ का नाम आवश्यक है।',
    validationAgeRequired: 'कृपया सही उम्र (0–125) दर्ज करें।',

    // Duplicate
    duplicateTitle: 'संभावित पुराना मरीज़ मिला',
    duplicateDesc:
      'इस मोबाइल नंबर या नाम से पहले से एक मरीज़ पंजीकृत है। नया रिकॉर्ड बनाने के बजाय उनकी प्रोफ़ाइल खोलकर नई विज़िट जोड़ें।',
    openExistingProfile: 'पुरानी प्रोफ़ाइल खोलें',
    createNewAnyway: 'फिर भी नया रिकॉर्ड बनाएं',

    // Search
    searchTitle: 'मरीज़ खोजें',
    searchPlaceholder: 'नाम, मोबाइल नंबर या TA-आईडी लिखें...',
    searchPrompt: 'मरीज़ का नाम लिखना शुरू करें, मिलते-जुलते रिकॉर्ड तुरंत दिखेंगे।',
    noSearchResults: 'कोई मिलता-जुलता मरीज़ नहीं मिला',
    yearsShort: 'वर्ष',
    mobileLabel: 'मोबा.',
    noAddress: 'पता दर्ज नहीं',
    noMobile: 'उपलब्ध नहीं',
    noAge: 'उपलब्ध नहीं',

    // Profile
    patientProfile: 'मरीज़ प्रोफ़ाइल',
    registrationDate: 'पंजीकरण तिथि',
    editPatientDetails: 'विवरण संपादित करें',
    addNewVisit: 'नई विज़िट जोड़ें',
    visitHistory: 'विज़िट इतिहास',
    noVisits: 'कोई विज़िट दर्ज नहीं है।',
    prescriptionsCount: 'प्रिस्क्रिप्शन',
    reportsCount: 'रिपोर्ट',
    deletePatient: 'मरीज़ रिकॉर्ड हटाएं',
    deletePatientConfirmTitle: 'क्या मरीज़ को स्थायी रूप से हटाएं?',
    deletePatientConfirmDesc:
      'इससे मरीज़ की जानकारी, सभी पुरानी विज़िट और सभी प्रिस्क्रिप्शन व रिपोर्ट फ़ोटो स्थायी रूप से हट जाएंगे।',
    confirmDelete: 'स्थायी रूप से हटाएं',

    // Visit Detail
    visitDetails: 'विज़िट विवरण',
    visitDate: 'विज़िट की तारीख़',
    editVisitDate: 'तारीख़ सुधारें',
    saveDate: 'तारीख़ सहेजें',
    deleteVisit: 'विज़िट हटाएं',
    deleteVisitConfirmTitle: 'क्या यह विज़िट हटाएं?',
    deleteVisitConfirmDesc: 'इस विज़िट के सभी प्रिस्क्रिप्शन और रिपोर्ट फ़ोटो स्थायी रूप से हट जाएंगे।',
    prescriptionsTab: 'प्रिस्क्रिप्शन (पर्चा)',
    reportsTab: 'मेडिकल रिपोर्ट',
    captureFromCamera: 'कैमरे से फ़ोटो लें',
    uploadFromGallery: 'गैलरी से चुनें',
    noPrescriptions: 'इस विज़िट के लिए अभी कोई प्रिस्क्रिप्शन फ़ोटो नहीं है।',
    noReports: 'इस विज़िट के लिए अभी कोई मेडिकल रिपोर्ट फ़ोटो नहीं है।',
    deletePhotoTitle: 'फ़ोटो हटाएं?',
    deletePhotoDesc: 'क्या आप वाकई इस फ़ोटो को इस विज़िट से हटाना चाहते हैं?',
    deletePhoto: 'फ़ोटो हटाएं',
    photoSavedTo: 'सहेजा गया:',

    // Camera
    cameraTitlePrescription: 'प्रिस्क्रिप्शन फ़ोटो लें',
    cameraTitleReport: 'रिपोर्ट फ़ोटो लें',
    cameraStarting: 'कैमरा चालू हो रहा है...',
    cameraError: 'लाइव कैमरा उपलब्ध नहीं है। नीचे दिए गए डिवाइस कैमरा बटन का उपयोग करें।',
    useDeviceCamera: 'फ़ोन कैमरा खोलें',
    capturePhoto: 'फ़ोटो खींचें',
    retake: 'दोबारा लें',
    savePhoto: 'फ़ोटो सहेजें',

    // Viewer
    zoomIn: 'ज़ूम इन',
    zoomOut: 'ज़ूम आउट',
    resetZoom: 'रीसेट',
    pinchHint: 'ज़ूम करने के लिए पिंच या स्क्रॉल करें · खिसकाने के लिए ड्रैग करें',

    // Security
    unlockTitle: 'त्रिमूल आयुर्वेद लॉक है',
    unlockSubtitle: 'मरीज़ के रिकॉर्ड देखने के लिए क्लिनिक पिन दर्ज करें।',
    enterPin: 'पिन दर्ज करें',
    unlock: 'खोलें',
    useBiometric: 'फ़िंगरप्रिंट / फेस से खोलें',
    wrongPin: 'गलत पिन। कृपया पुनः प्रयास करें।',
    biometricFailed: 'बायोमेट्रिक सत्यापन रद्द हुआ या असफल रहा।',

    // Settings
    settingsTitle: 'क्लिनिक सेटिंग्स',
    appearanceAndLanguage: 'भाषा और रंग थीम',
    languageLabel: 'ऐप की भाषा',
    themeLabel: 'रंग थीम',
    lightMode: 'लाइट मोड',
    darkMode: 'डार्क मोड',
    securitySection: 'सुरक्षा और गोपनीयता',
    appPinLock: 'ऐप पिन लॉक',
    pinEnabledLabel: 'पिन लॉक सक्रिय है',
    pinDisabledLabel: '4–6 अंकों के पिन से रिकॉर्ड सुरक्षित रखें',
    setPinPlaceholder: '4–6 अंकों का पिन लिखें',
    confirmPinPlaceholder: 'पिन की पुष्टि करें',
    enablePin: 'पिन लॉक चालू करें',
    disablePin: 'पिन लॉक बंद करें',
    pinMismatch: 'पिन मेल नहीं खा रहे या 4–6 अंकों के नहीं हैं।',
    biometricLock: 'बायोमेट्रिक अनलॉक',
    biometricSupportedHint: 'ऐप खोलने के लिए फ़िंगरप्रिंट या फेस अनलॉक का उपयोग करें',
    biometricUnsupportedHint: 'इस ब्राउज़र में बायोमेट्रिक सुविधा उपलब्ध नहीं है।',
    enableBiometric: 'बायोमेट्रिक सेट करें',
    disableBiometric: 'बायोमेट्रिक बंद करें',
    encryptLocalPhotos: 'फ़ोटो एन्क्रिप्शन (AES-256-GCM)',
    encryptLocalPhotosHint: 'प्रिस्क्रिप्शन और रिपोर्ट फ़ोटो को एन्क्रिप्ट करके सुरक्षित रखता है',
    enabled: 'चालू',
    disabled: 'बंद',

    // Backup
    localBackupSection: 'एन्क्रिप्टेड लोकल बैकअप और रीस्टोर',
    localBackupDesc:
      'सभी मरीज़ों, विज़िट, प्रिस्क्रिप्शन और रिपोर्ट का एक AES-256-GCM एन्क्रिप्टेड बैकअप बनाएं।',
    backupPassphrase: 'बैकअप पासवर्ड (Passphrase)',
    passphrasePlaceholder: 'मज़बूत पासवर्ड लिखें (कम से कम 6 अक्षर)',
    passphraseTooShort: 'कृपया कम से कम 6 अक्षरों का पासवर्ड लिखें।',
    createLocalBackup: 'एन्क्रिप्टेड बैकअप सहेजें',
    restoreLocalBackup: 'बैकअप फ़ाइल से रीस्टोर करें',
    lastBackup: 'पिछला बैकअप',
    neverBackedUp: 'अभी तक कोई बैकअप नहीं',

    // Drive
    googleDriveSection: 'गूगल ड्राइव बैकअप (वैकल्पिक)',
    googleDriveDesc:
      'एन्क्रिप्टेड बैकअप सहेजने या रीस्टोर करने के लिए अपना Google खाता जोड़ें। सामान्य कार्य पूरी तरह ऑफ़लाइन चलता है।',
    connectedAs: 'जुड़ा हुआ खाता',
    signOut: 'हटाएं',
    uploadToDrive: 'Google Drive पर एन्क्रिप्टेड बैकअप अपलोड करें',
    refreshDriveBackups: 'Drive बैकअप देखें',
    noDriveBackups: 'Google Drive में कोई त्रिमूल आयुर्वेद बैकअप नहीं मिला।',
    restoreFromDrive: 'रीस्टोर करें',
    deleteFromDrive: 'हटाएं',
    deleteDriveConfirmTitle: 'Google Drive से बैकअप हटाएं?',
    deleteDriveConfirmDesc: 'यह एन्क्रिप्टेड बैकअप फ़ाइल आपके Google Drive से स्थायी रूप से हट जाएगी।',
    backupSuccess: 'एन्क्रिप्टेड बैकअप सफलतापूर्वक तैयार हो गया।',
    driveUploadSuccess: 'एन्क्रिप्टेड बैकअप Google Drive पर अपलोड हो गया।',
    restoreModalTitle: 'एन्क्रिप्टेड बैकअप रीस्टोर करें',
    restorePassphrasePrompt: 'इस बैकअप को बनाते समय उपयोग किया गया पासवर्ड दर्ज करें:',
    decryptAndVerify: 'डिक्रिप्ट और जांच करें',
    restoreConfirmSummary: 'निम्नलिखित सत्यापित रिकॉर्ड रीस्टोर किए जाएंगे:',
    patientsCountLabel: 'मरीज़',
    visitsCountLabel: 'विज़िट',
    imagesCountLabel: 'फ़ोटो',
    restoreReplaceWarning: 'रीस्टोर करने पर वर्तमान लोकल डेटा इस बैकअप के डेटा से बदल जाएगा।',
    confirmRestore: 'पुष्टि करें और रीस्टोर करें',
    restoreSuccess: 'सभी मरीज़, विज़िट और फ़ोटो सफलतापूर्वक रीस्टोर हो गए।',
    wrongPassphrase: 'गलत पासवर्ड या खराब बैकअप फ़ाइल।',

    // Android Source
    androidExportSection: 'Android Studio Kotlin प्रोजेक्ट और APK गाइड',
    androidExportDesc:
      'यह ऐप इंस्टॉल होने योग्य ऑफ़लाइन मोबाइल वेब ऐप (PWA) के रूप में तुरंत काम करता है। संपूर्ण Kotlin + Jetpack Compose + Room प्रोजेक्ट फ़ाइलें (/android-project) में शामिल हैं।',
    pwaToAndroidHint:
      'PWA और Android APK के बीच डेटा ट्रांसफ़र: यहाँ से एन्क्रिप्टेड लोकल बैकअप बनाएं, फिर Android ऐप में सेटिंग्स → बैकअप फ़ाइल से रीस्टोर करें खोलकर वही पासवर्ड डालें।',
  },
} as const;

export function getGenderLabel(gender: Gender, lang: Language): string {
  const t = translations[lang];
  if (gender === 'Male') return t.male;
  if (gender === 'Female') return t.female;
  return t.other;
}

export function formatDisplayDate(dateStr: string, lang: Language): string {
  if (!dateStr) return '';
  const parts = dateStr.split('T')[0].split('-');
  if (parts.length !== 3) return dateStr;
  const year = Number(parts[0]);
  const month = Number(parts[1]) - 1;
  const day = Number(parts[2]);
  const dt = new Date(year, month, day);
  return dt.toLocaleDateString(lang === 'hi' ? 'hi-IN' : 'en-GB', {
    day: '2-digit',
    month: 'long',
    year: 'numeric',
  });
}

export function getTodayDateString(): string {
  const now = new Date();
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, '0');
  const d = String(now.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}
